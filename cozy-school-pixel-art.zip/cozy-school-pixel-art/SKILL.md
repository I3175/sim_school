---
name: cozy-school-pixel-art
description: Create cohesive 16-bit-inspired, top-down pixel art for a cozy student RPG, including school maps, game-screen mockups, UI overlays, characters, and directional walking spritesheets. Use for school courtyard scenes, student character assets, or related game art that should share this visual direction.
---

# Cozy school pixel art

Create warm, nostalgic, readable 2D game art for a student RPG. Preserve a coherent visual language across maps, characters, and UI: top-down or three-quarter game view, deliberate pixel clusters, restrained outlines, warm highlights, and clean edges. Treat “Stardew Valley aesthetic” as a broad cozy farming-RPG mood cue; create original characters, layouts, icons, and UI.

## Choose the deliverable

- **Game-screen concept:** Generate a complete 16:9 screenshot. Depict a walkable school courtyard with a red brick building, lush trees, wooden benches, cobblestone paths, and warm golden-hour light. Add retro inventory slots, health and stamina bars, and a parchment-style dialogue box along the bottom. Keep the playable scene visible around the overlay.
- **Character sheet concept:** Generate a 16:9 sheet on a plain light-gray background. Show one cute student in a consistent classic uniform. Arrange front, back, left, and right orientations into a regular grid with idle and sequential walking poses. Keep baselines, scale, outfit details, and spacing consistent; request crisp edges and no blur.
- **Other asset:** Reuse the same palette, pixel density, outlines, and school setting. Ask for exact dimensions and frame specifications only if the user needs implementation-ready files and has not supplied them.

## Generate and inspect

1. Restate the requested asset as a concise image prompt with its intended use, framing, subjects, style, and constraints. Default to 16:9 for the two concepts above unless the user specifies otherwise.
2. Use the image-generation tool for raster concepts. If the user requests a true sprite asset for a game engine, specify transparent background, fixed per-frame cell size, precise row and column order, equal padding, and the desired frame count. A light-gray background is appropriate only for a preview sheet.
3. Inspect the output for viewpoint, all requested school details, UI placement, distinct directions, consistent character proportions, sharp pixel edges, and spacing. Fix a concrete defect with a focused edit or regeneration.
4. Distinguish visual mockups from engine-ready assets. Generated grids can drift by a few pixels; verify frame bounds and alignment before claiming a sheet is directly sliceable. For production, create or request deterministic slicing, alpha cleanup, and animation checks.
5. Preserve the chosen character design and palette when generating follow-up scenes or sheets. Use prior output as a visual reference when available.

Avoid watermarks and unrequested logos or text. For UI copy, include exact wording only when supplied by the user; otherwise favor short, legible labels or an empty dialogue field.

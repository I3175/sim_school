# Làng Sao Mai project profile

Source: workspace `Game Design Document & Master Prompt.md`, version 1.0. Read the actual section before producing its assets; this is a routing profile, not a replacement GDD.

- Sections 0.2, 2: Godot 4.3+, 320×180 logical viewport, integer scaling, Nearest filtering, 16×16 tiles, 16×32 player/NPC cells. PC first, Vietnamese UI.
- Section 3: game art in `assets/art/` (characters, tilesets, buildings, props, items, plants, animals, monsters, fx, ui, portraits); audio in `assets/audio/`. Do not move legacy assets without checking references.
- Sections 5–6, 14.4: region layouts, buildings and regional palettes. Farm is green/earth/warm; school lemon-yellow/blue; forest deep green/night-purple; mountain white/cool-blue/purple. Preserve each region's identity.
- Sections 7.2–7.3: matching 16×32 layered sheets. Rows down/up/left; right mirrors left. Columns are animation frames. Layers include shadow, back equipment, body, bottoms, shoes, top, eyes, hair, hat, accessories and anchored hand item. Back equipment draw order depends on facing. Palette-swappable layers use four reference shades. Consult the GDD for hand anchors and animation-specific counts.
- Initial animations: idle 2 frames at 2 FPS; walk 6 at 10 FPS; run 6 at 14 FPS. Separate animation folders can preserve the `{layer}_{style_id}.png` naming rule.
- Sections 8.2 and 14.5: item icons 16×16; dialogue portraits 48×48.
- Section 11: monster sizes depend on tier; defeat uses ink/paper, no blood.
- Section 12: crop growth stages and seasonal plants. The detailed 4–6-stage requirement takes precedence over the approximate five-frame MVP inventory.
- Section 13: water uses 4 frames at 0.4 seconds/frame, shoreline terrain transitions.
- Section 14: title, character creation, HUD and menus; native localized text should remain separate from art.
- Section 15.5: implementation proceeds M0–M14, with an independent scene, tests and API documentation per system. Skill use alone does not establish milestone completion.
- Section 16.1: art-batch order is outdoor seasons, interiors, player layers, NPC sprites/portraits, tools/weapons, crops, animals, monsters, UI, then audio through an appropriate audio workflow. Suggested counts are MVP planning quantities, not proof that content exists.

Record source/license, cell geometry, frame order, pivot, FPS, palette and validation status for shipped assets. Label temporary placeholders explicitly. Do not claim a generated concept is engine-ready without measured checks.

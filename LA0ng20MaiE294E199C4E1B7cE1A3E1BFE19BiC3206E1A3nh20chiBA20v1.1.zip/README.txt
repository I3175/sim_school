LÀNG SAO MAI — BỘ ĐẶC TẢ THẾ GIỚI v1.1

01_Tai_lieu/Làng Sao Mai — Game Design Document & Master Prompt.md
  GDD v1.0 do người dùng cung cấp: nguồn luật gameplay.
01_Tai_lieu/Làng Sao Mai — Đặc tả thiết kế giao diện.md
  UI spec do người dùng cung cấp.
01_Tai_lieu/Làng Sao Mai — Đặc tả toàn bộ thế giới game v1.1.md
  Bản World Design Bible bổ sung 11 vùng; quy định mới có gắn nhãn.
01_Tai_lieu/Làng Sao Mai — GDD tích hợp đặc tả thế giới v1.1.md
  GDD gốc + world bible nối tiếp trong một tệp.
02_Anh_tham_chieu/
  Sáu hình minh họa gốc đã cung cấp.

LƯU Ý: Hình là tài liệu định hướng mỹ thuật và UI. Không xem tên khác biệt trong ảnh là canonical; xem DEC-01 đến DEC-12 ở mục 19 World Bible.

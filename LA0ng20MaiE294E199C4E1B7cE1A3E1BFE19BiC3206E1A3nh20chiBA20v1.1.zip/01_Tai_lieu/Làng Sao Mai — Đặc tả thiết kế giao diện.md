# Làng Sao Mai — Đặc tả giao diện theo bố cục cozy farming RPG

*Bản viết lại từ UI Spec v1 · Godot 4.3+ · viewport cơ sở 320×180 · tile 16×16 · pixel art ấm áp*

## 1. Mục tiêu và định hướng

Làng Sao Mai là game nhập vai đời sống kết hợp học tập. Giao diện cần tạo cảm giác đang sống trong một ngôi làng nhỏ: trồng trọt, khám phá, trò chuyện, thu thập vật phẩm và học kiến thức qua hoạt động trong thế giới.

Bố cục tham khảo cách tổ chức quen thuộc của **Stardew Valley**: góc màn hình dành cho thông tin nhanh, hotbar nằm sát đáy, menu lớn mở thành một cuốn sổ ở giữa màn hình, các mục được chia bằng tab, hội thoại đặt ở cạnh dưới. Chỉ tham khảo nguyên tắc bố cục và nhịp thị giác; nhân vật, biểu tượng, bản đồ, minh họa, tên gọi và asset phải là thiết kế riêng của Làng Sao Mai.

### Trụ cột giao diện

- Thế giới là điểm nhìn chính; HUD gọn và nằm sát mép màn hình.
- Menu lớn chỉ xuất hiện khi người chơi chủ động mở; thời gian game tạm dừng.
- Mỗi màn hình có một điểm nhấn, chữ ngắn và dễ quét mắt.
- Vật liệu gỗ, giấy, vải và kim loại gợi cảm giác sổ tay của cư dân.
- Học tập là hoạt động trong thế giới, không trình bày như một bài kiểm tra căng thẳng.
- Toàn bộ thao tác dùng được bằng bàn phím, chuột và tay cầm.

## 2. Khung hiển thị và phong cách

| Hạng mục | Quy định |
|---|---|
| Viewport cơ sở | 320×180, tỷ lệ 16:9 |
| Ô bản đồ | Tile 16×16 |
| Phóng to | Chỉ scale nguyên 2×, 3×, 4×; không làm mờ pixel |
| Lưới giao diện | 4 px; padding trong 4 px; khoảng cách panel 4 px |
| Lề an toàn | 4 px; chế độ TV dùng 16 px |
| Bộ lọc texture | NEAREST; tọa độ và kích thước Control là số nguyên |
| Font | Bitmap dễ đọc, 8 px mặc định, dòng 12 px; có đủ dấu tiếng Việt |

### Bảng màu giao diện

| Vai trò | Màu |
|---|---|
| Mực / viền | `#2B1B17` |
| Gỗ tối | `#5A3A2A` |
| Gỗ | `#8B5E3C` |
| Gỗ sáng | `#B98554` |
| Giấy | `#F4E4BC` |
| Kem | `#FFF6DA` |
| Lá / thành công | `#6DB04A` / `#3E7B3A` |
| Đỏ / cảnh báo | `#D94A4A` / `#8E2D3A` |
| Vàng / chọn / Xu | `#F2C14E` |
| Lam / nước / tri thức Số | `#4A86C5` |
| Tím / tri thức Ngữ | `#8A64B8` |
| Cam / tri thức Chữ | `#E8884A` |
| Hồng / quan hệ | `#E58FA8` |
| Xám / khóa / vô hiệu | `#8C8578` |

### Panel và nút

- `panel_wood`: viền Mực, lõi Gỗ tối và Gỗ; cạnh trên/trái sáng hơn. Dùng cho HUD, hộp thoại, tooltip và viền ngoài của menu.
- `panel_paper`: giấy sáng, viền Gỗ 1 px, góc vát 1 px. Dùng cho trang nội dung.
- `panel_slot`: ô lõm, có viền sáng/tối để nhìn rõ vật phẩm.
- `panel_tab`: tab gỗ gắn liền với trang giấy đang mở.
- Nút thường dùng chữ Kem; focus có viền Vàng và con trỏ sổ tay 8×8; nút bị khóa chuyển Xám; thao tác phá/xóa dùng viền Đỏ và cần xác nhận.

## 3. Bố cục màn hình khi chơi

Thế giới chiếm toàn bộ nền. HUD không đóng thành một khung lớn; mỗi nhóm thông tin dùng panel nhỏ riêng, đặt dọc theo mép để giữ phần giữa thoáng.

### HUD mặc định ở viewport 320×180

| Thành phần | Vị trí gợi ý | Kích thước / nội dung |
|---|---:|---|
| Theo dõi nhiệm vụ | Trên trái, x=4 y=4 | Tối đa 112×44; 1–2 mục tiêu ngắn, thu gọn được |
| Đồng hồ / lịch / thời tiết | Trên phải, x=240 y=4 | 76×42; giờ, thứ, mùa-ngày, icon thời tiết và nhiệt độ |
| Xu | Dưới đồng hồ, x=240 y=48 | 76×14; icon Xu và số căn phải |
| Minimap tùy chọn | Phải giữa, x=266 y=66 | 48×48; ẩn trong nhà hoặc khi tắt cài đặt |
| Thanh thể lực | Mép phải, x=308 y=128 | 8×44; Lá bình thường, Đỏ khi dưới 15% |
| Trạng thái / buff | Mép trái phía trên hotbar | Icon 12×12, tối đa 6; thời lượng bằng vạch nhỏ |
| HP | Dưới trái, x=4 y=156 | 34×20; tim, thanh HP, số hiện khi mở rộng HUD |
| Hotbar | Giữa sát đáy, x=40 y=156 | 12 ô × 20 px, liền nhau; ô chọn viền Vàng |
| Toast nhặt đồ | Trên hotbar, x≈44 | Tối đa 3 dòng; icon, tên ngắn, số lượng; tự mất sau 3 giây |
| Banner sự kiện | Giữa phía trên | Tối đa 160×28; lên cấp, nhiệm vụ hoặc mở khóa |

Trên màn hình nhỏ hoặc khi cỡ chữ tăng, HUD tự chuyển sang bố cục gọn: minimap ẩn trước, theo dõi nhiệm vụ chỉ còn biểu tượng và một dòng, còn hotbar và HP luôn hiện.

### Hành vi HUD

- Sau 6 giây không có sự kiện, HUD phụ mờ xuống 50%; tương tác, nhận sát thương, nhặt vật phẩm hoặc đổi thời gian đưa HUD về 100%.
- Khi có quái trong vòng 10 ô, HP và hotbar không mờ dưới 70%.
- Khi mở menu hoặc hội thoại, ẩn HUD trừ Xu nếu đang giao dịch.
- `H` bật/tắt HUD để chụp cảnh. Không ẩn các chỉ báo bắt buộc trong chế độ trợ năng.
- Không đặt panel che nhân vật khi chiến đấu. Panel lớn chỉ mở khi game đã tạm dừng.

### Đồng hồ và lịch

Panel góc phải hiển thị ví dụ `08:40`, `Thứ Hai`, `Xuân · Ngày 3`, icon trời nắng và `22°C`. Giờ game tăng theo bước 10 phút. Từ 00:00 đến 02:00, giờ chuyển đỏ nhẹ như lời nhắc nghỉ ngơi. Ngày lễ hội có cờ nhỏ cạnh mùa.

## 4. Hotbar, vật phẩm và chỉ số

- Hotbar có đúng 12 ô, mỗi ô 20×20 px; số phím 1–0, `-`, `=` nằm mờ ở góc trên trái.
- Ô đang chọn viền Vàng 1 px và nhô lên 2 px. Icon 16×16 đặt giữa; số lượng ở góc dưới phải; sao chất lượng ở góc dưới trái.
- Tay cầm dùng LB/RB để đổi ô, D-pad chọn nhanh 4 ô đầu.
- HP hiển thị bằng tim và thanh Đỏ. Mất máu có vệt màu Kem trễ 0,3 giây rồi mới co thanh.
- Thể lực hiển thị bằng thanh dọc màu Lá. Khi hết thể lực, thanh rung nhẹ và công cụ bị gạch chéo; có thể tắt rung.
- Buff có viền Lá, hiệu ứng xấu có viền Đỏ. Mỗi trạng thái phải có cả icon và màu, không dùng màu làm tín hiệu duy nhất.
- Khi túi đầy, viền túi chuyển Đỏ nhạt trong 1 giây và hiện toast ngắn.

## 5. Menu sổ tay

Nhấn `Tab` hoặc `I` để mở. Lớp phủ nền tối 55–60%, dừng thời gian game. Một cuốn sổ giấy lớn nằm giữa màn hình, viền gỗ, kích thước co theo độ phân giải. Hàng tab gỗ nằm phía trên trang; tab đang chọn sáng màu Vàng và nối liền với trang giấy. Điều hướng tab bằng Q/E, LB/RB; `Esc` hoặc `Tab` đóng sổ.

Trang chính gồm các mục: Túi đồ, Kỹ năng & Tri thức, Nhiệm vụ, Bách khoa, Bản đồ, Quan hệ, Chế tạo, Cài đặt. Dùng icon pixel riêng và nhãn khi focus. Mỗi trang có nút focus mặc định rõ ràng.

### Túi đồ

- Lưới 12×3 ô, hàng đầu là hotbar và được đánh dấu bằng viền Vàng nhạt.
- Cột bên cạnh hoặc dải dưới hiển thị vật phẩm đang chọn: icon lớn, tên, mô tả ngắn, độ hiếm, giá bán và nút hành động phù hợp.
- Hành động: Dùng, Trang bị, Vứt, Sắp xếp. Vật phẩm hiếm cần xác nhận trước khi vứt.
- Chuột kéo-thả; chuột phải dùng/trang bị; Shift-kéo tách chồng. Tay cầm A nhấc/đặt, X dùng, Y tách, RT sắp xếp.
- Tooltip hiện sau 0,25 giây hover; tay cầm hiện ngay khi focus. Tooltip tự lật vào trong màn hình.

### Kỹ năng & Tri thức

- Trang chia đôi: 5 kỹ năng nghề ở trái, biểu đồ ngũ giác 5 mảng tri thức ở phải.
- Mảng tri thức: Số, Chữ, Ngữ, Vật, Ký; màu luôn đi kèm icon riêng.
- Mỗi kỹ năng có cấp và thanh XP. Ở cấp 5/10 mở lựa chọn nhánh kèm hộp giải thích lợi ích.
- Cây tài năng dùng lưới 3×4, đường nối giữa nút và số điểm còn lại.

### Nhiệm vụ

- Bộ lọc dạng tab/chip: Hôm nay, Chính, Phụ, Lặt vặt, Tâm tình, Thử thách, Lễ hội, Đã kích hoạt.
- Danh sách gọn ở trái, nội dung nhiệm vụ ở phải: người giao, mô tả, mục tiêu, thưởng, hạn và nút Ghim/Bỏ ghim.
- Trạng thái có icon riêng: đang làm, có thể nộp, hoàn thành, hết hạn. Tối đa 3 nhiệm vụ được ghim lên HUD.
- Nhiệm vụ chính tuyến dùng nền vàng giấy nhạt; mục tiêu tùy chọn có nhãn riêng.

### Bách khoa

- Tab ngang: Cá, Thú, Quái, Cây, Khoáng sản.
- Lưới icon pixel; mục chưa khám phá hiện bóng tối kèm dấu `?`.
- Trang chi tiết cho biết hình, nơi tìm, mùa, giờ, thời tiết và tiến độ khám phá.

### Bản đồ

- Bản đồ vẽ tay trên nền giấy, tên vùng và đường nối rõ ràng.
- Địa điểm bị khóa hiện ổ khóa cùng điều kiện mở. Chấm người chơi nổi bật; NPC chỉ xuất hiện khi có Tri thức Ký phù hợp.
- Chọn địa điểm có thể ghim mục tiêu nhiệm vụ. `M` mở bản đồ nhanh; nhấn lần hai mở bản đồ chi tiết khu vực.

### Quan hệ

- Danh sách NPC dạng chân dung nhỏ, tên, tối đa 10 tim và dấu đã tặng quà trong ngày.
- Trang NPC gồm sinh nhật, lịch sinh hoạt tóm tắt và sự kiện đã xem.
- Sở thích chỉ lộ ra sau khi người chơi khám phá; thông tin chưa biết hiển thị `?`.

### Chế tạo

- Danh sách công thức và bộ lọc theo trạm ở trái; công thức và nguyên liệu ở phải.
- Nguyên liệu có số `có/cần`; đủ dùng màu Lá, thiếu dùng Đỏ kèm số.
- Nút chế tạo ×1, ×5, Tối đa; công thức chưa học hiển thị bóng mờ và gợi ý nơi học.

### Cài đặt

Các nhóm Âm thanh, Điều khiển, Hiển thị, Ngôn ngữ, Trợ năng. Thanh trượt có bước rõ ràng; đổi phím báo trùng; scale hình chỉ nhận giá trị nguyên. Khôi phục mặc định và thoát game đều cần hộp xác nhận an toàn.

## 6. Hội thoại và cửa hàng

### Hội thoại

- Hộp thoại gỗ chạy dọc cạnh dưới, cao khoảng 56 px, không che vùng giữa nơi có nhân vật.
- Chân dung NPC 48×48 ở trái; thẻ tên nhỏ phía trên hộp; màu viền phân biệt vai trò.
- Văn bản tối đa 3 dòng, hiện từng chữ khoảng 30 ký tự/giây. `E` hiện hết dòng; nhấn tiếp để sang trang.
- Lựa chọn 2–4 dòng nằm phía trên hộp và căn phải; mặc định chọn dòng đầu. Dùng số hoặc lên/xuống để chọn.
- Có phụ đề khi bật trợ năng. Giữ `Esc` 0,5 giây để bỏ qua hội thoại không bắt buộc.

### Cửa hàng

Mở qua hội thoại với người bán. Trang giấy có hai cột: hàng của tiệm và túi đồ. Dưới cùng luôn có Xu hiện có, tổng giao dịch, nút Xác nhận và nút Quay lại. Hàng hết hoặc bị khóa theo mùa có trạng thái dễ nhận biết; giá bán là giá thực nhận sau các hiệu chỉnh.

## 7. Hoạt động học tập, câu cá và chiến đấu

### Mini-game học tập

Khung giấy đặt giữa màn hình, nền ngoài tối 55–60%, tạm dừng thời gian. Phần đầu có môn học, 5 chấm tiến độ và bậc khó 1–5 sao. Nội dung câu hỏi và minh họa ở giữa; nút Gợi ý, Bỏ qua tạm, Xác nhận ở dưới.

Hỗ trợ 7 dạng câu: trắc nghiệm, điền khuyết, sắp xếp, nối cặp, nhập số, phân loại kéo-thả, câu đố dạng lưới. Không có đồng hồ đếm giờ mặc định. Đáp án đúng hiện viền Lá và dấu ✓; đáp án sai hiện giải thích trong khung. Ba câu sai liên tiếp gợi ý học lại bài. Kết thúc phiên hiện 1–3 sao, XP tri thức, XP cư dân và phần thưởng ngày.

### Câu đố trong thế giới

Khóa số, bảng chữ, phòng thí nghiệm và mê cung dùng phiên bản thu gọn của cùng khung học tập. Gợi ý có cùng cách gọi ở mọi dạng để người chơi dễ nhận biết.

### Câu cá

- Khi quăng cần, thanh lực nhỏ xuất hiện phía trên nhân vật; vùng chính xác được đánh dấu bằng vàng.
- Phao nhấp nhô; lúc cá cắn hiện dấu `!` rõ ràng và vòng báo thời gian.
- Khi kéo, thanh dọc đặt bên cạnh nhân vật, tự đổi bên nếu sát mép màn hình. Hiện thanh điều khiển, icon cá và tiến độ.
- Kết quả dùng panel nhỏ: icon cá, tên, kích thước, chất lượng sao, XP; cá mới có dấu ghi vào Bách khoa.

### Chiến đấu

- HUD chiến đấu vẫn gọn, giữ HP và hotbar rõ. Thanh máu quái xuất hiện khi bị đánh; tên/cấp hiện khi ngắm.
- Dấu phát hiện và vùng báo đòn dùng hình dạng, icon và màu tương phản; giảm nhấp nháy theo cài đặt trợ năng.
- Sát thương bay lên ngắn: trắng thường, vàng chí mạng, đỏ khi người chơi bị thương.
- Thanh trùm đặt ở giữa phía trên, có tên, biểu tượng tri thức và vạch pha. Câu đố trùm hiển thị gọn bên dưới; giảm tốc độ trận đấu khi trả lời, cho phép tạm dừng hoàn toàn trong tùy chọn trợ năng.

## 8. Màn hình tiêu đề, tải game và tạo nhân vật

### Tiêu đề

Nền parallax bốn lớp: sao, núi, đồi, làng. Logo **Làng Sao Mai** ở gần giữa phía trên. Menu dọc bên trái gồm sáu mục, focus bằng icon sổ tay nhỏ và chữ Vàng. Màn hình phản ánh mùa, giờ và thời tiết của lượt chơi gần nhất.

### Tải game

Ba thẻ save xếp dọc. Mỗi thẻ có ảnh cảnh, tên cư dân, tên nông trại, ngày-mùa-năm và thời gian chơi. Ô trống có lời mời tạo trò chơi mới. Thẻ bị lỗi có màu xám và không cho xóa nhầm; xóa cần xác nhận giữ nút.

### Tạo nhân vật

Bố cục ba cột: xem trước sprite ở trái, tùy chỉnh ngoại hình ở giữa, tên cư dân/nông trại, thú cưng và môn yêu thích ở phải. Cho phép đổi kiểu cơ thể, màu da, tóc, mắt và trang phục. Tên tối đa 16 ký tự, hỗ trợ dấu tiếng Việt. Nút Bắt đầu chỉ sáng khi tên hợp lệ.

## 9. Điều khiển

| Hành động | Bàn phím / chuột | Tay cầm |
|---|---|---|
| Di chuyển | WASD / phím mũi tên | D-pad / cần trái |
| Tương tác | E | A |
| Dùng công cụ | J / chuột trái | X |
| Hành động phụ | K / chuột phải | Y |
| Ăn / dùng vật phẩm | F | B giữ |
| Chạy | Giữ Shift | Giữ LT |
| Né / lướt | Space | RT |
| Chọn hotbar | 1–0, -, =, cuộn chuột | LB/RB, D-pad |
| Sổ tay / nhật ký / bản đồ | Tab hoặc I / Q / M | Start / Select / L3 |

Icon phím tự đổi theo thiết bị đang dùng. Mọi màn hình có focus ban đầu hợp lý; `Esc` hoặc B luôn là quay lại. Chuyển đổi chuột/tay cầm không làm mất focus.

## 10. Trợ năng

- Cỡ chữ 8, 10, 12 px; mỗi mức có bố cục riêng, không phóng to mờ.
- Chế độ mù màu dùng họa tiết và icon kèm màu.
- Tùy chọn giảm rung, giảm nhấp nháy, tương phản cao và phụ đề âm thanh quan trọng.
- Câu hỏi học tập không giới hạn giờ. Có tùy chọn tạm dừng khi chọn đáp án trong trận trùm.
- Mọi hành động có thể đổi phím; hỗ trợ nhấn hoặc giữ.
- Bản dịch dài hơn 20% vẫn phải vừa nút/panel, tự xuống dòng hợp lý.

## 11. Quy ước triển khai Godot

- Một `ui_theme.tres` dùng chung cho panel 9-slice, font, nút, thanh trượt và ô nhập.
- CanvasLayer: HUD 10, Menus 20, Dialogs 30, Minigames 40, Transitions 100, Debug 128.
- UIStack quản lý mở/đóng menu và hội thoại; gửi `time_pause_requested` đến GameClock.
- Dùng EventBus cho tín hiệu UI như `ui_opened`, `ui_closed`, `item_slot_clicked`.
- Scene UI đặt tên khớp script. Widget phải hỗ trợ normal, hover/focus, pressed, disabled và nội dung dài.
- Có `ui_gallery.tscn` để xem các trạng thái ở scale nguyên và kiểm tra layout.

## 12. Lộ trình dựng

| Mốc | Thành phần | Điều kiện hoàn thành |
|---|---|---|
| M0 | Theme, font tiếng Việt, panel, nút, gallery | Chạy đúng ở 320×180 và scale nguyên |
| M2 | HUD, giờ, lịch, thời tiết, hotbar | Không che nhân vật; cập nhật đúng theo GameClock |
| M3 | Sổ tay, túi đồ, tooltip, trang bị | Kéo-thả, chia chồng và điều khiển tay cầm hoạt động |
| M5 | Tương tác thế giới, biển hiệu, bản đồ | Gợi ý không chồng nhau và luôn ở trong màn hình |
| M6–M7 | Hội thoại, cửa hàng, quan hệ, nhiệm vụ | Chữ tiếng Việt đủ dấu, lựa chọn điều khiển được |
| M8 | HP, quái, trùm, cảnh báo | Đọc được trong cảnh đông, không che nhân vật |
| M10 | Câu cá | Các bước thao tác phân biệt rõ |
| M11 | Khung học tập và 7 dạng câu | Thêm dạng câu mới mà không phá khung chung |
| M12–M13 | Tiêu đề, save, tạo nhân vật, tổng kết, trợ năng | Đạt kiểm tra cỡ chữ, tương phản và điều khiển |

## 13. Danh sách asset giao diện tối thiểu

| Nhóm | Số lượng ban đầu |
|---|---:|
| Panel 9-slice | 4 kiểu × thường / focus / cảnh báo |
| Nút | 3 kích thước × 5 trạng thái |
| Icon 16×16 cho tab, kỹ năng, tri thức | Khoảng 40 |
| Icon trạng thái 12×12 | Khoảng 24 |
| Icon nhỏ 8×8: Xu, tim, thời tiết, phím | Khoảng 60 và bộ icon tay cầm |
| Chân dung NPC | 12 nhân vật × 4 biểu cảm |
| Font bitmap | 8, 10, 12 px có dấu tiếng Việt; số 5×7 |
| Hiệu ứng | Sao, lên cấp, sát thương, vòng tiến trình, nhặt vật phẩm |

## 14. Tiêu chí kiểm tra giao diện

- Người chơi nhận ra giờ, tiền, nhiệm vụ đang ghim, HP, thể lực và vật phẩm chọn trong một lần nhìn nhanh.
- Phần giữa màn hình luôn ưu tiên thế giới và nhân vật.
- Menu, hội thoại, cửa hàng và mini-game dùng chung ngôn ngữ gỗ/giấy nhưng phân biệt được chức năng.
- Nội dung tiếng Việt, gồm dấu và câu dài, không bị cắt khỏi nút hoặc panel.
- Tất cả chức năng chính dùng được bằng bàn phím, chuột và tay cầm.
- Hình ảnh giữ pixel sắc nét ở mọi scale hỗ trợ; không có thành phần UI dựa vào màu đơn lẻ để truyền trạng thái.

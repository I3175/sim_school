# LÀNG SAO MAI — ĐẶC TẢ TOÀN BỘ THẾ GIỚI GAME

**World Design Bible / World Art & Level Specification — Bản bổ sung GDD v1.1**  
**Dự án:** Làng Sao Mai — RPG nông trại 2D top-down, khám phá, giải đố và học tập  
**Nền tảng thiết kế:** Godot 4.3+, GDScript, viewport gốc 320×180, tile 16×16, nhân vật 16×32, 60 FPS  
**Đầu vào:** (1) *Game Design Document & Master Prompt v1.0*; (2) *Đặc tả thiết kế giao diện*; (3) sáu bảng minh họa do người dùng cung cấp.  
**Trạng thái:** Bản đặc tả **bổ sung** để làm world map, level, môi trường, art asset, NPC, sự kiện và sản xuất. Không tự sửa các quy tắc nền của GDD.

> **Quy ước nguồn gốc**
> - **[GDD]**: đã được quy định trong Game Design Document; giữ nguyên khi triển khai.
> - **[UI]**: đã được quy định trong tài liệu giao diện.
> - **[HÌNH]**: chi tiết nhìn thấy ở sáu bảng minh họa, dùng làm chuẩn định hướng hình ảnh, không mặc nhiên là dữ liệu gameplay.
> - **[MỚI — ĐỀ XUẤT]**: phần viết thêm để lấp chỗ trống; chỉ trở thành nguồn sự thật sau khi được chấp thuận.
> - **[CẦN CHỐT]**: mâu thuẫn hoặc quyết định còn mở; không tự ý hợp nhất vào dữ liệu chính thức.

---

## 0. TÓM TẮT THẾ GIỚI VÀ RANH GIỚI ĐẶC TẢ

### 0.1 Trải nghiệm cốt lõi

**Làng Sao Mai là một ngôi làng sống được, không phải chỉ là bản đồ nối giữa các cửa sổ UI.** Buổi sáng người chơi nghe gà gáy ngoài nông trại, tới chợ mua giống, ngang qua trường học nghe tiếng trống, ghé bờ hồ câu cá, tối trở về trong ánh đèn vàng; sau đó dần khám phá vì sao những cuốn sách mất chữ, rừng xuất hiện Ma Sương, và năm Mảnh Sao bị phân tán. [GDD]

Mỗi vùng phải thỏa mãn ba tầng mục đích:

1. **Nơi chốn:** có địa hình, kiến trúc, âm thanh và vòng sinh hoạt nhận diện tức thì.
2. **Hoạt động:** có tối thiểu một vòng chơi 1–3 phút và một mục tiêu quay lại dài hạn.
3. **Ý nghĩa:** chứa ký ức, NPC, cơ chế tri thức hoặc dấu vết cốt truyện; không phải vùng trống chỉ để đi ngang.

Người chơi có thể tập trung vào nông nghiệp, quan hệ, nghề, sưu tầm và giải đố mà không bị ép chiến đấu liên tục. Học tập trợ giúp mở đường nhưng không khóa cứng mạch truyện. [GDD]

### 0.2 Phạm vi phiên bản này

- **11 bản đồ ngoài trời/chức năng chính** theo đúng danh sách GDD (Hầm Đá gồm 40 tầng). [GDD]
- **Hệ thống nội thất** của nhà, cửa hàng, lớp học, thư viện, chuồng, trạm chế tạo, đài thiên văn. [GDD + MỚI]
- **4 mùa, 7 ngày/mùa, 28 ngày/năm**; giờ hoạt động, thời tiết, vòng sống NPC và động vật. [GDD]
- **12 NPC chính**, sinh vật hoang, vật nuôi, quái Quên, 5 Bóng Quên và trùm cuối. [GDD]
- Quy tắc **mỹ thuật môi trường, thiết kế level, tương tác, dữ liệu, asset, QA** có thể triển khai bằng Godot. [MỚI — ĐỀ XUẤT]

**Không bao gồm:** thay thế GDD bằng lore mới, thêm hệ thống cốt lõi mới, đổi giá vật phẩm, đổi tiến độ chương, đổi chỉ số đã ghi trong GDD.

### 0.3 Sáu bảng hình được dùng như thế nào

| Bảng minh họa | Tính chất | Hệ quả cho đặc tả thế giới |
|---|---|---|
| 1 — Tiêu đề / tải / tạo nhân vật | Toàn cảnh làng, núi xanh, hoa đào, gỗ, mặt trời mọc | Khóa ngôn ngữ phong cảnh nông thôn ấm áp; quy tắc cảnh nền parallax và nhận diện thế giới |
| 2 — Hội thoại / cửa hàng / mini-game | Phố nhỏ, mái tranh, cây hoa, hàng rào, NPC | Khóa phong cách kiến trúc dân dã, đường đi đủ rộng để hội thoại, cửa hàng có không gian giao dịch |
| 3 — Chế tạo / cài đặt | Cảnh làng lúc tối, đèn lồng, vật liệu gỗ–giấy | Định hướng nhà/xưởng ban đêm, lò rèn có ánh lửa, đồ gỗ có silhouette dễ đọc |
| 4 — Bách khoa / bản đồ / quan hệ | Bản đồ vẽ tay, vùng nước, rừng, núi, địa danh | Hình bản đồ thế giới là đồ họa sổ tay; tên địa danh trong hình là **tham khảo hình ảnh**, không thay thế tên trong GDD |
| 5 — Túi đồ / kỹ năng / nhiệm vụ | Tranh nông trại, NPC, vật phẩm 16×16 | Tính nhất quán đồ vật trong thế giới với icon, sprite cầm tay, biểu tượng nhiệm vụ |
| 6 — Gameplay / chiến đấu / câu cá | Nông trại, lối làng, ao sen, nhà mái tranh, HUD | Khóa bố cục top-down ¾ nhìn từ trên, tâm nhìn ưu tiên nhân vật, thế giới sống phía dưới HUD |

**Lưu ý art:** các bảng minh họa có độ chi tiết và chữ lớn nhằm giải thích thiết kế. Tài sản đưa vào game phải được **vẽ lại trên lưới pixel thực**; không cắt trực tiếp hình bảng UI thành tileset rồi thu nhỏ, vì sẽ vỡ tỉ lệ, mất kiểm soát va chạm và khó animation. [MỚI — ĐỀ XUẤT]

---

## 1. WORLD BIBLE — BỐI CẢNH, BẢN SẮC VÀ KÝ ỨC

### 1.1 Câu chuyện địa phương

[GDD] Làng Sao Mai nằm giữa năm ngọn đồi. Hàng trăm năm trước, cư dân dựng **Ngôi Sao Tri Thức** ở đài thiên văn. Khi ngôi sao vỡ thành năm **Mảnh Sao** — Số, Chữ, Ngữ, Vật, Ký — Màn Sương Quên khiến những tri thức và kỹ năng của làng dần bị phai nhạt. Quái Quên là biểu hiện vật chất của những ký ức bị xóa. Người chơi thừa hưởng **Nông Trại Mầm Xanh** và một cuốn **Sổ Tay Tri Thức** tự đầy lên nhờ khám phá.

[MỚI — ĐỀ XUẤT] Thể hiện truyền thuyết qua môi trường thay vì lời kể dài:

- Tranh tường và hoa văn ngôi sao năm cánh xuất hiện kín đáo tại trường, thư viện, mỏ, bến cảng và đài thiên văn; mỗi nơi thiếu một nét ký hiệu.
- Vùng an toàn mang dấu hiệu **tri thức được chăm sóc**: sách mở, bảng ghi chép, cây thẳng hàng, biển đường rõ chữ.
- Vùng bị Sương Quên chạm tới mang dấu hiệu **thông tin suy yếu**: biển mờ chữ, trang giấy bay, dấu chân lặp, đèn lạc nhịp, bản đồ rách góc.
- Sau khi người chơi lấy Mảnh Sao, môi trường cải thiện có chọn lọc: một biển được đọc lại, một cửa mở, NPC nhớ lại công thức, không biến thế giới thành phông nền hoàn toàn khác.

### 1.2 Ba lớp cảm xúc của hành trình

| Lớp | Nơi điển hình | Cảm giác | Nguyên tắc trình bày |
|---|---|---|---|
| **Mái nhà** | Nông trại, Đồng Cỏ, Phố Chợ | Có thể về, ấm, quen thuộc | Màu kem–nâu–xanh; đường thấy rõ; tiếng người và gia súc |
| **Làng học hỏi** | Quảng Trường, Trường, Thư Viện, Hồ | Tò mò, kết nối, sáng tạo | Bố cục dẫn mắt về bảng tin, sách, cầu, hiện vật; nhiều tương tác không chiến đấu |
| **Vùng ký ức thất lạc** | Rừng, Mỏ, Núi, hầm sách, khu boss | Huyền bí nhưng không kinh dị | Tương phản sáng/tối có kiểm soát; biểu tượng tri thức luôn tạo lối về |

### 1.3 Ngôn ngữ Việt trong thiết kế

[HÌNH] Ưu tiên mái tranh hoặc ngói đất nung, cổng gỗ, hàng rào tre/gỗ, hiên nhà, giếng, chậu hoa, đèn lồng, ruộng chia luống, đường đá–đất, ao sen, mây núi xanh phía xa. [MỚI — ĐỀ XUẤT] Thẩm mỹ là **làng quê Việt hư cấu**: ấm, có tính kể chuyện, không rập khuôn nguyên mẫu địa lý, không dùng biểu tượng văn hóa thiêng một cách tùy tiện.

**Bộ dấu hiệu thị giác chung:** năm cánh sao (tri thức), hình lá/mầm (trồng trọt), mái nhà chữ A (cộng đồng), đường nước cong (thư thái), giấy ngả kem (ký ức được lưu giữ). Mỗi khu vực chỉ dùng 1–2 biểu tượng làm chủ đạo để không quá dày đặc.

---

## 2. ĐỊA LÝ, KẾT NỐI VÙNG VÀ HƯỚNG KHÁM PHÁ

### 2.1 Đồ thị kết nối chính thức

[GDD] Giữ nguyên các vùng và trục kết nối đã mô tả ở GDD mục 5.1:

```text
                        [Núi Mây]
                            |
[Rừng Thì Thầm] — [Đồi Thư Viện] — [Hồ Gương & Sông Bạc]
        |                   |                   |
[Hầm Đá Thì Thầm]    [Quảng Trường] ─── [Bãi Biển Sóng Vàng]
                       /         \
              [Phố Chợ]      [Trường Ánh Dương]
                  |
           [Nông Trại Mầm Xanh]
                  |
           [Đồng Cỏ Cỏ Xanh]
```

*Bản đồ chữ là sơ đồ kết nối, không định nghĩa tọa độ tuyệt đối. GDD còn cho Nông Trại một lối tắt trực tiếp vào Rừng, mở sau chương 1. Vị trí kết nối Phố Chợ/Nông Trại và lối đi Quảng Trường/Bãi Biển sẽ phải được kiểm tra với sơ đồ gốc khi dựng `MapPortal`.*

### 2.2 Danh sách 11 map nền

| `map_id` | Tên chính thức [GDD] | Kích thước tile [GDD] | Vai trò / chủ đề | Trạng thái ban đầu |
|---|---|---:|---|---|
| `farm_main` | Nông Trại Mầm Xanh | 80×60 | Nhà, canh tác, nâng cấp | Mở |
| `ranch` | Đồng Cỏ Cỏ Xanh | 60×44 | Chăn nuôi, bãi cỏ | Mở vùng; cửa hàng sau Ch1 |
| `market_street` | Phố Chợ | 56×32 | Mua bán, chữa bệnh, nghề thủ công | Mở |
| `town_square` | Quảng Trường Sao Mai | 64×48 | Trung tâm xã hội, nhiệm vụ, lễ hội | Mở |
| `school_grounds` | Trường Ánh Dương | 48×36 | Toán, khoa học, hoạt động học | Mở sân; lớp sau Ch1 |
| `library_hill` | Đồi Thư Viện | 40×32 | Ngữ văn, ký ức, bảo tàng | Mở; hầm sách Ch3 |
| `whispering_forest` | Rừng Thì Thầm | 90×70 | Hái lượm, mối nguy, bí ẩn | Sau Ch1 |
| `stone_mine` | Hầm Đá Thì Thầm | 40 tầng × 40×30 | Khoáng sản, đố cơ khí, boss | Ch1 và cấp Cư Dân ≥3 |
| `mirror_lake` | Hồ Gương & Sông Bạc | 60×44 | Câu cá, nước, cầu | Mở |
| `golden_beach` | Bãi Biển Sóng Vàng | 70×40 | Biển, thủy triều, ngoại ngữ | Sau sửa cầu Hồ Gương |
| `cloud_mountain` | Núi Mây | 80×80 | Leo núi, sử–địa, đài thiên văn | Ch5 và cấp Cư Dân ≥8 |

### 2.3 Nguyên tắc định hướng và nhịp di chuyển [MỚI — ĐỀ XUẤT]

- Mỗi map có **một landmark cấp vùng** (nhà lớn, tháp, cây cổ thụ, thác, giếng, đỉnh núi) và **hai landmark cấp đường đi** (cầu, biển chỉ đường, cổng, cụm hoa khác màu).
- Trong vòng 3–6 giây kể từ khi vào cổng, người chơi phải nhận ra khu vực qua silhouette và âm nền, dù HUD bị ẩn.
- Các đường chính rộng tối thiểu **2 tile trống hữu dụng**; gần điểm NPC thường đứng, cổng ra vào và tương tác quan trọng nên ưu tiên 3 tile để tránh tắc nghẽn. Đây là **mục tiêu thiết kế level**, chưa phải thông số GDD.
- Cảnh nhiều chi tiết tập trung ở mép đường, không phủ vật trang trí lên điểm tương tác, ô câu cá, bậc thang hay nút cửa.
- Luồng trở về luôn có dấu hiệu: cổng gỗ chung, biển tên vùng, hoặc lối đá dẫn ra; không được tạo nhánh một chiều gây kẹt trước khi có bản đồ.
- Khám phá theo cấu trúc **trục an toàn → nhánh tài nguyên → bí mật có điều kiện**, thay vì một mê cung ngẫu nhiên cho tất cả vùng.

### 2.4 Cổng vùng và mở khóa [GDD + MỚI]

Mọi liên kết dùng `MapPortal` (`Area2D` layer `trigger`) với `target_map_id`, `target_spawn_id`, `unlock_conditions[]`. Thời gian tiếp tục chạy khi đổi map; fade-out 0,25 giây và fade-in 0,25 giây. [GDD]

[MỚI — ĐỀ XUẤT] Bổ sung `portal_id`, `return_portal_id`, `approach_facing`, `unlock_hint_key`, `camera_entry_mode`, `transition_sfx`, `enabled_weather_flags`, `safe_spawn_radius_tiles`. Với mỗi cổng phải có cặp spawn hai chiều và kiểm tra spawn không chồng vật thể. Cửa bị khóa cho đọc lời nhắc ngắn thay vì im lặng.

---

## 3. ART BIBLE — QUY CHUẨN MÔI TRƯỜNG PIXEL ART

### 3.1 Khung hình thực thi

| Thuộc tính | Quy tắc |
|---|---|
| Viewport & tỷ lệ | **320×180**, 16:9 [GDD/UI] |
| Grid thế giới | **16×16 px/tile** [GDD/UI] |
| Sprite người/NPC | **16×32 px**, gốc sắp chiều sâu ở chân [GDD] |
| Quái | Nhỏ 16×16, vừa 24×24, lớn 32×32, boss từ 48×48 [GDD] |
| Lọc ảnh | **NEAREST**, không mipmap, không để sprite lọt nửa pixel [GDD/UI] |
| Hiển thị | Scale nguyên khi có thể, không làm mờ pixel [GDD/UI] |
| Mặt nhìn | Top-down ¾ cách điệu: thấy mặt trước nhà, mép mái, nền đất và phía trên vật trang trí [HÌNH + MỚI] |
| Chiều sâu | Y-Sort thực thể; thân cây, mái nhà có lớp chồng và vùng mờ khi người chơi đi phía sau [GDD] |

### 3.2 Quy tắc màu môi trường [MỚI — ĐỀ XUẤT]

Không áp bảng màu UI lên môi trường một cách máy móc. Dùng UI làm *màu hòa hợp*: viền mực `#2B1B17`, giấy `#F4E4BC`, gỗ tối `#5A3A2A`, vàng nhấn `#F2C14E`, xanh lá `#6DB04A`. [UI]

| Vùng cảnh quan | Màu đề xuất | Tác dụng |
|---|---|---|
| Cỏ xuân sáng | `#8FCB72`, `#5FA65B` | Nền sống, dễ đọc đường |
| Cỏ đậm / rừng | `#4D8A5B`, `#315B49` | Tăng chiều sâu |
| Đất / luống | `#B07A4E`, `#785036` | Phân biệt đã cuốc/đã tưới |
| Đường đá | `#C9B48F`, `#9A917C` | Dẫn mắt, ít cạnh sắc |
| Mái ngói | `#C97859`, `#8E493E` | Hồn làng, landmark |
| Mái tranh | `#E4BC74`, `#A57C47` | Nông trại, xưởng, sạp |
| Nước hồ | `#67B8C8`, `#347C9C` | Mát, trong |
| Hoa đào | `#F5A0BE`, `#D977A1` | Dấu hiệu mùa Xuân |
| Ánh đèn | `#FFD27C`, `#E8A15A` | An toàn trong cảnh đêm |
| Sương Quên | `#9185B9`, `#555174` | Vùng ký ức bất thường |

Mỗi map cần một **palette môi trường ban ngày** và một bộ LUT/CanvasModulate theo pha giờ. Không vẽ riêng mọi object cho mọi giờ; chỉ vật thể phát sáng và trạng thái mùa cần sprite độc lập.

### 3.3 Kiến trúc, vật liệu và tỷ lệ [HÌNH + MỚI]

**Nhà dân:** mái tranh/ngói đỏ dốc; tường vôi kem hoặc ván gỗ; cửa 1–2 tile, hiên thấp, bậc đá; cửa sổ sáng khi đèn bật. **Công trình công cộng:** mái lớn hơn, cổng nhận diện bằng biểu tượng sách, trống trường, búa rèn, cây thuốc hoặc sao. **Cấu trúc nông trại:** rào 1 tile, cổng 2 tile, hàng luống thẳng, nhà kho thô mộc, giếng đá, máng nước.

[GDD] Kích thước ngoại thất mẫu: nhỏ 4×4 tile, vừa 6×5 tile, lớn 9×7 tile; dùng `BodySprite`, `RoofSprite`, `DoorPortal`, `CollisionPolygon2D`, `SignLabel`, `LightPoints` và một ô đứng trống trước cửa. [MỚI] Với kiến trúc đặc biệt lớn có thể ghép module phụ, nhưng cửa/điểm chân và va chạm vẫn theo chuẩn này.

### 3.4 Lớp đồ họa đề xuất

```text
WorldMap
├── GroundBase             # cỏ, đất, đá nền
├── GroundDetails          # cánh hoa rơi, sỏi, vết xe, chấm cỏ
├── Water                  # tile nước động, bờ
├── TerrainSolid           # mép vực, bờ cao, tường đá
├── BackDecoration         # bụi thấp, biển đặt phía sau nhân vật
├── BuildingBacks          # chân tường, hàng rào sau
├── YSortedWorld           # Player, NPC, animal, monster, furniture, trunks
├── BuildingFronts         # mái và phần che trước có xử lý alpha
├── CanopyOverlay          # tán cây, lá che, đèn cao
├── EnvironmentalFX       # bóng, nước, bụi, lá, mưa, tuyết
└── SpawnAndTriggerNodes   # portal, điểm NPC, vùng câu cá, tương tác
```

Đây là mẫu cấu trúc **mở rộng**, không thay đổi các layer vật lý đã có trong GDD.

### 3.5 Nguyên tắc bố cục cảnh [MỚI]

1. Một màn hình điển hình có **60% khoảng trống đọc được** (đường, nước, ruộng, sân), 25% cụm vật thể lớn và 15% chi tiết nhỏ; là mục tiêu thẩm mỹ, không phải luật cứng.
2. Trang trí hoa/đá dùng **cụm bất đối xứng** 2–5 object; tránh rải đồng đều tạo nhiễu.
3. Cầu, rìa vực, bậc thang, bến câu và cây cần chặt phải có silhouette tách khỏi nền từ màn hình scale 2×.
4. Ánh sáng trong bóng râm giảm bão hòa thay vì biến cả cảnh thành một mảng đen; hành động quan trọng không phụ thuộc chỉ vào sắc màu.
5. Các đối tượng xa như núi, nhà nhỏ phía chân trời trong bảng minh họa chỉ đưa vào **background/parallax**; nhân vật không thể đi tới nếu chưa có map thật.

---

## 4. QUY TẮC THẾ GIỚI CHẠY THEO THỜI GIAN

### 4.1 Đồng hồ, mùa và ngủ [GDD]

- 1 ngày game = 1.440 phút game = **240 phút thực**; 1 giờ game = 10 phút thực.
- Ngày chơi bắt đầu **06:00**, ngủ muộn nhất **02:00 hôm sau**; quãng 02:00–06:00 được bỏ qua khi ngủ.
- 1 mùa 7 ngày, năm 4 mùa: Xuân → Hạ → Thu → Đông; Chủ Nhật/ngày 7 của mỗi mùa là ngày lễ.
- Thời gian tạm dừng khi mở menu, hội thoại, cutscene và màn học/đố; **vẫn chạy** khi ở nhà, câu cá, chiến đấu, đi qua cổng map.
- HUD giờ hiển thị theo bước 10 phút game, chuyển pha ánh sáng nội suy liên tục.

### 4.2 Bốn mùa tác động đến *cả* thế giới [GDD + MỚI]

| Mùa | Phong cảnh & thời tiết [GDD] | Thay đổi môi trường cần vẽ [MỚI] | Tương tác cần test |
|---|---|---|---|
| **Xuân** | Cỏ xanh non, hoa hồng đào, suối đầy; nắng/mưa phùn | Cành đào 2–3 biến thể, vũng nước mỏng, cánh hoa bay nhẹ, mái rêu sáng | Mưa tưới đất, xuất hiện hoa Xuân và cây Xuân |
| **Hạ** | Lá rậm, nắng vàng, hồ lấp lánh, nóng/giông | Tán cây phủ rộng, sen nở, đom đóm đêm, bóng cây rõ | Nắng gắt làm đất khô; câu cá/động vật đổi nhịp |
| **Thu** | Lá cam đỏ, nấm, mưa, gió | Lá rụng dưới gốc, đường đất có lá, giàn quả vàng; luống thu hoạch | Hái hạt dẻ, nấm; Hội Gặt và Trăng Tròn |
| **Đông** | Tuyết, cành trơ, băng và bão tuyết | Rìa mái có tuyết, bậc đi trơn, tuyết trên cọc gỗ; cửa sổ vàng nổi bật | Hồ đóng băng; áo ấm; cây trái mùa héo |

[MỚI] **Thứ tự layer thay mùa:** `seasonal_ground_tiles → object_variants → snow/wetness overlay → light_phase → weather particles → special effects → interactable indicators`. Đúng nguyên tắc `MapStateData` trong GDD.

### 4.3 Thời tiết, điều kiện đặc biệt [GDD]

Lưu/đọc thời tiết qua `WeatherSystem` có seed `hash(world_seed, year, season, day)`, dự báo ngày mai đúng 90%, ba ngày đầu và lễ hội nắng, không có hai ngày thời tiết nặng liên tiếp; một ngày tối đa hai đoạn chuyển thời tiết. Các điều kiện nổi bật: **Giông sét, Sương Quên, Nóng gay gắt, Bão tuyết, Gió lớn mùa Thu, Mưa sao băng, Trăng Tròn ngày 4, Cầu vồng, Lễ hội ngày 7**.

[MỚI] Mỗi thời tiết cần **bốn lớp phản hồi**: (a) hình ảnh, (b) âm thanh, (c) NPC/sinh vật, (d) gameplay. Ví dụ trời mưa: mái nhỏ giọt, âm mưa và ếch, NPC che ô/chuyển lịch, đất tự ướt và cá cắn câu nhiều hơn. Không chỉ thay particle.

### 4.4 Vòng sống môi trường [MỚI — ĐỀ XUẤT]

- **06:00:** chạy cập nhật nông trại, spawn tài nguyên hái lượm, reset quái theo GDD, tính động vật, làm mới nhiệm vụ và bảng tin.
- **Theo giờ game:** chuyển pha ánh sáng, mở/đóng cửa, đổi NPC theo lịch, phát đèn, cập nhật thủy triều và môi trường.
- **Khi quay lại map:** mọi vật thể có `persistent_id` giữ trạng thái, nhưng đối tượng trang trí chỉ cần nội suy dựa trên `MapStateData`.
- **Mỗi đêm sau lưu:** dọn vật phẩm rơi hết ngày theo GDD, lưu biến đổi đất/đồ đặt/hộp chứa; không reset lén vật phẩm người chơi sở hữu.

---

## 5. HỒ SƠ CHI TIẾT 11 KHU VỰC

> Các **tên, kích thước, mở khóa, quy luật đã có** giữ nguyên từ GDD. Những bố cục không gian, cách bài trí và điểm quay hình dưới đây là **[MỚI — ĐỀ XUẤT]** để họa sĩ/level designer có thể dựng map.

### W01 — NÔNG TRẠI MẦM XANH (`farm_main`, 80×60)

**Vai trò [GDD]:** Nhà chính người chơi, 24×16 ô đất canh tác, giếng, hòm gửi hàng, silo, chuồng gà/bò, nhà kính, bãi đá/gốc cây cần dọn; không có quái ban ngày, chỉ vài quái nhẹ vào đêm Trăng Tròn. Nằm trên tuyến đường tới Phố Chợ, Đồng Cỏ và lối tắt Rừng sau Ch1.

**Bố cục [MỚI]:**

- **Tây-bắc:** nhà chính và khoảng sân đón người chơi, hòm thư, chậu hoa, ghế gỗ; góc máy đầu trò nhìn được mái nhà, cửa, thùng đồ và khoảng đất trống.
- **Giữa:** cụm đất canh tác 24×16 ô, chia vùng thị giác bằng bờ đất/lối nhỏ; đặt giếng trong tầm nhìn từ ruộng để việc tưới không bắt người chơi đi vòng khó chịu.
- **Đông:** không gian xây chuồng, máng và hàng rào; để đủ khoảng trống nâng cấp hoặc tự sắp xếp theo GDD.
- **Nam:** bãi cỏ và đường ra Đồng Cỏ; có bảng chỉ hướng dễ nhận diện.
- **Bắc:** dải cây tự nhiên, gốc lớn/đá làm mục tiêu dọn đất; lối tắt Rừng có biển gỗ cũ, mở sau Ch1.

**Landmark:** nhà mái ngói/khung gỗ có hiên, giếng tròn, ruộng thành dải thẳng và một cây đào nở hoa gần cổng (hoa biến thể theo mùa). **Màu:** xanh lá–đất nâu–hồng đào, tương phản vàng kem. **Âm:** chim, gà, ve mùa Hạ, mưa trên mái, tiếng cuốc. [HÌNH + MỚI]

**Tương tác và vòng chơi:** cuốc → gieo → tưới → chăm → thu hoạch → bán; đặt hàng rào và máy; chữa đất, chăn nuôi, nấu, học ở bàn; ngủ, lưu. Không để cây trang trí tự nhiên chiếm các ô dự kiến mở rộng nhà hoặc chặn lối tới hòm gửi hàng. [GDD + MỚI]

**Thay đổi theo chương:** Ch0 chỉ một phần đất sạch; Ch1 có nhánh rừng; Ch4 có nhà kính mở; từ cấp 12 có điều kiện xây nhà kính theo GDD. **Chú ý [CẦN CHỐT]:** GDD ghi nhà kính mở sau chương 4 và cấp Cư Dân 12; UI phải hiển thị rõ nếu cần đồng thời cả hai.

**Cảnh mẫu / screenshot mục tiêu:** bình minh với nhân vật tưới hàng rau, nhà mái tranh/ngói bên trái, lối làng hướng ra trung tâm, ao sen nhỏ/đường đá ở rìa cảnh; HUD gọn như bảng hình 6, nhưng đồ vật chiếm kích thước tile thật. [HÌNH]

### W02 — ĐỒNG CỎ CỎ XANH (`ranch`, 60×44)

**Vai trò [GDD]:** trại cô Mai, bãi chăn thả, chuồng mẫu, bảng giá động vật. Vùng đi vào từ đầu, dịch vụ mua vật nuôi mở sau Ch1. Cỏ mọc lại 1 ô/ngày trong Xuân–Hạ–Thu, nhanh gấp đôi khi mưa, chết dần vào Đông.

**Bố cục [MỚI]:** lối vào phía nông trại → nhà cô Mai và cổng bán vật nuôi → đồng cỏ chính mở rộng → ao nhỏ dành cho vịt và cụm bóng cây; chuồng mẫu nằm ở cạnh trên để người chơi nhìn động vật từ ngoài rào. Có một khu tương tác **giáo trình nuôi vật** (biển hỏi về ăn, nước, nhiệt độ) nhưng không ép kiểm tra để mua vật.

**Landmark:** hàng rào liên tục, vòng cỏ vàng, cối xay gió nhỏ hoặc mái che thức ăn **chỉ để trang trí nếu chưa có công năng**. **Cư dân:** cô Mai; động vật gà, vịt, bò/dê/cừu theo tiến độ. **Âm:** tiếng chuông nhỏ, bước chân trên cỏ, gió, gia súc. **Thay mùa:** rực xanh Xuân/Hạ, cỏ vàng Thu, mái chuồng và hàng rào phủ tuyết Đông. **Rủi ro:** đường đi không được để động vật gây bít cổng; chúng có vùng đi riêng.

### W03 — PHỐ CHỢ (`market_street`, 56×32)

**Vai trò [GDD]:** Tiệm tạp hóa của **Dì Năm**, Lò rèn **Chú Ba**, Phòng khám **Bác sĩ Minh**, Quán Hương Lúa **Chị Vy**, các sạp ngoài trời. Tiệm tạp hóa 09:00–19:00, nghỉ Chủ Nhật; lò rèn 10:00–17:00, nghỉ Thứ Bảy; phòng khám 08:00–16:00 (cấp cứu 24/7); Quán Hương Lúa 11:00–22:00. Ngày lễ đóng cửa thường. [GDD]

**Bố cục [MỚI]:** đường đất/đá dài theo trục ngang; đầu phố là biển gỗ tới Quảng Trường, phía còn lại dẫn về Nông Trại. Tòa nhà đặt so le để mái không che biển hiệu. Tiệm hạt giống gần hướng nông trại; lò rèn có ống khói và sân đặt phôi; quán ăn có hiên, bàn ngoài trời; phòng khám có bảng cây thuốc. Các sạp mở thành một dải vào ngày chợ phiên.

**Landmark:** dãy mái ngói đất, dây vải phơi, chậu hoa, đèn lồng đỏ-vàng, luồng khói mềm từ lò rèn. **Âm:** tiếng rao nhỏ, tiếng bước chân, búa gõ, chảo xèo, nhạc jazz nhẹ theo GDD. **Hệ thống thế giới:** lịch mở cửa làm thay đổi **cửa sổ/biển quầy/đám đông**; không chỉ khóa nút mua. Các sạp đóng khi bão tuyết. **Gắn tri thức Số:** bảng giá và nhiệm vụ tính tiền thối. [GDD + MỚI]

**Lưu ý:** hình 2 ghi “Cửa Hàng Bà Tư”; theo GDD **Bà Tư là thủ thư**. Không đổi tên NPC chủ tiệm nếu chưa duyệt mục [CẦN CHỐT].

### W04 — QUẢNG TRƯỜNG SAO MAI (`town_square`, 64×48)

**Vai trò [GDD]:** tâm điểm làng, đài phun nước, bảng nhiệm vụ ngày, bảng dự báo thời tiết, ghế đá, sân khấu ngày lễ. NPC thường hẹn nhau ở đây, đài phun đóng băng mùa Đông.

**Bố cục [MỚI]:** trục đi bộ hình vòng quanh đài phun; **bảng nhiệm vụ** đặt ở một cạnh của vòng, dễ tiếp cận dù người chơi đến từ Phố Chợ, Trường hoặc Đồi. Khu lễ hội chừa sân trống và điểm dựng gian hàng bằng `event_overlay`. Rìa quảng trường có bồn hoa bốn mùa, cột đèn, ghế cho NPC ngồi, đường lát đá định hướng 4 cổng.

**Landmark:** bồn nước và phù điêu ngôi sao (phiên bản dân gian), sân khấu có cờ giấy khi lễ hội. **Âm:** accordion, nước róc rách, tiếng chợ xa, người chuyện trò. **Tương tác:** nhận 3 nhiệm vụ Hàng ngày mới lúc 06:00, kiểm tra dự báo, gặp NPC, nhận lời mời dự lễ. **Thời tiết:** khi mưa, NPC trú hiên; khi tuyết, bồn nước đóng băng; ngày hội phải có biến thể bề mặt/ánh sáng gian hàng.

**Cảnh kiểm thử:** từ bất kỳ cổng nào phải nhìn được một phần đài phun hoặc đường dẫn về nó trong một màn hình; không để UI bảng nhiệm vụ che đầu NPC chính.

### W05 — TRƯỜNG ÁNH DƯƠNG (`school_grounds`, 48×36)

**Vai trò [GDD]:** sân trường, lớp học, phòng thí nghiệm, vườn thực nghiệm, sân bóng, phòng hiệu trưởng. Giờ học 08:00–10:00 và 14:00–16:00 trong ngày thường; cuối tuần lớp đóng, sân mở. Lớp mở sau Ch1.

**Bố cục [MỚI]:** ngoại thất chữ U với sân chung trung tâm, bảng thông báo ở cổng; dãy lớp ở một cánh, phòng thí nghiệm ở cánh còn lại, vườn thực nghiệm phía sau có lối lát gạch để trẻ đi giữa các ô trồng. Cây lớn ở sân là chỗ giao nhiệm vụ với **Cô Lan** và gặp **Bé Na**. Nội thất lớp có 12 bàn học theo GDD, bảng đen ở phía trên, lối đi giữa tối thiểu 2 tile.

**Landmark:** cổng trường vòm gỗ, biển nắng/sách và chuông trường. **Âm:** xylophone, tiếng chim, tiếng bút phấn, bước chân học sinh; trống/chuông giờ học làm âm báo nhỏ. **Tri thức:** Số tại bàn/bảng, Vật tại bàn thí nghiệm, Ký tại quả địa cầu/bản đồ. **Cốt truyện:** Ch2 tạo lớp “trường bị Sương Quên” với bảng bị mờ, cổng hầm trường dẫn tới Bóng Số Không, sau thắng phục hồi chữ/số.

**Nguyên tắc học ẩn trong thế giới:** công thức thật được giải bằng dụng cụ phòng thí nghiệm, ô đất minh họa diện tích, bản đồ xã hội; không mở màn thi chỉ để khóa cổng phụ. [GDD + MỚI]

### W06 — ĐỒI THƯ VIỆN (`library_hill`, 40×32)

**Vai trò [GDD]:** Thư viện cổ hai tầng, bảo tàng nhỏ, hầm sách khóa tới Ch3, vườn đọc sách; Thư viện 09:00–18:00, nghỉ thứ Hai. **Bà Tư** là thủ thư, giao nhiệm vụ Chữ, Phụ và Ẩn.

**Bố cục [MỚI]:** lối lên đồi là đường đá cong chữ S qua vườn đọc, có băng ghế nhìn xuống làng. Thư viện nằm ở phần cao nhất dễ nhận thấy mái ngói cũ; bảo tàng ở một cánh ngắn sát lối đi; cổng xuống hầm sách được đặt bên trong để lời kể dẫn dắt hợp lý. Có ít nhất hai nơi “ngồi đọc” không che đường NPC, một góc bóng cây để kích hoạt nhiệm vụ ẩn ngày mưa lúc 16:00 (từ GDD).

**Landmark:** cây cổ thụ lá vàng hoặc xanh rêu tùy mùa, mái thư viện với huy hiệu cuốn sách/sao, đèn dầu ấm; giấy bay một vài chỗ khi có Sương Quên. **Âm:** piano/cello, gió qua lá, tiếng lật trang và chuông nhỏ. **Tương tác:** mượn/trả sách, máy tra mục lục, trưng bày Bách khoa, cầu thang xoắn, hầm sách và Chìa Mực. **Cốt truyện:** Ch3 làm mờ chữ trên biển/kệ trong một trạng thái có kiểm soát, boss Gã Gạch Xóa và phục hồi dần các dòng chữ sau khi thắng.

**Quy tắc:** đọc sách là hoạt động yên tĩnh; không sinh quái trên sân thư viện trong trạng thái bình thường. Quái Dơi Giấy/Sách Hộ Pháp chỉ ở **hầm sách** theo GDD.

### W07 — RỪNG THÌ THẦM (`whispering_forest`, 90×70)

**Vai trò [GDD]:** hái lượm, chặt cây, quái nhẹ, sói đêm, gốc cổ thụ, trại thợ rừng, hang sói; mở sau Ch1. Sương Quên làm rừng nguy hiểm hơn. Lối tắt tới nông trại sau Ch1.

**Bố cục [MỚI]:**

- **Vành đai an toàn:** cổng rừng, bảng kiểm tra thời tiết, cây sồi/thông thưa, nhiều nấm/hái lượm dễ nhìn, đường về luôn sáng hơn.
- **Lối mòn giữa:** phân nhánh ôm hồ cạn và khúc gỗ đổ; có vòng đi bộ cho người thích khám phá không đánh quái.
- **Khoảng trống nấm:** nguồn thực vật đổi theo mùa, địa điểm gặp Nấm Độc lúc sương/Thu.
- **Khu cổ thụ:** thân lớn, rễ tạo lối cong, một điểm bí mật điều kiện tri thức, nhưng không đặt nhầm trên đường bắt buộc.
- **Vành đai đêm:** hang sói ở mép ngoài; nhiều vùng ẩn núp và đèn đặt được; vùng boss/khám phá chỉ vào khi người chơi chủ động.

**Nhận diện:** xanh rêu–lục thẫm ban ngày; tím lam ban đêm; tia sáng xuyên tán, rêu trên đá, nấm nhỏ sáng nhẹ. **Âm:** sáo thì thầm, côn trùng, cú; đêm thêm bass trầm và tiếng sói xa. **Sinh vật:** thỏ, chim sẻ, bướm, hươu, cú; Slime Mực, Nấm Độc, Sói Bóng Đêm, Ma Sương theo điều kiện đã có trong GDD.

**Thiết kế công bằng:** đòn quái luôn telegraph; vị trí spawn tối thiểu 12 ô ngoài tầm nhìn theo GDD; cây cao có vùng mờ khi che nhân vật; người chơi không bị “úp sọt” ở sát portal. **Sương Quên:** fog giảm tầm nhìn nhưng đèn lồng, biển hiệu và đường gỗ vẫn tạo hệ thống dẫn đường. **Thu thập:** gỗ, nấm, hoa Nguyệt, quả rừng, vật phẩm cốt truyện.

### W08 — HẦM ĐÁ THÌ THẦM (`stone_mine`, 40 tầng × 40×30)

**Vai trò [GDD]:** 40 tầng sinh theo seed ngày, sảnh hầm cố định với thang máy và lều nghỉ; hầm không phụ thuộc thời tiết. Các boss: tầng 10 **Slime Mực Mẹ**, 20 **Chúa Dơi Giấy**, 30 **Golem Công Thức** (Bóng Quên Mảnh Vật), 40 **Hầm Vương**. Mở Ch1 khi cấp Cư Dân ≥3.

**Bố cục [MỚI]:** sảnh hầm là “nút an toàn” rộng có biển tầng, quầy thiết bị và ghế nghỉ. Mỗi tầng chiến đấu cần có: ô vào an toàn, đường chính tới lối xuống, 1–3 nhánh tài nguyên, chỗ đặt khoáng, rương/biến thể phòng, lối thoát hợp lệ. **Không bắt buộc người chơi tiêu diệt tất cả quái** để xuống, trừ các trận khóa rõ ràng do thiết kế chương/boss.

**Ngôn ngữ tầng [MỚI]:**

| Tầng | Quần thể và màu | Cơ chế / nhịp |
|---|---|---|
| 1–10 | Đá nâu/xám ẩm, đồng, gel mực; ánh đèn ấm | Hướng dẫn đập đá, đường nhỏ, Slime/Sâu Đá/Dơi Giấy; boss 10 |
| 11–20 | Đá xám lam, tơ nhện, kệ gỗ hỏng | Nhánh đường phức tạp, Nhện Hang/Nấm Độc, cầu gỗ; boss 20 |
| 21–30 | Vách đá đậm, tinh thể sáng, máy móc cổ | Kênh tri thức Vật, mạch điện/cơ cấu, Golem nhỏ; boss 30 |
| 31–40 | Tinh thể tím–xanh, sương mờ, rãnh sâu | Tăng mật độ tinh anh, nhiều nhánh cần chuẩn bị; boss 40 |

**Nguyên tắc tạo tầng:** phân vùng không gian chạy được trước khi trang trí, đặt portal vào/ra trước, sau đó phòng thưởng/quái/tài nguyên theo seed; không có đồ rơi hoặc rương nằm ngoài lưới có thể tới. Trạng thái khai thác giữ trong phiên/ngày theo GDD; tầng sinh lại mỗi ngày. Tránh dùng ánh sáng lung linh gây khó đọc hitbox.

**Tương tác tri thức:** cân thăng bằng, mạch điện, trật tự công thức, ký hiệu khoáng. Với đố Chính tuyến thất bại ba lần, cơ chế hỗ trợ Lão Quang cho qua 1 sao vẫn áp dụng [GDD]. **Âm:** giọt nước, lửa nhỏ, va chạm kim loại, dội bước chân; nhạc synth trầm nhẹ, tránh làm game trở thành kinh dị.

### W09 — HỒ GƯƠNG & SÔNG BẠC (`mirror_lake`, 60×44)

**Vai trò [GDD]:** bến câu, cầu gỗ, nhà thuyền, thác nhỏ, bãi sậy; mặt hồ đóng băng toàn bộ vào Đông, đom đóm đêm Hạ, mưa lớn làm nước lên/cầu ngập một ngày. Hồ có sen mùa Hạ và cá theo lịch; đường tới Bãi Biển liên quan nhiệm vụ sửa cầu.

**Bố cục [MỚI]:** hồ là hình khối xanh lớn ở trung tâm; một đường đi bộ ôm bờ, ba vị trí câu với silhouette khác nhau (cầu gỗ, bãi sậy, chân thác), nhà thuyền ở cạnh lối chính. Sông chảy tới thác và nối biên map; cầu nằm trên tuyến di chuyển quan trọng, khi bị ngập phải có chỉ báo và phương án đi/đợi hợp lý chứ không làm người chơi mắc kẹt ở bên sai bờ.

**Landmark:** cầu gỗ, bụi sen, bến câu có ghế gỗ, thác phản chiếu ánh trời. **Âm:** đàn hạc, nước, ếch, vịt trời; đêm Hạ thêm đom đóm. **Tương tác:** lấy nước cho bình tưới, câu cá, bẫy, rửa mặt xóa Mù, bơi sau Ch4 có Áo Phao, đi bộ trên băng mùa Đông, câu băng.

**Mỹ thuật nước [GDD + MỚI]:** tile hoạt hình 4 frame ×0,4 giây; gợn sáng hạn chế tương phản, đường bờ autotile rõ. Mưa tạo gợn tròn; mùa Đông đóng băng thành mặt phẳng có khe băng và cảnh báo khu đi trơn. **Khu câu:** `FishingZone` độc lập theo bến, đồng bộ mùa/giờ/thời tiết.

### W10 — BÃI BIỂN SÓNG VÀNG (`golden_beach`, 70×40)

**Vai trò [GDD]:** cầu cảng, nhà ngư dân, hang đá thủy triều, bãi san hô và thuyền trưởng **Marco**; mở sau nhiệm vụ sửa cầu ở Hồ Gương. Thủy triều chu kỳ 6 giờ game; khi thấp lộ ao nước đọng, vỏ sò, sao biển; giông bão có sóng cao cấm tới mép nước.

**Bố cục [MỚI]:** đường tới bãi đi qua dải cát rộng; vùng nhà ngư dân/quầy câu ở trái, cầu cảng và thuyền ở phải; khu ao nước đọng và hang thủy triều chỉ lộ/lối đi rõ khi nước rút. Nhìn thấy đèn hải đăng nhỏ từ xa **nếu dùng như landmark trang trí**, không biến thành công trình mới có chức năng trừ khi được duyệt.

**Landmark:** đường chân trời, nước ngọc lam, thuyền buồm/bến cảng, mái chòi cọ hoặc ngói, đèn vàng lúc đêm. **Âm:** ukulele, sóng, hải âu, chuông cảng. **Động vật:** cua, hải âu, sao biển, rùa biển hiếm. **Quái:** Cua Đá lúc triều thấp; Ma Sương ban đêm; trận Thủy Thủ Câm trên tàu theo Ch4. **Học Ngữ:** giao tiếp với Marco, biển chỉ dẫn song ngữ, phân loại đồ trao đổi.

**Quy tắc thời gian:** mọi `tide_state` phải là kết quả từ `GameClock`; không dùng timer thật 6 giờ. Cảnh bờ nước phải luôn có **cảnh báo hình học + hiệu ứng sóng** khi bão ngăn tiếp cận. Trẻ hóa cảnh bằng đèn nước lễ Hội Biển Đêm, không tạo điểm chói gây che thanh câu.

### W11 — NÚI MÂY (`cloud_mountain`, 80×80)

**Vai trò [GDD]:** địa hình lên cao 0–3, trạm dừng, thác nước, vách đá, đài thiên văn; tuyết quanh năm ở cao độ từ 2, sương sáng sớm; mở ở Ch5 và cấp Cư Dân ≥8. Đỉnh núi chứa nhiệm vụ thiên văn và Bóng Quên **Hồn Ký Ức**, đồng thời nơi đặt năm Mảnh Sao và đối mặt **Kẻ Xóa Chữ**.

**Bố cục [MỚI]:**

1. **Chân núi (cao độ 0):** đường đá, cây thông, lều nghỉ, cảnh nhìn lại làng.
2. **Sườn núi (cao độ 1):** đường zig-zag, cầu gỗ nhỏ và bậc đá; điểm mở khóa Móc leo sau yêu cầu kỹ năng.
3. **Vành tuyết (cao độ 2):** băng, gió, mái che hiếm, quái Linh Băng và nguồn tinh băng; trạm nghỉ có đèn.
4. **Đỉnh thiên văn (cao độ 3):** khoảng sân rộng, đường nét sao trên đá và Đài Thiên Văn; tầm nhìn hướng núi/hồ, ít cây để bầu trời là chủ đề chính.

**Landmark:** cột đá đánh dấu cao độ, thác, cầu treo, mái đài thiên văn hình sao. **Âm:** dây kéo dài, gió, tiếng băng, chuông xa; khi trời quang có motif Ngôi Sao Tri Thức. **Tương tác:** leo vách khi có Móc leo và Khai thác cấp 5, nhặt Hoa Nhung Tuyết, quan sát sao khi trời quang 19:00–02:00, giải mê cung la bàn và ký ức, nghỉ tại trạm.

**Khả năng đọc:** đường lên tầng phải liên tục, đoạn không có tay vịn dùng bóng chân vách rõ, không để background giả đánh lừa là có lối đi. **Cốt truyện:** Ch6 mở các mảnh ký ức dọc đường; Ch7 đài thiên văn chuyển sang `event_overlay` nghi lễ, nhưng vẫn giữ lối đi từ cổng tới bàn tinh tú. Không bắt buộc đêm nào cũng đối đầu boss.

---

## 6. MẠNG NỘI THẤT, CÔNG TRÌNH VÀ ĐỒ VẬT TƯƠNG TÁC

### 6.1 Nguyên tắc nội thất [GDD + MỚI]

[GDD] Nội thất dùng các lớp `Floor`, `Wall`, `Furniture_Back`, `Entities` (Y-sort), `Furniture_Front`, `Light`, có `SpawnPoint_FromOutside`, `AmbienceBus`, các `InteractableSlot`; cửa sổ đổi ánh sáng theo giờ, trong nhà nghe tiếng mưa/gió vọng mờ. [MỚI] Mỗi nội thất xác định **đường từ cửa → điểm phục vụ chính → lối quay lại**; ở khung nhìn 320×180 phải nhìn thấy hoặc suy ra được nơi cần tới ngay sau khi vào.

| Nội thất | Điểm nhìn đầu | Vật phải có [GDD] | Vật/chi tiết thêm [MỚI] | Quy tắc đặc biệt |
|---|---|---|---|---|
| Nhà chính | Giường, rương, bàn nhỏ | Giường, rương, bếp theo cấp, bàn chế tạo, tủ đồ, bàn học, TV, lò sưởi | Cửa sổ nhìn ra luống, thảm vải, đèn bàn | Nâng cấp 3 bậc; đồ đặt cá nhân lưu theo `persistent_id` |
| Tiệm Dì Năm | Quầy ngay cạnh lối vào | Quầy thu ngân, kệ hạt mùa, bảng giá, thùng đặt hàng | Sọt rau, thùng gỗ, sổ bán hàng | Mở Shop hai cột; nghỉ Chủ Nhật |
| Lò rèn Chú Ba | Lò nung và đe nhìn thấy | Lò nung, đe, giá vũ khí, bàn mài | Than hồng, quặng bày từng bậc | Nâng công cụ mất 2 ngày game |
| Phòng khám | Quầy tiếp đón, giường bệnh | Giường bệnh, tủ thuốc, bảng cơ thể | Chậu thuốc, kệ khăn sạch | Cấp cứu mở 24/7 có phí |
| Quán Hương Lúa | Quầy và bàn ăn | Quầy, bàn, thực đơn, bảng sự kiện | Bếp lửa, nồi cơm, bàn góc cửa sổ | Có NPC ngồi theo lịch, mở tới 22:00 |
| Lớp học | Bảng đen ở đầu, 12 bàn | Bàn học, bảng, bàn Cô Lan, tủ sách, chuông | Bài tập trên bàn, tranh thiên nhiên | Chỉ phiên học theo giờ lớp |
| Phòng thí nghiệm | Bàn dụng cụ và bảng sơ đồ | Bàn thí nghiệm, bản đồ/quả địa cầu | Lọ, dây, bóng đèn giả lập | Đố Vật dùng minh họa rõ, không dựa màu |
| Thư viện cổ tầng 1 | Quầy Bà Tư và kệ sách | Kệ sách, bàn thủ thư, máy mục lục | Trần gỗ, đèn đọc, bàn học nhóm | Thứ Hai đóng cửa |
| Thư viện tầng 2 | Kệ sách cổ, cầu thang | Cầu thang xoắn, sách cổ | Bản đồ sao, kính đọc, đồng hồ | Chữ/ký ức theo nhiệm vụ |
| Hầm sách | Lối tối, biểu tượng Chìa Mực | Cửa khóa, tủ kính liên quan truyện | Sàn chữ rơi, kệ xiên, đèn mờ | Ch3, quái Dơi Giấy/Sách Hộ Pháp |
| Chuồng gà/bò | Lối giữa hai dãy | Máng ăn, nước, ổ trứng/điểm vắt, lò sưởi, bảng tin | Thùng rơm, cửa thông gió | Vật nuôi cần tiếp cận từ 2 phía |
| Nhà kính | Luống và van tưới | Luống trồng quanh năm, tưới tự động Ch4 | Kính hơi sương, chậu ươm | Không bị thời tiết ngoài trời |
| Đài thiên văn | Kính thiên văn và Bàn Tinh Tú | Kính, bàn đặt Mảnh Sao, Trụ Ngôi Sao | Đèn sao, tranh chòm sao | Hoạt động 19:00–02:00; nghi lễ cuối |

**Kích thước nội thất:** GDD chưa chốt từng scene. [MỚI — ĐỀ XUẤT] Khởi đầu bằng module 16×12, 20×14 hoặc 24×16 tile tùy công trình; dùng kiểm tra khả năng đọc và di chuyển để chốt cuối, **không xem đây là kích thước đã phê duyệt**.

### 6.2 Luồng tương tác thống nhất [GDD]

`InteractionDetector` kích thước 20×20 hướng về trước; ưu tiên NPC → Station → Rương → Trang trí; phát hiện đối tượng, viền sáng, icon `E`, kiểm điều kiện, hoạt ảnh/SFX, cập nhật thế giới, phát EventBus và lưu nếu có `persistent_id`.

[MỚI] Thiết kế nội thất theo **luồng vật lý** này: icon không được hiện xuyên tường; cự ly từ cửa đến quầy phải đủ ngắn; NPC không đứng chặn máy/cửa; mỗi trạm có điểm đứng tương tác bên cạnh; đồ trang trí có collider riêng hoặc không collider nhất quán, không để tủ cao vừa che nhân vật vừa chặn cửa.

### 6.3 Trạng thái dựng công trình [MỚI — ĐỀ XUẤT]

Mọi công trình có tối thiểu: `closed` (đèn/tấm biển hợp lý), `open` (NPC/âm thanh/đồ tương tác hoạt động), `festival` (cửa tiệm thường đóng hoặc chuyển cảnh), `night_lit`, và `snowy/rainy` ở ngoại thất. Những công trình gắn chương có thêm `locked_story` và `restored_story` nhưng chỉ khi GDD yêu cầu.

---

## 7. VĂN HÓA ĐỜI SỐNG VÀ NHỊP SINH HOẠT NPC

### 7.1 Mười hai NPC chính [GDD]

| NPC | Nghề / nơi làm | Vai trò trong thế giới | Dấu hiệu thị giác [MỚI] | Hành vi quan sát được [MỚI] |
|---|---|---|---|---|
| Cô Lan | Giáo viên, Trường Ánh Dương | Số, chính tuyến lớp học | Áo màu sáng, sách/bút | Đứng bảng, ra vườn thực nghiệm, trò chuyện cùng Bé Na |
| Bà Tư | Thủ thư, Đồi Thư Viện | Chữ, sách cổ, nhiệm vụ ẩn | Tóc bạc búi, áo tím/kem | Sắp sách, đi vườn đọc, tra mục lục |
| Chú Ba | Thợ rèn, Phố Chợ | Nâng công cụ/vũ khí | Tạp dề nâu, búa | Đập đe, nung, nghỉ hiên khi đóng cửa |
| Dì Năm | Tiệm tạp hóa, Phố Chợ | Giống, vật dụng, toán mua bán | Khăn quàng, giỏ hàng | Sắp kệ, cân hàng, khóa cửa Chủ Nhật |
| Bác sĩ Minh | Phòng khám | Chữa bệnh, khoa học cơ thể | Túi thuốc, áo sáng | Kiểm tra giường, đọc thảo dược |
| Ông Sáu | Hồ / Bãi Biển | Ngư nghiệp, câu cá | Nón rộng, cần câu | Câu theo giờ, kiểm bến, trò chuyện ngư dân |
| Cô Mai | Đồng Cỏ | Chăn nuôi, hướng dẫn | Mũ vải/giỏ cỏ | Cho ăn, mở cổng chuồng, vuốt ve động vật |
| Lão Quang | Đài thiên văn | Truyện sao, Vật/Ký, hỗ trợ đố | Áo choàng đơn giản, cuộn bản đồ | Quan sát bầu trời, ghi sổ, nghỉ ở đài |
| Bé Na | Trường / Quảng Trường | Nhiệm vụ học sinh và quan hệ | Cặp sách nhỏ, hoa cài | Tới lớp, chơi sân, hỏi bài người chơi |
| Anh Khoa | Hầm Đá | Hướng dẫn khai thác, Vật | Đèn đầu, đồ thợ mỏ | Kiểm mỏ, ngồi sảnh, chở khoáng |
| Chị Vy | Quán Hương Lúa | Nấu ăn, lễ hội, giao thương | Khăn bếp, tạp dề | Băm rau, mời khách, ghi thực đơn |
| Marco | Bến cảng | Tri thức Ngữ, giao thương ngoại quốc | Áo thủy thủ/khăn cổ | Gỡ dây buồm, xem hàng, nói chuyện tại cảng |

GDD đã quy định **hữu nghị 0–10 tim**, trò chuyện +20/ngày, quà theo sở thích, sự kiện quan hệ mỗi 2 tim; lịch NPC là JSON theo `weekday`, `weekend`, `rain`, `festival`, `special`, sử dụng `NavigationAgent2D`. **MỚI:** khi nhân vật không chạy mô phỏng đầy đủ ngoài camera, hãy giữ trạng thái logic theo mốc giờ rồi đưa vào vị trí hợp lệ lúc camera đến, tránh “dịch chuyển ngay trước mắt”.

### 7.2 Vai phụ làm nền [MỚI — ĐỀ XUẤT, KHÔNG PHẢI NPC CHÍNH THỨC]

Để không tạo làng hoang vắng có thể có `background_villagers` không có đường hữu nghị riêng: người gánh hàng vào chợ, trẻ em trong sân trường, người lớn nghỉ bên hồ, khách du lịch trong lễ hội. Số lượng và spawn phải theo hiệu năng; **không** tự tạo quest/cốt truyện/quan hệ nếu chưa thêm vào danh sách GDD. Mỗi mẫu dùng quần áo/điệu bộ riêng, không sao chép cùng sprite ở mọi vùng.

### 7.3 Quy tắc lịch sinh hoạt có thể tin cậy

- Lịch cơ bản: nơi ở → nơi làm → nghỉ trưa ngắn → hoạt động sau giờ → về nhà. **Các giờ cụ thể của từng NPC chưa được GDD chốt**; tạo file dữ liệu riêng để tác giả điền.
- Khi có mưa/bão, hoạt động ngoài trời chuyển sang nơi trú theo `rain`; ngày lễ dùng `festival`; nhiệm vụ chương dùng `special` ưu tiên cao.
- NPC đi giữa các map bằng `MapPortal` có điểm đến, không xuyên tường, không đi vào vùng boss hoặc nhà riêng của người chơi nếu không có sự kiện.
- Khi NPC không hiện diện, vật tương tác có thể báo lịch hoặc gợi ý, nhưng **không tự mở cửa hàng** ngoài giờ.
- Nếu NPC đang ở cutscene/nhận nhiệm vụ, `NpcScheduleController` tạm giữ vị trí rồi tiếp tục lịch sau khi kết thúc; người chơi không mất hội thoại giữa chừng.

### 7.4 Một ví dụ lịch **chỉ để minh họa cấu trúc**, chưa canon [MỚI]

```json
{
  "npc_id": "teacher_lan",
  "weekday": [
    {"start_minute": 360, "map_id": "school_grounds", "position_marker": "staff_room", "activity": "prepare_lessons"},
    {"start_minute": 480, "map_id": "school_grounds", "position_marker": "classroom_board", "activity": "teach"},
    {"start_minute": 720, "map_id": "school_grounds", "position_marker": "school_garden", "activity": "garden_check"},
    {"start_minute": 840, "map_id": "school_grounds", "position_marker": "classroom_board", "activity": "teach"}
  ]
}
```

Dữ liệu thực cần được duyệt lại theo buổi học 08–10 và 14–16; các mốc khác do team nội dung quyết định.

---

## 8. HỆ SINH THÁI: CÂY, VẬT NUÔI, ĐỘNG VẬT HOANG, NGUỒN LỢI

### 8.1 Thảm thực vật và vòng đời [GDD]

**Cây trồng:** 14 loại nông nghiệp theo GDD, 4–6 frame phát triển (hạt, mầm, non, trưởng thành, chín, héo). Cần tưới trong ngày để tăng 1 ngày sinh trưởng; ba ngày liền không tưới thì héo; trái mùa héo trừ trong nhà kính. **Cây ăn quả:** đào, cam, táo, hồng; cần khoảng trống 3×3 ô khi lớn. **Cây rừng:** sồi, thông, phong, cổ thụ; gốc chặt còn lại. **Hoa và bụi:** cúc, tulip, hướng dương, hoa tuyết, hoa Nguyệt, bụi dâu, cỏ cao... [GDD]

[MỚI] Mỗi cây có ba lớp rõ trong world asset: **silhouette** để nhận dạng loài từ xa, **trạng thái tương tác** để biết có thể thu hoạch/chặt, và **dấu mùa** để cho thế giới thay đổi. Tránh dựa vào tooltip để phân biệt cây đã chín. Dùng ít nhất một dấu hình: quả to hơn, chấm sáng, lá khác, búp mở.

### 8.2 Vùng hái lượm theo mùa [GDD + MỚI]

| Môi trường | Xuân | Hạ | Thu | Đông |
|---|---|---|---|---|
| Rừng / nông trại | Tỏi dại, rau dớn, hoa | Dâu rừng, hướng dương dại | Nấm, hạt dẻ, mâm xôi | Rễ củ, quả khô |
| Bờ nước / biển | Rau cải xoong | Vỏ sò, rong biển | Sò điệp | San hô khi biển lặng |
| Hầm / núi | Tuyết lan chân núi | Nấm đá | Nấm hang | Tinh băng, Hoa Nhung Tuyết |

[GDD] 06:00 mỗi map ngoài trời spawn 3–8 vật hái lượm; mưa làm nấm nhiều hơn. [MỚI] Spawn chỉ trên ô đi được, cách portal và điểm quest bắt buộc ít nhất một khoảng an toàn; không rơi vào ô có đồ người chơi đặt. Biến thể hình ảnh phải phản ánh đúng vật phẩm nhận được.

### 8.3 Vật nuôi [GDD]

Tám nhóm vật nuôi **gà, vịt, bò, dê, cừu, heo, ong, ngựa** và thú cưng **mèo/chó**. Không giết/mổ; có thể nhượng vật nuôi cho cô Mai. Chỉ số Đói/Khát/Hạnh phúc/Sức khỏe/Nhiệt; sản phẩm đổi theo chất lượng, mùa và chăm sóc. Cần cho ăn, cho uống, vuốt ve, đóng cửa chuồng trước 19:00, chữa bệnh; mùa Đông cần sưởi. Người chơi học được ý nghĩa nuôi dưỡng chứ không chỉ lấy tài nguyên.

[MỚI] Hoạt ảnh vật nuôi tối thiểu cần thấy: đứng, đi, ăn, ngủ, nhận vuốt ve, trạng thái ốm/đói (icon trên đầu). Cho con vật **vùng quay đầu/lối về chuồng** để không đi xuyên rào. Mèo/chó đi theo có khoảng cách mềm, tránh đẩy người chơi khi tương tác hoặc chiến đấu.

### 8.4 Động vật hoang [GDD]

**Thỏ, chim sẻ, vịt trời, ếch, cua, bướm, đom đóm, hươu, cú, cáo** có hành vi theo giờ, mùa, thời tiết; đa số dùng quan sát/cho ăn/bắt nhẹ để mở Bách khoa và nhận nguyên liệu. [MỚI] Quy tắc art: động vật phải có chuyển động nhận diện trước khi người chơi tới gần: sẻ mổ hạt rồi bay, thỏ giật tai, vịt tạo sóng, cua đi ngang, hươu ngoái nhìn rồi chạy. Không sử dụng cùng một kiểu `idle` cho tất cả.

### 8.5 Phân bố sinh thái không gian [MỚI]

- Vùng cư trú có **thú hiền và gia súc**; đêm Trăng Tròn nông trại có hiểm họa hiếm theo GDD, nhưng quảng trường và chợ vẫn được thiết kế là nơi an toàn.
- Vùng bờ hồ ưu tiên **vịt trời, ếch, đom đóm**; chỉ xuất hiện vào những khoảng giờ thích hợp.
- Rừng và núi ưu tiên **thỏ, hươu, cú**, khu rậm/đêm có quái.
- Biển ưu tiên **hải âu, cua, rùa biển**, thay đổi theo triều.
- Mỏ ưu tiên sinh vật/quái phù hợp với đá và bóng tối, không tự đưa động vật trang trại vào.

---

## 9. QUÁI QUÊN, VÙNG NGUY HIỂM VÀ KHÔNG GIAN CHIẾN ĐẤU

### 9.1 Bản sắc của Quái Quên [GDD]

Quái vật là biểu tượng của **ký ức bị xóa**, không phải sinh vật đẫm máu. Khi bị đánh bại, chúng tan thành mực, giấy, bột sáng trong hoạt ảnh 6 khung. Các dạng chính: Slime Mực, Sâu Đá, Dơi Giấy, Nấm Độc, Cua Đá, Quái Điện, Nhện Hang, Sói Bóng Đêm, Ma Sương, Linh Băng, Sách Hộ Pháp, Golem Đá. Chỉ số, loot, bán kính phát hiện, hành vi và tỉ lệ spawn phải đọc từ GDD mục 11/data, không tự đặt lại trong world spec này.

**Ngôn ngữ hình ảnh [MỚI]:**

| Nhóm | Dấu hiệu nhận ra | Hiệu ứng sinh ra/thua |
|---|---|---|
| Mực/gel | Đầu hoặc thân nửa trong, giọt mực chảy ngược | Bong bóng mực tụ rồi tách |
| Giấy/sách | Mép rách, dòng chữ vụn, cánh như trang sách | Trang giấy rơi chậm rồi tan |
| Sương/ảo ảnh | Viền rời, ánh tím xanh, bóng không ổn định | Chụm thành một ký hiệu ngôi sao thiếu nét |
| Đá/tinh thể | Khối góc sắc, vết nứt ký hiệu công thức | Mảnh đá và bụi lắng xuống |
| Sinh vật biến dị | Silhouette vẫn giống loài nền, chỉ thêm dấu Quên | Trở về hình rừng/biển không bạo lực |

### 9.2 Không gian chiến đấu có đường lui [MỚI]

- Trận chạm trán thường phải có **khung sàn đủ để né**, không đặt vật trang trí cản mọi hướng cạnh portal; mục tiêu 3–4 tile đất trống theo một trong các hướng thoát.
- Khi địch phát hiện, `!` và telegraph phải hiện nổi trên cỏ, đá, nước hoặc nền tối. [GDD/UI]
- Đòn lớn luôn có **khoảng báo hiệu** như bảng quái trong GDD; không dùng hạt mưa/tuyết giống màu đòn để đánh lừa.
- Chạm trán boss tách khỏi vòng giao thương làng bằng **phòng/đấu trường riêng**, có lối vào và cơ chế trở ra.
- Nếu người chơi mất hết HP, áp dụng ngất/đưa về nhà, Phòng khám hay sảnh hầm theo GDD, không đặt lại ở một tile nguy hiểm.

### 9.3 Năm đấu trường Bóng Quên [GDD + MỚI]

| Trùm | Đấu trường / dấu hiệu [MỚI] | Đòn/cơ chế chiến đấu [GDD] | Câu đố & biểu đạt tri thức [GDD] | Phản hồi sau thắng [MỚI] |
|---|---|---|---|---|
| **Bóng Số Không** | Hầm trường có sàn ô số, bảng phấn nứt | Né số rơi, sang pha 2 | Đánh đúng con số đáp án của 3 phép tính | Các con số trên bảng học hiện lại rõ |
| **Gã Gạch Xóa** | Hầm sách, sàn ghép dòng chữ | Gạch xóa vùng sàn | Điền từ đúng để khôi phục ô an toàn | Kệ/biển thư viện sáng chữ |
| **Thủy Thủ Câm** | Boong tàu, mỏ neo và làn sóng quanh mép | Sóng, mỏ neo quét | Hội thoại tiếng Anh lộ điểm yếu | Đèn cảng/biển chỉ dẫn đọc được |
| **Golem Công Thức** | Phòng máy hầm tầng 30, cột mạch | Dậm đất, ném đá | Đánh khớp sáng theo chuỗi công thức khoa học | Máy cũ nhấp nháy ổn định |
| **Hồn Ký Ức** | Bệ đá Núi Mây, bia thời gian | Sương, ảo ảnh | Xếp mốc ký ức đúng thứ tự | Cột mốc trên đường núi phục hồi |

**Trùm cuối — Kẻ Xóa Chữ [GDD]:** tại Đài Thiên Văn, đêm Đông ngày 7 lúc 20:00, ba pha xóa chữ/số/ngôn ngữ và dùng cả năm tri thức; kết thúc bằng “nhắc nhớ”, không giết chóc. [MỚI] Thiết kế visual theo nhịp: nền sao yên tĩnh → ký hiệu dần biến mất → năm vòng sáng trở lại khi người chơi giải thành công. Bố cục boss UI không che các điểm cần tương tác trên sân.

### 9.4 Các chế độ nguy hiểm theo ngày

[GDD] **Trăng Tròn** ngày 4 mỗi mùa làm bầy sói mạnh hơn, mở Hoa Nguyệt; **Sương Quên** gây hạn chế tầm nhìn và trạng thái Quên; mưa làm Slime Mực xuất hiện nhiều hơn; giông sinh Quái Điện; Đông có Sói Tuyết/Linh Băng. [MỚI] Để không phá nhịp chơi thư thái, mỗi vùng cần có ít nhất một **tín hiệu báo trước** bằng âm thanh, biển chỉ dẫn hoặc ánh sáng, cùng đường rút an toàn.

---

## 10. TRI THỨC NẰM TRONG THẾ GIỚI, KHÔNG TÁCH RỜI THẾ GIỚI

### 10.1 Phân bổ năm mảng tri thức [GDD]

| Mảng | Địa bàn và vật thể học chính | Bài học thế giới | Phần thưởng vai trò |
|---|---|---|---|
| **Số** — Toán | Trường, bảng giá Dì Năm, bàn học | Tính tiền thối, đo diện tích, nhận quy luật | Bán có giá tốt hơn, mua giảm giá, Mảnh Số |
| **Chữ** — Ngữ văn | Thư viện, sách, bia có chữ | Điền ca dao, ghép câu, phục hồi đoạn văn | Hội thoại phong phú, quà tốt hơn, Mảnh Chữ |
| **Ngữ** — Tiếng Anh | Bến cảng, Marco, thương lái ngoại quốc | Nối từ–hình, giao tiếp, điền hội thoại | Mở giao thương, Mảnh Ngữ |
| **Vật** — Khoa học tự nhiên | Vườn trường, phòng thí nghiệm, Hầm Đá, Phòng khám | Vòng đời cây, mạch điện, cơ thể, máy móc | Công thức/chế tạo, cây tốt hơn, Mảnh Vật |
| **Ký** — Lịch sử–Địa lý | Bản đồ, thư viện, Núi Mây, đài thiên văn | Định hướng, lịch sử làng, sắp xếp mốc ký ức | Đường tắt, bản đồ, Mảnh Ký |

### 10.2 Mẫu thiết kế một câu đố gắn môi trường [MỚI]

**Ví dụ A — Bảng giá chợ, Số:** người chơi thấy ba rổ rau và thẻ giá ở quầy Dì Năm. Nhấn `E` mở khung câu hỏi nhỏ theo UI chuẩn, tính tổng tiền/thối tiền; đáp đúng, Dì Năm nhận xét và trao XP. Nếu sai, giải thích ngắn, không phạt Xu hàng hóa thật.

**Ví dụ B — Vườn thực nghiệm, Vật:** ba luống có ánh sáng, đất và nước khác nhau. Người chơi quan sát cây, kéo thẻ điều kiện “nước/ánh sáng/không khí/chất dinh dưỡng” vào bảng. Sau giải thích, người chơi nhận biết quy tắc cây trồng đang áp dụng trong game.

**Ví dụ C — Bia ký ức trên Núi Mây, Ký:** các phiến đá khắc bốn sự kiện làng; người chơi xem di vật ở các vùng rồi sắp thứ tự mốc. Nếu sai, có thể đọc lại gợi ý trên bia, không buộc đi tìm vật phẩm ngẫu nhiên.

**Ví dụ D — Marco ở bến, Ngữ:** lời thoại liên quan việc chỉ đường tới thuyền, các đáp án hiện dưới dạng hội thoại như UI đã thiết kế. Trả lời đúng giúp Marco hiểu; sai thì NPC diễn đạt lại đơn giản hơn.

**Ví dụ E — Hầm sách, Chữ:** câu ca dao bị trống một từ, đáp án tương ứng các mảnh giấy trên sàn; điền đúng giúp hiện lại một đoạn đường an toàn.

### 10.3 Quy tắc sư phạm xuyên thế giới [GDD + MỚI]

- 5 câu/phiên học, tối đa 5 mức độ khó thích ứng; đúng/sai đều có phản hồi bằng lời giải thích. [GDD]
- Không có đồng hồ đếm giờ mặc định; `Gợi ý` và `Bỏ qua tạm` có ở mọi dạng. [GDD/UI]
- Thất bại 3 lần ở câu đố Chính tuyến sẽ có hỗ trợ của Lão Quang để đi tiếp với 1 sao. [GDD]
- [MỚI] **Ngôn ngữ câu đố phải khớp đồ vật địa phương**: bài toán nông nghiệp dùng giá nông sản, bài khoa học dùng cây, bài địa lý dùng đường đến bản đồ; không dùng nội dung ngẫu nhiên lệch bối cảnh.
- [MỚI] Mỗi “bài học lần đầu” nên có dấu hiệu tương tác trên scene; lượt ôn lại không cần hiện một nhiệm vụ mới.

---

## 11. CỐT TRUYỆN VÀ CÁC LỚP BIẾN ĐỔI THẾ GIỚI

### 11.1 Thứ tự 7 chương [GDD]

| Chương | Mốc sớm nhất | Map trọng tâm | Biến đổi có thể nhìn thấy [MỚI] | Kết quả [GDD] |
|---|---|---|---|---|
| Mở đầu: Lá Thư | Xuân 1 | Nông Trại, Phố Chợ | Nhà cũ, cỏ cần dọn, phong thư/chiếc chìa khóa | Nhận Sổ Tay |
| 1. Hạt Giống Đầu Tiên | Xuân 2 | Nông Trại, Chợ, Trường | Nhân vật trong làng giới thiệu nhau, đường rừng có dấu mở | Rừng, sảnh Hầm, nhiệm vụ ngày |
| 2. Ngôi Trường Im Lặng | Xuân 4 | Trường, hầm trường | Bảng bị xóa số, sân bớt học sinh, sau thắng sáng lại | Mảnh Số, lướt |
| 3. Thư Viện Bị Khóa | Hạ 1 | Đồi Thư Viện, hầm sách | Trang sách phai, cửa hầm mở sau Chìa Mực | Mảnh Chữ, công thức nâng cao |
| 4. Tiếng Sóng Ngoại Ngữ | Hạ 5 | Hồ Gương, Biển | Sửa cầu, mở đường ra bến, đèn nước lễ hội | Mảnh Ngữ, Áo Phao, nhà kính |
| 5. Mỏ Đá Thì Thầm | Thu 1 | Hầm Đá tầng sâu | Máy cơ khí phục hồi từng phần | Mảnh Vật, Núi Mây |
| 6. Núi Mây và Ký Ức | Thu 5 | Núi Mây, đài thiên văn | Bia lịch sử sáng lên, dấu sao dẫn đỉnh | Mảnh Ký, đài nâng cao |
| 7. Đêm Sao Rơi | Đông 1; trận cuối Đông 7 20:00 | Đài thiên văn, Quảng Trường | Làng chuẩn bị trang trí, bầu trời có dấu năm cánh | Trùm cuối, hậu kết, chơi tự do |

Các chương chỉ mở khi chương trước hoàn thành và đạt ngày tối thiểu; **không hết hạn**, có thể đi tiếp trong năm sau. [GDD] Vì vậy môi trường phải dựa vào **cờ tiến trình**, không chỉ dựa vào mùa/ngày: nếu tới Đông mà người chơi chưa xong Ch4, cảnh không được tự giả định cầu đã sửa.

### 11.2 Phân lớp sự kiện (`event_overlay`) [GDD + MỚI]

**Thế giới cơ sở** được dựng từ tileset mùa; **trạng thái chương** bổ sung cổng/đồ vật/câu chữ; **lễ hội** dựng sân khấu/cờ/gian hàng; **thời tiết** phủ hiệu ứng; cuối cùng là ánh sáng theo giờ. Các lớp độc lập giúp không phải nhân bản một map cho mỗi chương.

[MỚI] Quy tắc ưu tiên xung đột:

1. Khả năng đi lại và portal bắt buộc.
2. Trạng thái cốt truyện/đối tượng tương tác.
3. Lễ hội theo ngày.
4. Công trình do người chơi đặt.
5. Thời tiết, mùa và trang trí ngẫu nhiên.

Một sự kiện không được xóa hoặc chiếm ô công trình/vật nuôi của người chơi. Nếu một NPC có nhiệm vụ chương nhưng là ngày lễ, nội dung phải có nhánh hội thoại tại lễ hội hoặc giải pháp sau lễ, không khiến nhiệm vụ mắc kẹt.

### 11.3 Bốn lễ hội [GDD + MỚI]

| Lễ hội | Ngày [GDD] | Trang trí thế giới [MỚI] | Hoạt động gắn gameplay [GDD] |
|---|---|---|---|
| **Hội Hoa Xuân** | Xuân 7 | Cổng hoa đào, dây hoa giấy, gian trưng bày cạnh đài phun | Cắm hoa, thu thập 5 loại hoa, đố Số/Chữ |
| **Hội Biển Đêm** | Hạ 7 | Đèn nước, đèn cảng, bến gỗ có cờ, đom đóm | Thi câu cá đêm, giao tiếp tiếng Anh |
| **Hội Gặt** | Thu 7 | Rơm cuộn, bó lúa, giỏ bí ngô, sân bày nông sản | Nộp nông sản chất lượng, nấu, ca dao |
| **Đêm Sao Rơi** | Đông 7 | Bàn sao, đèn vàng ấm, sao giấy năm cánh, trời quang | Kết thúc Ch7, năm sau là ngày hội vui |

[GDD] Lễ hội diễn ra 10:00–23:00; cửa hàng thường đóng; thời tiết bảo đảm nắng/trời quang. [MỚI] Lối tới các gian hàng phải đi được từ cổng chính, có các điểm đứng dành cho NPC chính; tránh overlay ngày hội làm biến mất bảng nhiệm vụ hoặc gây lỗi NPC pathfinding.

### 11.4 Ba hậu kết và dấu vết lưu lại [GDD + MỚI]

[GDD] Hậu kết phụ thuộc mức phát triển **Trường**, **Thư Viện** hoặc **Nông Trại**. [MỚI] Mỗi hậu kết có thể dùng một thay đổi xã hội nhẹ trong thế giới sau kết thúc: thêm bàn học ngoài sân, triển lãm sách ở quảng trường hoặc vườn cộng đồng; chỉ là **ý tưởng mỹ thuật/không gian**, chưa có công thức tính phát triển được GDD xác nhận. Hậu kết không xóa thành tựu, NPC hay tài sản người chơi.

---

## 12. HỆ THỐNG KINH TẾ, KHÁM PHÁ VÀ ĐỜI SỐNG

### 12.1 Dòng lưu chuyển vật phẩm trong không gian

```text
Nông Trại ──nông sản──► Hòm gửi hàng / Dì Năm / Quán Hương Lúa
    ▲                            │
    │                       Xu / công thức
    │                            ▼
Đồng Cỏ ──sữa, trứng──► Bếp / trạm chế biến / quà NPC

Rừng ──gỗ, nấm──► Bàn chế tạo ──đồ dùng──► Nông Trại
Mỏ ──quặng──► Lò rèn ──công cụ mạnh──► Rừng / Mỏ / Nông Trại
Hồ & Biển ──cá, rong──► Chợ / Quán ăn / Bách khoa
Trường & Thư viện ──tri thức──► kỹ năng mở rộng / câu đố / công thức
```

Đây là **sơ đồ luồng**, không thêm giá mới. Mọi hệ số kinh tế, kỹ năng, XP, chất lượng và thời gian chế biến được lấy theo GDD mục 7–13.

### 12.2 Mỗi vùng phải có vòng chơi ngắn và dài [MỚI]

| Vùng | Vòng chơi ngắn (1–3 phút) | Lý do quay lại (ngày/mùa/chương) |
|---|---|---|
| Nông Trại | Tưới, thu, cất đồ | Tăng vụ, nâng nhà/chuồng/nhà kính |
| Đồng Cỏ | Quan sát, chăm con vật | Chọn giống mới, tăng hạnh phúc |
| Phố Chợ | Mua giống, bán, ghé quán | Giá/giống mùa, đơn hàng, NPC |
| Quảng Trường | Nhận nhiệm vụ, đọc bảng tin | Nhiệm vụ ngày, dự báo, lễ hội |
| Trường | Làm một câu/quan sát vườn | Lớp theo buổi, tri thức Số/Vật |
| Đồi Thư Viện | Đọc, tra mục lục | Sách mới, hầm Ch3, Chữ/Ký |
| Rừng | Hái nấm, chặt một cây | Tài nguyên theo mùa, bí mật đêm |
| Hầm | Đập quặng, xuống một tầng | Kim loại cao cấp, boss, Vật |
| Hồ | Một lượt câu/bẫy | Cá theo thời tiết, băng mùa Đông |
| Biển | Nhặt vỏ sò, nói với Marco | Triều thấp, thương nhân, Ngữ |
| Núi | Tìm một mốc, nhặt tinh băng | Đài thiên văn đêm quang, Ký |

### 12.3 Giới hạn áp lực [GDD + MỚI]

- Thất bại chiến đấu/ngủ muộn chỉ mất một phần Xu hoặc thể lực/HP như GDD; không dùng “game over vĩnh viễn”.
- Nhiệm vụ Chính tuyến không hết hạn; gợi ý và đường hỗ trợ không bị khóa do trả lời sai.
- [MỚI] Những nhiệm vụ tạo cảm giác thời hạn (trồng theo vụ, chợ mở theo giờ, cá theo mùa) nên có nhắc bằng sổ tay và bảng tin, nhưng không spam cảnh báo.
- [MỚI] Mọi khu khóa phải có **lời giải thích theo thế giới**: cầu chưa sửa, đường rừng cần chỉ dẫn, cổng mỏ cần chuẩn bị, núi cần móc leo; không hiển thị chỉ một ổ khóa trơ trọi.

---

## 13. MẠNG ÂM THANH VÀ KHÔNG KHÍ TỪNG VÙNG

### 13.1 Phân lớp âm thanh [MỚI — ĐỀ XUẤT]

`MusicMap` (nhạc theo map) + `AmbienceBiome` (môi trường lặp) + `SpotSFX` (âm từ vị trí: giếng, búa, chim) + `WeatherLoop` (mưa/gió/tuyết) + `StoryStinger` (cốt truyện) + `InteractionSFX` (công cụ, UI). `AudioManager` quyết định chuyển nhạc theo map/giờ/thời tiết như GDD.

| Map | Nhạc đặc trưng [GDD] | Điểm phát âm trong thế giới [MỚI] |
|---|---|---|
| Nông Trại | Guitar mộc | Giếng, cây, gà gáy, mái mưa |
| Đồng Cỏ | Sáo | Bò kêu, chuông cỏ, bước chân đàn |
| Phố Chợ | Jazz nhẹ | Lò rèn gõ, tiếng rao, nấu ăn, sạp bán |
| Quảng Trường | Accordion | Đài phun, tiếng nói xa, cờ gió |
| Trường | Xylophone | Chuông, phấn, bước chân, chim |
| Đồi Thư Viện | Piano/cello | Lá khô, giấy, tiếng cửa gỗ |
| Rừng | Sáo thì thầm; đêm bass trầm | Cú, cành gãy, côn trùng, sói xa |
| Hầm Đá | Nhỏ giọt và synth | Nước, đá vỡ, thang, tinh thể |
| Hồ | Đàn hạc | Sóng bờ, vịt, cá quẫy, thác |
| Biển | Ukulele | Sóng, hải âu, thuyền, dây buồm |
| Núi | Dàn dây, gió | Gió tầng cao, băng, chuông đài |

### 13.2 Phản hồi âm thanh có tính năng

- Tiếng `!` khi cá cắn, đổi giờ học, tiếng chuông rèn hoàn thành, cảnh báo quái và thông báo nhiệm vụ đều phải có **phụ đề âm thanh tùy chọn** theo UI Spec. [UI + MỚI]
- Trời mưa bên trong công trình nghe **mưa qua mái/cửa sổ giảm âm**, không phát vòng lặp mưa giống ở ngoài. [GDD]
- Đêm khuya giảm âm dân cư, tăng côn trùng/gió, đèn bật đồng bộ `light_level < 0.55`. [GDD + MỚI]
- Khi mở menu/học tập thời gian tạm dừng, âm môi trường có thể giảm âm lượng nhẹ nhưng không được để nhạc tiếp tục báo nguy hiểm như trận đang chạy. [MỚI]

---

## 14. THIẾT KẾ CẤP ĐỘ MAP, CAMERA, ĐƯỜNG ĐI VÀ LỚP VA CHẠM

### 14.1 Hợp đồng một scene map [MỚI]

Mỗi scene cần có: `map_id`, kích thước tile cố định, ít nhất một `SpawnPoint`, danh sách `MapPortal`, các `NavigationRegion2D`/ô đi được, layer render chuẩn, vùng âm thanh, ánh sáng, điểm spawn NPC/động vật/quái, `FishingZone` nếu có nước, vị trí camera có giới hạn, và mô tả `map_state_id`.

### 14.2 Thông số phải bám GDD

- Physics layers 1–10: `world_solid`, `player`, `npc`, `monster`, `animal`, `interactable`, `hitbox_player`, `hitbox_monster`, `pickup`, `trigger`. [GDD]
- Camera bám nhân vật, smoothing 6, giới hạn đúng kích thước map; tính y-sort theo chân thực thể. [GDD]
- Portal fade 0,25 giây vào + 0,25 giây ra; thời gian vẫn chạy; map cache giữ state. [GDD]
- Vật cao dùng điểm gốc ở chân, mái nhà và tán cây ẩn/mờ khi cần. [GDD]
- Thực thể ngoài bán kính 2 màn hình giảm cập nhật; cây ngoài tầm nhìn cập nhật theo ngày; object pooling cho vật rơi, hạt, đạn. [GDD]

### 14.3 Tiêu chuẩn khả năng đi và camera [MỚI]

1. **Khu spawn:** không va chạm, không quái xuất hiện sát, không đẩy người chơi vào nước sâu, không đứng ngay bên rìa tile bị chặn.
2. **Cửa & quầy:** có ít nhất một ô đứng trước tương tác; mỗi NPC trọng tâm có `position_marker` không chồng cửa.
3. **Giao lộ:** dấu chỉ đường/landmark thấy từ vùng vào; mũi tên không đè NPC hoặc ảnh hưởng bối cảnh.
4. **Vật thể che:** khi người chơi đi sau tán/mái, che mờ phần cần thiết trong chốc lát; hitbox không đổi do alpha.
5. **Nước sâu:** có va chạm cho tới khi mở Bơi/Áo Phao; chỗ lội phải có ranh giới rõ. [GDD]
6. **Địa hình cao:** mỗi bậc 0–3 có lối nối rõ (cầu, thang, đường dốc); không có chỗ rơi vô hình.
7. **Ngày lễ:** kiểm tra lại đường đi vì gian hàng xuất hiện, đám đông và NPC đổi lịch.
8. **Tăng font/độ phóng UI:** menu/tooltip không quyết định vị trí vật thể trong thế giới; gợi ý tương tác lật phía khi sát cạnh màn hình. [UI]

### 14.4 Sổ ghi cổng cần lập khi dựng [MỚI]

| `portal_id` mẫu | `from_map` | `to_map` | Điều kiện | Ghi chú |
|---|---|---|---|---|
| `farm_to_market` | `farm_main` | `market_street` | Không | GDD có liên kết tuyến đi |
| `farm_to_ranch` | `farm_main` | `ranch` | Không | Vào vùng tự do |
| `farm_to_forest_shortcut` | `farm_main` | `whispering_forest` | Ch1 | Lối tắt phía bắc |
| `square_to_school` | `town_square` | `school_grounds` | Không (sân) | Lớp học mở sau Ch1 |
| `square_to_library` | `town_square` | `library_hill` | Không | Đường lên đồi |
| `library_to_forest` | `library_hill` | `whispering_forest` | Ch1 | GDD sơ đồ chính |
| `forest_to_mine` | `whispering_forest` | `stone_mine` | Ch1 + cấp ≥3 | Cổng sảnh hầm |
| `library_to_lake` | `library_hill` | `mirror_lake` | Không | Đường ra nước |
| `lake_to_beach` | `mirror_lake` | `golden_beach` | Sửa cầu | Theo điều kiện mở bãi biển |
| `library_to_mountain` | `library_hill` | `cloud_mountain` | Ch5 + cấp ≥8 | Cần phân biệt cổng chân núi và leo vách |

**Chưa chốt:** một số mũi liên kết trung tâm trong sơ đồ chữ GDD cần mô tả portal hai chiều chính xác trước khi dựng scene. Bảng trên là **đề xuất danh sách liên kết tối thiểu**, không khẳng định đã đủ mọi cổng.

---

## 15. CẤU TRÚC DỮ LIỆU THẾ GIỚI — DATA-DRIVEN GODOT

### 15.1 Ranh giới trách nhiệm [GDD + MỚI]

| Hệ thống | Sự thật quản lý | Không nên quản lý |
|---|---|---|
| `GameClock` | Phút game, ngày, mùa, năm, sự kiện thời gian | Nội dung cụ thể của cây/NPC |
| `SeasonSystem` | Biến thể mùa, luật cây đổi mùa | Chi tiết hội thoại |
| `WeatherSystem` | RNG thời tiết, dự báo, điều kiện đặc biệt | Sinh quái tự do không qua `SpawnDirector` |
| `SceneManager` | Portal, spawn, cache map, chuyển cảnh | Giá bán hàng |
| `QuestManager` | Cờ nhiệm vụ, mục tiêu, tiến trình chương | Chỉnh thẳng tile nếu không qua hệ thống map |
| `InventoryManager` | Túi/rương/hotbar và số lượng | Lịch NPC |
| `KnowledgeManager` | Câu đố, năm mảng tri thức, độ khó | Cửa map ở trạng thái tùy ý |
| `SaveManager` | Snapshot trạng thái, `save_version`, migrate | Tự suy đoán cờ chưa lưu |
| `AudioManager` | Nhạc, âm tầng, fade giữa vùng | Sinh NPC |
| `EventBus` | Signal thông báo giữa hệ thống | Chứa logic gameplay |
| **`WorldStateService` [MỚI]** | Trả về dữ liệu `MapStateData`/biến thể/cờ vùng một cách nhất quán | Không ghi đè GDD; là lớp truy cập dữ liệu đề xuất |

[MỚI] `WorldStateService` là tiện ích tùy chọn, không bắt buộc thêm Autoload. Có thể đặt là component/service của `SceneManager` nếu muốn tránh singleton mới.

### 15.2 Hợp đồng `MapStateData` [GDD]

Các trường đã ghi trong GDD: `map_id`, `season`, `time_phase`, `light_level`, `weather_segments`, `special_flags`, `wetness`, `snow_cover`, `temperature`, `is_open`, `event_overlay`.

[MỚI] Cần liên kết tới **phần trạng thái lưu bền** riêng: công trình/vật đặt, cây trồng, ô đất, vật rơi, rương, portal mở, đối tượng nhiệm vụ và NPC đang ở đâu. Không ép thông tin lưu bền vào tất cả instance `MapStateData`; GDD đã quy định lưu ở nhánh `maps` của save.

### 15.3 `MapDefinition` đề xuất [MỚI]

Đây là dạng dữ liệu thiết kế, không phải class đã có trong dự án. Có thể triển khai thành `Resource`/`.tres`.

```json
{
  "map_id": "mirror_lake",
  "name_key": "MAP_MIRROR_LAKE_NAME",
  "scene_path": "res://scenes/maps/mirror_lake.tscn",
  "size_tiles": [60, 44],
  "biome_id": "lake_river",
  "music_id": "bgm_mirror_lake",
  "spawn_points": ["from_library", "from_beach", "lake_pier"],
  "portal_ids": ["lake_to_library", "lake_to_beach"],
  "fishing_zone_ids": ["lake_central", "river_bank", "waterfall_foot"],
  "poi_ids": ["lake_pier", "boathouse", "bridge", "waterfall"],
  "seasonal_variant_group": "four_seasons",
  "story_overlay_group": "mirror_lake_story",
  "festival_overlay_group": null
}
```

**Quy ước:** ID/đường dẫn minh họa phải được xác nhận trước khi code; không dùng dữ liệu placeholder để tạo đường đi thật mà thiếu cặp return portal.

### 15.4 `WorldPOI` đề xuất [MỚI]

Một điểm đáng chú ý (Point of Interest) có: `poi_id`, `map_id`, `tile_position`, `display_name_key`, `type` (`landmark`, `shop`, `quest`, `resource`, `fishing`, `transition`, `lore`, `hazard`), `interaction_id`, `unlock_conditions[]`, `minimap_icon`, `world_icon`, `time_windows[]`, `season_windows[]`, `discovery_flag`, `audio_emitter_id`. `WorldPOI` chỉ làm **danh mục địa điểm**, không trùng toàn bộ dữ liệu Shop/Quest/Interactable.

Ví dụ điểm `bridge` của Hồ Gương: `type=transition`, `unlock_conditions=[quest_repair_bridge_completed]`, `discovery_flag=bridge_seen`; icon bản đồ thay đổi theo `quest` và state. **ID điều kiện là tên minh họa**, chưa có trong tài liệu nguồn.

### 15.5 Tín hiệu đề xuất cho sự thay đổi môi trường

Bên cạnh tín hiệu đã có trong GDD, có thể bổ sung qua `EventBus`: `map_poi_discovered(poi_id)`, `portal_unlocked(portal_id)`, `world_prop_state_changed(persistent_id, state_id)`, `interior_entered(interior_id)`, `tide_phase_changed(tide_id)`, `festival_overlay_changed(map_id, overlay_id)`. [MỚI]

**Luồng mẫu khi sửa cầu:** QuestManager đánh dấu mục tiêu hoàn thành → EventBus phát sự kiện → World map đọc `unlock_conditions` và thay sprite cầu từ “hỏng” sang “sửa” → `MapPortal` cho vào Biển → SaveManager giữ cờ. Không để script cầu tự viết vào JSON nhiệm vụ.

### 15.6 Sinh ngẫu nhiên có seed và lưu trạng thái

- `world_seed` sinh từ save; thời tiết, spawn hầm, vật phẩm ngẫu nhiên phải tái lập theo seed/phần ngày theo quy tắc GDD.
- Với vật phẩm do người chơi đặt/trồng, **ưu tiên `persistent_id`** hơn seed ngẫu nhiên để tránh mất đồ khi load lại.
- 40 tầng hầm dùng seed ngày, nhưng **tiến trình đang ở tầng/hộp đã mở trong ngày** phải giữ trong phiên và ghi đúng nếu save tại chỗ được hỗ trợ.
- Không tự phát sinh NPC, mùa hoặc cổng trên client theo giờ thực; chỉ dùng đồng hồ game.

### 15.7 Hợp đồng tệp ảnh và animation [MỚI]

```text
assets/art/tilesets/
  shared/                 # dirt_path, water_edges, wood_fence, small_rocks
  spring/ summer/ autumn/ winter/
  forest/ cave/ coast/ mountain/ interior/
assets/art/buildings/
  farm_house/ market_stalls/ school/ library/ forge/ clinic/
assets/art/props/
  signposts/ lanterns/ wells/ benches/ bridge/ crafting_stations/
assets/art/plants/
  crops/ trees/ fruit_trees/ flowers/ foraging/
assets/art/animals/        # per loài, sprite nhiều hướng
assets/art/monsters/       # per quái, attack/telegraph/hurt/death
assets/art/fx/             # leaf_fall, rainfall, fog, water, snow, meteor
```

**Tên file mẫu:** `tree_oak_spring.png`, `tree_oak_winter.png`, `bridge_lake_broken.png`, `bridge_lake_repaired.png`, `forge_flame_04f.png`, `water_river_flow_04f.png`. Mỗi assetsheet có tài liệu `frame_size`, `fps`, `origin`, `collision_bounds`, `atlas_margin`, `palette_variant`.

---

## 16. MA TRẬN ASSET THẾ GIỚI CẦN SẢN XUẤT

> Số lượng bên dưới là **ước lượng sản xuất** để chia ticket; **không thay thế MVP list** ở GDD phụ lục 16.1. Một “bộ” có thể gồm nhiều biến thể/mảnh autotile.

### 16.1 Nhóm tile & môi trường [MỚI]

| Nhóm | Bộ/scope đề xuất | Ghi chú |
|---|---|---|
| Nền cỏ/đất/đường | 4 biến thể mùa × bộ terrain cạnh/góc | Chuyển mùa và mặt đất ướt/khô |
| Nước | 1 bộ sông + 1 hồ + 1 biển, mỗi bộ hoạt hình 4 frame | Bờ nước và tile nông/sâu rõ |
| Rừng | Sồi, thông, phong, cổ thụ, cây bụi, rễ lớn | Tán và thân độc lập; cây cần chặt có HP |
| Núi/đá | 4 mức cao, vách, dốc, bậc thang, rãnh | Chú ý collision/height_level |
| Hầm mỏ | 4 họ vật liệu cho mỗi dải 10 tầng | Đá, quặng, cầu gỗ, tinh thể, máy cổ |
| Bờ biển | Cát khô/ướt, sóng, vỏ sò, san hô, ao triều | Có state theo thủy triều |
| Trang trí | Rào gỗ/tre, luống, đèn, biển, ghế, thùng, sọt, giếng | Tái sử dụng giữa map, đổi bảng màu nhẹ |
| Thời tiết | Mưa, tuyết, gió lá, sương, cầu vồng, sao băng | Kèm trạng thái trợ năng giảm hiệu ứng |
| Kiến trúc ngoài | Nhà nhỏ/vừa/lớn, mái tranh/ngói, cửa, biển hiệu | Cửa và chân tường collision độc lập |
| Nội thất | Sàn gỗ, vách, cửa, bàn, kệ, tủ, giường, dụng cụ học | Tương tác định vị theo object |

### 16.2 Asset nhân vật/sinh vật [GDD + MỚI]

- [GDD] Nhân vật người chơi ghép lớp 16×32, đủ hướng/animation; 12 NPC 16×32 và chân dung 48×48; quái nhỏ 16×16, vừa 24×24, boss ≥48×48.
- [MỚI] Mỗi NPC chính nên có `idle`, `walk`, `interact/activity` và 2–3 biến thể đạo cụ theo nghề; riêng chân dung dùng 4 biểu cảm theo UI Spec.
- [MỚI] Với vật nuôi, chuẩn sheet ít nhất 4 hướng di chuyển và trạng thái ăn/ngủ/nhận chăm sóc; với động vật hoang, có hoạt ảnh đặc trưng và phản ứng bỏ chạy/quan sát.
- [MỚI] Thêm silhouette pass ở 1× và 2× để kiểm tra chồng lấn giữa người, cây và cổng.

### 16.3 Mỗi khu vực cần gói art giao việc cụ thể [MỚI]

| Mã | Landmark phải vẽ | Module độc quyền | Bộ trạng thái cần chụp QA |
|---|---|---|---|
| W01 | Nhà chính + giếng + ruộng | Đất canh tác, chuồng, nhà kính, silo | Sáng Xuân, mưa, Đông, đêm Trăng Tròn |
| W02 | Cổng trại + bãi cỏ | Chuồng mẫu, máng, ao vịt, bảng động vật | Nắng, mưa, Đông, giờ cho ăn |
| W03 | Dãy mái ngói và lò rèn | Quầy tạp hóa, phòng khám, quán, sạp | Mở cửa, đóng cửa, chợ phiên, bão tuyết |
| W04 | Đài phun + bảng tin | Sân lễ hội, gian hàng, ghế, đèn | Ngày thường, 4 lễ hội, tuyết |
| W05 | Cổng trường + lớp U | Bảng đen, phòng thí nghiệm, vườn trường | Buổi học, nghỉ cuối tuần, Sương Quên |
| W06 | Nhà thư viện + cây cổ thụ | Kệ cổ, máy mục lục, hầm sách | Bình thường, Ch3 bị xóa, sau phục hồi |
| W07 | Cổ thụ + hang sói | Nấm, đường rừng, trại thợ rừng | Ngày, đêm, mưa, Sương Quên |
| W08 | Sảnh hầm + thang máy | 4 theme tầng, quặng, cột tinh thể | Tầng đầu, boss 10/20/30/40 |
| W09 | Cầu gỗ + thác + sen | Nhà thuyền, bến câu, băng | Nắng, mưa lớn, đêm Hạ, Đông |
| W10 | Cầu cảng + tàu | Ao triều, hang, đèn nước | Triều cao/thấp, giông, lễ Biển Đêm |
| W11 | Vách zig-zag + đài sao | Trạm nghỉ, bệ ký ức, tuyết cao | Sương sáng, đêm quang, Ch6, Ch7 |

### 16.4 Yêu cầu đầu ra cho họa sĩ [MỚI]

Mỗi gói asset giao kèm: file PNG nền trong suốt ở pixel gốc; sprite sheet có lưới/metadata; bảng màu sử dụng; tile atlas có thứ tự; mẫu đặt vào scene 320×180 ở scale thực; hướng ánh sáng; va chạm đề xuất; animation frame count/FPS; tên và mô tả trạng thái tương tác; giấy phép sử dụng thương mại. **Không giao chỉ một ảnh concept độ phân giải cao thay cho tài sản có thể chơi.**

---

## 17. QUY TRÌNH TẠO BẢN ĐỒ TỪ ĐẶC TẢ [MỚI — ĐỀ XUẤT]

### 17.1 Một map đi qua tám bước

1. **Blockout:** đặt rìa map, đường đi, vùng khóa, landmark, portal, vùng nước/địa hình cao trên lưới tile.
2. **Traversal test:** di chuyển 4 hướng từ mọi portal đến ít nhất một POI; kiểm tra chỗ hẹp, kẹt cửa, băng qua cầu.
3. **Gameplay placement:** đặt Interactable, shop/NPC marker, FishingZone, farming cells, resource nodes, spawn tables.
4. **Palette and terrain:** tô biome, nền, tường, sườn, nước và bảng màu theo mùa.
5. **Set dressing:** mái, hoa, bụi, đèn, đá nhỏ, biển; không làm giảm khả năng đọc lối chính.
6. **Living world:** lịch NPC, chuyển động sinh vật, âm thanh tại vị trí, thời tiết, ánh sáng theo giờ.
7. **Event variants:** khóa/mở, chương truyện, bốn lễ hội, câu đố; test mọi thứ tự sự kiện hợp lệ.
8. **Save/performance/QA:** lưu/tải sau tương tác, test ở scale x2/x3/x4 và khi map đông, đạt 60 FPS theo GDD.

### 17.2 Hai ảnh kiểm chứng bắt buộc của mỗi map

- **Ảnh A — Gameplay nguyên bản 320×180:** nhân vật, đường đi và tối đa HUD thường dùng, cho thấy tính chơi được.
- **Ảnh B — Concept/marketing 16:9:** phong cảnh giàu chi tiết, cùng màu và silhouette; không dùng để đánh giá kích thước va chạm.

Điểm này giúp tránh nhầm lẫn giữa sáu ảnh thiết kế trình bày hiện tại với cảnh có thể đưa trực tiếp vào game.

### 17.3 Một lát cắt sản xuất mẫu (vertical slice)

**Đề xuất:** làm đường **Nông Trại → Phố Chợ → Quảng Trường → Trường → Nông Trại**, kèm một phiên học Số tại bảng giá hoặc trường và một tương tác bán nông sản. Lát cắt phải bao gồm ngày/đêm, mưa, một NPC có lịch, cửa tiệm mở/đóng, lưu/tải, một màn học và đường về. Sau đó mới nhân rộng cùng chuẩn sang rừng/hầm/hồ/biển/núi. [MỚI]

**Tại sao:** một đoạn đường liên thông có đủ nông nghiệp, cửa hàng, hội thoại, tri thức và cổng sẽ kiểm nghiệm “thế giới sống” tốt hơn 11 background chưa có collision.

---

## 18. KIỂM THỬ CHẤT LƯỢNG THẾ GIỚI — DEFINITION OF DONE

### 18.1 Tiêu chuẩn bắt buộc của từng map [GDD + MỚI]

- [ ] Kích thước và tên `map_id` đúng bảng mục 2.2.
- [ ] Portal hai chiều cho phép trở ra; không spawn đè vật thể hoặc đối tượng nguy hiểm.
- [ ] Nhân vật/NPC/động vật không xuyên qua tường/nước sâu/vách theo layer vật lý.
- [ ] Có ít nhất một landmark dễ nhận biết và đường tới hoạt động chính.
- [ ] NPC đang làm việc theo `GameClock`, đổi lịch mưa/lễ hội, không biến mất khi bắt đầu đối thoại.
- [ ] Xuân/Hạ/Thu/Đông và sáng/trưa/đêm không làm thay đổi collision sai ý.
- [ ] Đồ đặt, đất, cây, rương, portal mở và trạng thái cốt truyện lưu/tải được.
- [ ] Không có vật phẩm hoặc rương sinh ra trong ô không đi tới được.
- [ ] Ô học/quest/câu cá/đánh quái có vùng đứng tương tác phù hợp.
- [ ] Hiệu ứng gió/mưa/tuyết không che dấu hiệu báo đòn và tương tác.
- [ ] Tất cả chữ tiếng Việt có dấu, bảng biển/tooltip vừa màn 320×180 với scale hỗ trợ.
- [ ] Mục tiêu 60 FPS; cập nhật ngoài camera đúng chiến lược chunk/object pool của GDD.
- [ ] Có scene test độc lập + ít nhất một unit test GUT logic thuần + ghi chú API trong `docs/`.

### 18.2 Kịch bản QA chung [MỚI]

| Test | Bước | Kết quả mong đợi |
|---|---|---|
| **World reload** | Trồng 3 ô, đặt rương, mở cổng, save/load | Giữ đúng đất, cây, cổng và vật phẩm |
| **Weather cycle** | Chạy từ nắng sang mưa và qua ngày | Cây ngoài trời tự tưới, vật liệu ướt, âm thanh đổi |
| **Season roll** | Từ ngày 7 sang ngày 1 mùa sau | Cây trái mùa héo, tileset đổi, quầy theo mùa thay |
| **NPC and hours** | Tới tiệm trước/đúng/sau giờ mở | Biển/cửa/NPC/Shop đồng bộ; gõ cửa có phản hồi |
| **Story order** | Vào Xuân 4 khi chưa xong Ch1 | Không tự phát hoạt cảnh Ch2; cổng theo quest |
| **Festival overlay** | Ngày 7, đi qua 4 cổng Quảng Trường | Không có gian nào chắn đường/NPC/quest |
| **Forest risk** | Tới rừng ban ngày/đêm/Trăng Tròn/Sương | Spawn, tầm nhìn, đèn và lối về hợp lệ |
| **Mine generation** | Sinh nhiều tầng theo cùng seed/ngày | Có lối xuống, quặng và rương tới được; tái lập đúng |
| **Lake winter** | Đổi từ Thu sang Đông ở Hồ | Băng hình/va chạm/câu băng tương ứng; không mắc kẹt |
| **Beach tide** | Quan sát qua chu kỳ 6 giờ game | Bãi triều đúng thời gian, tài nguyên/đường đi hợp lệ |
| **Mountain heights** | Leo 0→3 và trở xuống | Không xuyên vách/nhầm lớp vẽ, góc camera đúng |
| **Accessibility** | Bật font lớn, giảm chớp, mù màu | Còn đọc rõ icon, telegraph, caption và tương tác |

### 18.3 Định nghĩa hoàn thành toàn thế giới

Một bản game được xem là **hoàn thành thế giới khả dụng** khi có đủ 11 map + nội thất bắt buộc, đi hết các tuyến hợp lệ theo điều kiện mở, chơi một vòng Xuân→Đông, hoàn thành tuyến Ch0–Ch7 và năm trận Bóng Quên, NPC và thời tiết đúng lịch, thế giới giữ trạng thái save, không có softlock và đáp ứng chỉ tiêu hiệu năng GDD. Đây là **tiêu chuẩn tích hợp**, không đòi toàn bộ asset trang trí cao cấp đã polish trước vertical slice.

---

## 19. CÁC ĐIỂM CHƯA THỐNG NHẤT / CẦN CHỐT TRƯỚC KHI CODE

| ID | Vấn đề | Những gì nguồn đang nói | Quyết định tạm trong tài liệu bổ sung | Việc cần chốt |
|---|---|---|---|---|
| `DEC-01` | **Bà Tư / Dì Năm** | GDD: Bà Tư là thủ thư, Dì Năm chủ tạp hóa; ảnh 2 ghi “Cửa Hàng Bà Tư” | Giữ GDD, coi tên trên mockup là chưa chuẩn hóa | Sửa label ở thiết kế UI hoặc đổi GDD bằng quyết định chính thức |
| `DEC-02` | **Tên nông trại** | GDD: Nông Trại Mầm Xanh; hình có Nông Trại Sao Mai/Trang Trại Đồi Gió | Giữ `farm_main` và Nông Trại Mầm Xanh | Chọn tên mặc định/alias rồi cập nhật ảnh |
| `DEC-03` | **Tên vùng trong bản đồ vẽ tay** | Hình 4 có Rừng Mơ, Núi Ngàn Sao, Đầm Linh Thủy; GDD có Rừng Thì Thầm, Núi Mây, Hồ Gương & Sông Bạc | Giữ 11 tên GDD | Xác định là tên cũ/concept hay vùng phụ thực sự |
| `DEC-04` | **Tên game và trung tâm** | Logo Làng Sao Mai; GDD mục 5 gọi “Thị trấn Sao Mai”, `town_square` là Quảng Trường Sao Mai | Làng Sao Mai là tên sản phẩm; Quảng Trường Sao Mai là map | Chốt tên hiển thị trong bản đồ và câu thoại |
| `DEC-05` | **Danh sách kỹ năng** | GDD: Nông nghiệp, Hái lượm, Câu cá, Khai thác, Chiến đấu; hình 5: Trồng trọt, Câu cá, Khai khoáng, Chăn nuôi, Thủ công | Giữ 5 kỹ năng theo GDD; chăn nuôi/thủ công là hoạt động có thể thuộc hệ thống khác | Chốt chỉnh mockup, hoặc thay GDD có chủ đích |
| `DEC-06` | **Số tab sổ tay** | UI spec: 8 mục chính; GDD mục 7.8 nêu “10 thẻ” nhưng liệt kê Trang bị và Thoát riêng, còn ảnh thể hiện 8 tab | World spec không thiết kế lại tab; để UI quyết định sau | Chốt Trang bị là tab hay subtab, Thoát là nút riêng hay tab |
| `DEC-07` | **Cầu mở biển và liên kết bản đồ** | GDD: Biển mở sau sửa cầu Hồ Gương; sơ đồ nối Quảng Trường–Bãi Biển và Hồ–Biển | Dùng gate “sửa cầu Hồ Gương”; không bỏ đường trên sơ đồ nếu chưa chốt | Liệt kê portal chính xác, điểm nào thực sự bị chặn |
| `DEC-08` | **Nhà kính** | GDD: có trong nông trại, sau Ch4 mở nhà kính, cấp Cư Dân 12 mở nhà kính | Chưa quyết định dùng điều kiện AND/OR | Chốt điều kiện xây và sử dụng hệ tưới |
| `DEC-09` | **Kích thước nội thất** | GDD quy định size ngoài; chưa có size mỗi interior | Dùng module 16×12/20×14/24×16 chỉ để thử | Chốt từng nội thất sau blockout |
| `DEC-10` | **Trang trí icon/sao trong lore** | Hình có hoa đào, sao và bảng gỗ; GDD có Ngôi Sao Tri Thức | Đề xuất một hệ biểu tượng năm cánh nhất quán | Chốt mẫu biểu tượng chính trước vẽ toàn bộ |
| `DEC-11` | **Thời điểm mở Ch7 và trùm cuối** | GDD: Ch7 mở Đông 1, trận cuối Đông 7 20:00, chương không hết hạn | Chờ đến sự kiện Đông 7 phù hợp, có thể qua năm sau | Chốt hành vi khi lỡ sự kiện do chưa đủ điều kiện |
| `DEC-12` | **Màn hình Phòng học trên tiêu đề** | GDD có Phòng học; ảnh 1 menu mẫu không hiển thị mục này | Giữ chức năng GDD, không sửa hình tại tài liệu thế giới | Sửa giao diện tiêu đề để có Phòng học |

**Nguyên tắc xử lý:** nhóm art vẫn có thể phát triển **hình, màu, layout blockout** của các vùng; các vấn đề `DEC` ảnh hưởng dữ liệu/UX/tiến trình phải được chốt trước khi kết nối vào scene thật. Không sửa lén các file nguồn.

---

## 20. BRIEF TẠO MINH HỌA VÀ TÀI SẢN CHO TỪNG VÙNG

### 20.1 Master World Art Brief [MỚI]

> **Mục tiêu:** vẽ Làng Sao Mai như một thế giới 2D top-down pixel-art 16-bit ấm áp, đậm cảm giác làng quê Việt hư cấu. Tỷ lệ gốc tile 16×16 và nhân vật 16×32; silhouette nhà mái ngói/nhà tranh, đường đất–đá, hàng rào gỗ, cây bốn mùa, hoa đào, ao sen, núi xanh, ánh đèn vàng, cảnh trong trẻo. Bố cục giữ đường đi và điểm tương tác rõ ràng, vật thể tách lớp để xử lý collision/Y-sort; không vẽ UI vào nền world scene. Mỗi cảnh có bản daylight và trạng thái thời tiết/mùa, giữ một ngôn ngữ bảng màu chung. Tránh sao chép logo/asset từ trò chơi khác.

Đây là **art direction**, không phải prompt thay thế kỹ thuật xuất sprite sheet. Mỗi đầu ra production cần thêm số frame, tỉ lệ, file cấu trúc, background trong suốt và pivot.

### 20.2 Shot list tạo concept/bản vẽ định hướng

| Shot | Nội dung phải có | Lưu ý góc máy |
|---|---|---|
| `WORLD_SHOT_01` | Bình minh Nông Trại, người tưới luống, giếng, mái nhà, cổng làng | Top-down ¾, đường đi nhìn rõ |
| `WORLD_SHOT_02` | Đồng Cỏ có cô Mai, bò/gà, rào gỗ, chuồng | Gợi chăm sóc, không rối đàn |
| `WORLD_SHOT_03` | Phố Chợ nhiều mái ngói, Dì Năm, lò rèn, quán Hương Lúa | Dải ngang, biển hiệu riêng |
| `WORLD_SHOT_04` | Quảng Trường với đài phun và bảng nhiệm vụ | Trục tâm, đủ khoảng trống ngày lễ |
| `WORLD_SHOT_05` | Trường có cổng, sân, vườn thực nghiệm và học sinh | Không biến thành lớp học hiện đại không hợp mỹ thuật |
| `WORLD_SHOT_06` | Đồi Thư Viện có vườn đọc, tán cây và thư viện cổ | Tĩnh, vàng kem và xanh rêu |
| `WORLD_SHOT_07` | Rừng Thì Thầm ban ngày/ban đêm | Hai trạng thái cùng layout, thấy lối mòn |
| `WORLD_SHOT_08` | Sảnh Hầm Đá và một tầng tinh thể sâu | Mô-đun đá và ánh đèn rõ collision |
| `WORLD_SHOT_09` | Hồ Gương, bến câu, cầu gỗ, sen, thác | Đường bờ/điểm câu không bị hoa che |
| `WORLD_SHOT_10` | Bãi Biển Sóng Vàng triều thấp, cầu cảng, thuyền | Biển ngọc lam, ao triều và cát vàng |
| `WORLD_SHOT_11` | Núi Mây từ chân lên đài sao, có bậc cao độ và tuyết | Tầng lớp rõ, đường đi khúc khuỷu |
| `WORLD_SHOT_12` | Lễ Đêm Sao Rơi, đài thiên văn và năm ký hiệu tri thức | Không gian kỳ ảo nhưng ấm, tránh kinh dị |

### 20.3 Brief làm tileset khác brief làm concept

**Tileset:** cần một atlas tile 16×16 với cạnh/góc/đường nối, các ô collision, biến thể mặt đất/sườn/bờ nước và các sprite độc lập cho object lớn. **Character sheet:** 16×32 frame, hướng trước/sau/trái, phải mirror nếu phù hợp, pivot chân thống nhất. **Exterior building:** mái, thân, cửa, đèn, biển thành các lớp. **Environment FX:** có thể tắt/giảm để đáp ứng trợ năng; không vẽ chết vào nền.

---

## 21. LỘ TRÌNH SẢN XUẤT THẾ GIỚI GẮN VỚI GDD

| Giai đoạn GDD | Phần thế giới phải hoàn thành | Cảnh kiểm thử gợi ý |
|---|---|---|
| **M0–M1** | Tile base, nhân vật, Y-sort, camera, Nông Trại blockout | Chạy vòng qua nhà, ruộng, cổng và cây |
| **M2–M3** | Bộ ánh sáng, mùa, thời tiết, giao diện HUD, hotbar | Qua 06:00 → hoàng hôn → đêm và save/load |
| **M4** | Đất/cây và asset mùa nông trại, hòm hàng | Trồng–tưới–thu hoạch–bán 3 ngày |
| **M5** | Cổng vùng và nội thất/cửa/Interactable | Đi nhà → chợ → nhà, giữ trạng thái đồ |
| **M6–M7** | Phố Chợ, Quảng Trường, Trường và 12 NPC theo lịch | Ngày nắng/mưa, hội thoại/quầy/nhiệm vụ |
| **M8** | Rừng, hầm, quái, phòng boss | Vòng rừng đêm, hầm tầng 1–10 |
| **M9** | Đồng Cỏ, chuồng, động vật và sản phẩm | Chăm gà/bò qua 7 ngày |
| **M10** | Hồ, nước, biển, thủy triều, câu cá | Câu theo thời tiết và triều |
| **M11** | Địa điểm học thực thụ, lớp/thư viện/bến/đài | 5 mảng tri thức, mở minigame đúng nơi |
| **M12** | Đài Núi Mây, 5 Bóng Quên, overlay chương/lễ hội | Chơi trọn Ch0–Ch7 |
| **M13–M14** | Âm thanh, polish, trợ năng, cân bằng/QA | 60 FPS, không softlock, build Windows |

### 21.1 Bản bàn giao cho đội phát triển [MỚI]

Mỗi khu vực có một thư mục `docs/world/` chứa: (1) phiếu map từ W01–W11; (2) bản blockout có ký hiệu portal; (3) danh sách POI và Interactable; (4) bảng asset cần vẽ; (5) danh sách trạng thái mùa/giờ/chương; (6) bảng NPC và spawn; (7) ảnh kiểm chứng 320×180; (8) kết quả QA/Performance. Sau khi team phê duyệt `DEC` còn mở, chuyển các đề xuất đã chốt thành dữ liệu `.tres`/JSON có version.

---

## PHỤ LỤC A — HÀNH TRÌNH MẪU MỘT NGÀY TRONG LÀNG

> **Ví dụ trải nghiệm [MỚI]:** Đây là một chuỗi có thể xảy ra dựa trên quy tắc game, không phải lịch nhiệm vụ bắt buộc.

**06:00:** thức dậy trong nhà Nông Trại Mầm Xanh, nhìn TV dự báo mưa mai, kiểm tra thư và bảng nhiệm vụ. **07:00–08:00:** chăm ruộng và cho vật nuôi ăn; nếu mưa, giảm công tưới. **09:00:** tới Phố Chợ, mua giống của Dì Năm và ghé quán; trong tiệm, một bài toán tính tiền được mở như hoạt động tự chọn. **10:00:** qua Quảng Trường, nhận nhiệm vụ hằng ngày và gặp một NPC, sau đó ghé Hồ Gương câu cá. **Chiều:** tới Thư Viện mượn sách hoặc học ở Trường khi có lớp. **Hoàng hôn:** trên đường về, đèn làng bật dần, người dân trở về nhà. **Tối:** về nông trại nấu ăn, đọc sách, sửa sang rồi ngủ để lưu tự động. Nếu người chơi thích khám phá, họ có thể đổi cả buổi chiều thành vào Rừng hoặc Hầm mà không phá mạch truyện.

## PHỤ LỤC B — HÀNH TRÌNH MẪU QUA BỐN MÙA

- **Xuân:** xây nông trại, làm quen làng và cô Lan; cây, hoa, đường rừng là các dấu mở rộng dễ thấy.
- **Hạ:** học ở thư viện, phục hồi sách, rồi ra biển, quan sát đom đóm, tham gia Hội Biển Đêm.
- **Thu:** thu hoạch bí/nho, khám phá hầm sâu và núi, đọc ký ức, cùng cộng đồng dự Hội Gặt.
- **Đông:** chuẩn bị áo ấm, câu cá băng, quan sát sao, kết thúc cốt truyện tại Đêm Sao Rơi; sang năm sau vẫn có thể sống, làm nông và hoàn thiện Bách khoa.

**Lưu ý:** đây là nhịp gợi ý tương ứng các mốc mở sớm nhất của GDD, không biến chương thành deadline; nếu chưa hoàn tất, tiến trình kéo sang năm tiếp.

## PHỤ LỤC C — TỪ ĐIỂN ĐỊA DANH VÀ ID CANON

| ID | Tên hiện dùng trong bản này | Trọng tâm |
|---|---|---|
| `farm_main` | Nông Trại Mầm Xanh | Nhà người chơi |
| `ranch` | Đồng Cỏ Cỏ Xanh | Chăn nuôi |
| `market_street` | Phố Chợ | Kinh tế, giao thương |
| `town_square` | Quảng Trường Sao Mai | Sinh hoạt làng |
| `school_grounds` | Trường Ánh Dương | Học Số/Vật |
| `library_hill` | Đồi Thư Viện | Học Chữ/Ký |
| `whispering_forest` | Rừng Thì Thầm | Hái lượm/quái nhẹ |
| `stone_mine` | Hầm Đá Thì Thầm | Khoáng và Vật |
| `mirror_lake` | Hồ Gương & Sông Bạc | Câu cá/nước |
| `golden_beach` | Bãi Biển Sóng Vàng | Biển và Ngữ |
| `cloud_mountain` | Núi Mây | Ký/thiên văn |

## PHỤ LỤC D — DANH SÁCH NGUỒN ĐỂ KIỂM TRA SAU KHI GHÉP GDD

- **GDD gốc:** mục 1 (tầm nhìn), 2–4 (kỹ thuật, thời gian), 5 (11 map), 6 (công trình), 7 (người chơi), 8 (vật phẩm), 9 (truyện/tri thức/NPC/lễ hội), 10 (động vật), 11 (quái), 12 (thực vật), 13 (nước/núi/biển), 14 (giao diện), 15 (kiến trúc và milestone), 16 (asset MVP).
- **UI Spec:** mục 1–2 (ngôn ngữ UI, pixel), 3–4 (HUD/hotbar), 5 (sổ tay), 6–7 (hội thoại, shop, học, câu cá, chiến đấu), 8–10 (tiêu đề/save/nhân vật/trợ năng), 11–14 (Godot/asset/QA).
- **Sáu bảng hình:** (1) ngoài gameplay; (2) hội thoại/cửa hàng/học; (3) chế tạo/cài đặt; (4) bách khoa/bản đồ/quan hệ; (5) túi/kỹ năng/nhiệm vụ; (6) gameplay/chiến đấu/câu cá.

---

**KẾT LUẬN THIẾT KẾ:** Thế giới Làng Sao Mai phải vừa đáng yêu để muốn ở lại, vừa vận hành đủ nhất quán để muốn hiểu sâu hơn. Mỗi ngôi nhà có người ở, mỗi con đường có đích đến, mỗi mùa để lại dấu vết, mỗi vật thể dạy được điều gì đó, và việc phục hồi Ngôi Sao Tri Thức có thể nhìn thấy ngay trong đời sống làng — chứ không chỉ trong màn hình nhiệm vụ.

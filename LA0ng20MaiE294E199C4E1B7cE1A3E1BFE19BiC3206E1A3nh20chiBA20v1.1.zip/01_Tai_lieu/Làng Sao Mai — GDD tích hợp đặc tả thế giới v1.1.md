# LÀNG SAO MAI — GDD TÍCH HỢP VÀ ĐẶC TẢ THẾ GIỚI

**Bản tổng hợp để tra cứu / cung cấp cho AI viết code.**

- **Phần I:** Game Design Document & Master Prompt v1.0 (nguyên văn, nguồn quy tắc gameplay chính).
- **Phần II:** Đặc tả thế giới game v1.1 (bổ sung có gắn nhãn `[GDD]`, `[UI]`, `[HÌNH]`, `[MỚI — ĐỀ XUẤT]`, `[CẦN CHỐT]`).
- **Đặc tả thiết kế giao diện:** là tài liệu tham chiếu riêng, không nhúng toàn văn để tránh nhầm vai trò giữa world và UI.

**Quy tắc khi có khác biệt:** Giữ quy tắc được ghi trong GDD gốc; chi tiết từ ảnh chỉ là chuẩn mỹ thuật; chi tiết mới phải được duyệt trước khi thay đổi logic gameplay. Xem mục 19 trong Phần II để biết các quyết định còn mở.

---

# PHẦN I — GDD GỐC (NGUYÊN VĂN)

# Làng Sao Mai — Game Design Document & Master Prompt

*Phiên bản 1.0 · Godot 4.x · Pixel art 16-bit (tile 16×16) · Nông trại + RPG + Giải đố + Học tập*

## 0. Cách dùng tài liệu này

Tài liệu có 2 lớp:

- **Lớp A — Master Prompt (mục 0.1):** đoạn prompt ngắn, dán vào AI viết code (Claude, Cursor, Copilot...) ở đầu mỗi phiên làm việc.
- **Lớp B — GDD chi tiết (mục 1 trở đi):** nguồn sự thật duy nhất. Prompt luôn yêu cầu AI đọc đúng mục liên quan trước khi code.

Nguyên tắc làm việc: **mỗi lần chỉ làm 1 hệ thống**, có cảnh test riêng, xong mới sang hệ thống tiếp theo (lộ trình ở mục 15).

### 0.1 Master Prompt (dán nguyên khối)

```
Bạn là Senior Game Developer chuyên Godot 4.x (GDScript có kiểu tĩnh) và Lead Game Designer.
Dự án: «Làng Sao Mai» — game 2D top-down pixel 16-bit, thể loại mô phỏng nông trại + RPG + giải đố + học tập (tham chiếu Stardew Valley).

QUY TẮC BẮT BUỘC
1. Nguồn sự thật là tài liệu GDD đính kèm. Trước khi code một hệ thống, hãy trích lại các mục GDD liên quan và liệt kê giả định của bạn.
2. Data-driven: mọi vật phẩm, nhiệm vụ, quái, cây trồng, động vật, câu hỏi nằm trong Resource (.tres) hoặc JSON ở thư mục data/. Không hardcode số liệu trong script.
3. Giao tiếp giữa hệ thống qua EventBus (signal). Không gọi chéo trực tiếp giữa các hệ thống.
4. Một thành phần = một trách nhiệm. Tên biến/hàm đầy đủ, tường minh, không viết tắt. Không dồn nhiều thao tác vào một dòng hay một hàm.
5. Pixel-perfect: viewport 320×180, texture filter Nearest, snap vị trí về pixel nguyên, scale nguyên.
6. Mọi thời gian trong game đọc từ GameClock. 1 ngày game = 240 phút thực (xem mục 4).
7. Mỗi hệ thống phải kèm: (a) scene test độc lập, (b) tối thiểu 1 unit test (GUT) cho logic thuần, (c) ghi chú API ngắn trong docs/.
8. Không thêm tính năng ngoài GDD. Nếu thấy GDD thiếu hoặc mâu thuẫn, hỏi lại trước khi làm.

QUY TRÌNH MỖI LƯỢT
Bước 1: Nhắc lại phạm vi (mục GDD nào). Bước 2: Đề xuất cấu trúc file/scene. Bước 3: Viết code theo từng file, mỗi file đúng đường dẫn trong cấu trúc folder (mục 3). Bước 4: Hướng dẫn cách chạy cảnh test và tiêu chí hoàn thành (Definition of Done).

ĐỊNH NGHĨA HOÀN THÀNH (DoD)
Chạy không lỗi/warning trong Godot 4.3+, đạt 60 FPS ở map lớn nhất, lưu/tải được trạng thái của hệ thống, có test.

NHIỆM VỤ HIỆN TẠI: <điền: ví dụ «Làm GameClock + WeatherSystem theo mục 4»>
```

### 0.2 Giả định đã chọn (có thể sửa)

| # | Giả định | Ghi chú |
| --- | --- | --- |
| 1 | «16bytes» hiểu là **pixel art 16-bit, tile 16×16** | Nhân vật 16×32, tile 16×16 |
| 2 | Godot **4.3+**, ngôn ngữ **GDScript** | C# có thể thay sau |
| 3 | **1 mùa = 7 ngày, 1 năm = 28 ngày** | Vì 1 ngày dài 240 phút nên mùa ngắn; 1 năm ≈ 93 giờ chơi. Chỉnh ở `GameConstants` |
| 4 | Single-player, PC trước, mobile sau | Input Map hỗ trợ bàn phím, chuột, tay cầm |
| 5 | Tiếng Việt là ngôn ngữ chính, i18n bằng CSV | Có thể thêm tiếng Anh |
| 6 | Không PvP, không phạt nặng | Thua trận chỉ mất ít Xu/đồ nhẹ |
| 7 | Học tập **không bao giờ chặn cốt truyện cứng** | Luôn có «Gợi ý», «Bỏ qua tạm» và chế độ ôn luyện |

---

## 1. Tầm nhìn sản phẩm

**Tagline:** *«Làm nông, khám phá, và thắp lại ngôi sao tri thức của ngôi làng.»*

### 1.1 Năm trụ cột thiết kế

1. **Thư thái:** nhịp chơi chậm, không áp lực thời gian thật; thất bại luôn có đường lui.
2. **Tri thức là sức mạnh:** học = mở khóa công thức, giảm giá, tăng chỉ số, mở khu vực. Không học vẫn chơi được nhưng chậm hơn.
3. **Thế giới sống:** thời gian, mùa, thời tiết, NPC có lịch sinh hoạt thật.
4. **Mỗi khu vực một bản sắc:** mỗi map có chủ đề, nhạc, bảng màu, cơ chế riêng.
5. **Quyết định có ý nghĩa:** chọn trồng gì, nuôi gì, đánh hay câu, học môn nào đều ảnh hưởng tiến trình.

### 1.2 Vòng lặp chơi (core loop)

| Chu kỳ | Người chơi làm gì | Phần thưởng |
| --- | --- | --- |
| 1 phút | Chặt, tưới, câu, đánh, giải 1 câu đố nhỏ | Vật phẩm, XP kỹ năng |
| 1 giờ game (10 phút thực) | Hoàn thành 1 việc cụ thể (thu hoạch luống, dọn hang, 1 bài học) | Xu, XP, tiến độ nhiệm vụ |
| 1 ngày | Chu trình: chăm nông trại → đi học/đi làm nhiệm vụ → khai thác/câu cá → ngủ | Tổng kết ngày, mở thêm nhiệm vụ |
| 1 mùa (7 ngày) | Hoàn thành 1–2 chương cốt truyện + lễ hội mùa | Mở map/kỹ năng/công trình |
| 1 năm | Thu thập đủ 5 Mảnh Sao, khôi phục Ngôi Sao Tri Thức | Kết thúc chính, tiếp tục chơi tự do |

### 1.3 Triết lý học tập

- Câu đố nằm **trong thế giới** (cửa khóa, máy móc, tính tiền, đổi vật phẩm) chứ không phải bài kiểm tra tách rời.
- 5 mảng tri thức: **Số (Toán), Chữ (Ngữ văn), Ngữ (Tiếng Anh), Vật (Khoa học tự nhiên), Ký (Lịch sử – Địa lý).**
- Độ khó **thích ứng** theo 5 bậc; sai không bị phạt, chỉ giảm số sao đánh giá.
- Có thể mở rộng ngân hàng câu hỏi bằng file JSON/CSV mà không cần sửa code.

---

## 2. Quy chuẩn kỹ thuật

| Hạng mục | Quy chuẩn |
| --- | --- |
| Engine | Godot 4.3+ (Forward+ tắt, dùng Compatibility/Mobile renderer cho 2D nhẹ) |
| Viewport gốc | 320×180, stretch mode `canvas_items`, aspect `keep`, scale nguyên (×4 = 720p, ×6 = 1080p) |
| Texture | Filter Nearest, tắt mipmap, snap 2D transform vào pixel |
| Tile | 16×16; nhân vật 16×32 (chân ở nửa dưới); NPC cùng chuẩn |
| Khung hình | 60 FPS, physics 60 Hz |
| Sắp xếp chiều sâu | Y-Sort bật cho lớp «Entities»; vật thể cao dùng điểm gốc ở chân |
| Dữ liệu | Resource `.tres` cho item/quest/monster/crop/animal; JSON cho ngân hàng câu hỏi và lịch NPC |
| Lưu game | JSON mã hóa nhẹ, 3 ô lưu + autosave mỗi lần ngủ, có `save_version` để migrate |
| i18n | `localization/*.csv`, khóa dạng `ITEM_TOMATO_NAME` |
| Plugin gợi ý | Dialogue Manager (hội thoại), GUT (unit test) |
| Giấy phép asset | Kiểm tra giấy phép thương mại trước khi dùng. Nguồn tham khảo: Sprout Lands, Ninja Adventure (CC0), LimeZu Modern Interiors |

### 2.1 Physics layers (đặt tên trong Project Settings)

| Layer | Tên | Dùng cho |
| --- | --- | --- |
| 1 | `world_solid` | Tường, nước sâu, vách đá, công trình |
| 2 | `player` | Nhân vật chính |
| 3 | `npc` | NPC |
| 4 | `monster` | Quái vật |
| 5 | `animal` | Động vật nuôi và hoang dã |
| 6 | `interactable` | Vật thể tương tác (Area2D) |
| 7 | `hitbox_player` | Đòn đánh của người chơi |
| 8 | `hitbox_monster` | Đòn đánh của quái |
| 9 | `pickup` | Vật phẩm rơi trên đất |
| 10 | `trigger` | Cổng map, vùng sự kiện, vùng câu cá |

---

## 3. Cấu trúc thư mục dự án

```
res://
├── project.godot
├── addons/                      # dialogue_manager, gut
├── assets/
│   ├── art/
│   │   ├── characters/          # body, eyes, hair, tops, bottoms, shoes, hats, accessories, tool_overlays
│   │   ├── tilesets/            # spring, summer, autumn, winter, interior, shared
│   │   ├── buildings/  props/  items/  plants/  animals/  monsters/
│   │   ├── fx/                  # mưa, tuyết, lá rơi, hạt sáng, hit_spark
│   │   ├── ui/                  # khung, nút, icon, bar
│   │   └── portraits/           # chân dung NPC khi hội thoại
│   ├── audio/  (bgm/, sfx/, ambience/)
│   ├── fonts/
│   └── shaders/                 # palette_swap, water, fog, snow_overlay, outline
├── data/
│   ├── items/  crops/  animals/  monsters/  quests/  npcs/  recipes/
│   ├── questions/               # ngân hàng câu hỏi theo môn: math.json, literature.json, english.json, science.json, history_geo.json
│   ├── schedules/               # lịch NPC theo ngày
│   ├── weather/  loot_tables/  shops/
│   └── balance/                 # xp_curve.tres, price_table.tres
├── scenes/
│   ├── core/        # boot.tscn, main.tscn, title_screen.tscn, loading_screen.tscn
│   ├── maps/        # farm_main.tscn, town_square.tscn, ...
│   ├── buildings/   # exterior/ và interior/
│   ├── entities/    # player/, npc/, monsters/, animals/, plants/, pickups/
│   ├── ui/          # hud/, menus/, dialogs/, shop/, quest_log/
│   ├── minigames/   # math/, literature/, english/, science/, history_geo/, fishing/
│   └── fx/          # weather/, lighting/, hit_effects/
├── scripts/
│   ├── autoload/    # game_clock, weather_system, season_system, event_bus, save_manager,
│   │                # inventory_manager, quest_manager, knowledge_manager, audio_manager,
│   │                # scene_manager, item_database, settings_manager
│   ├── components/  # health_component, stamina_component, hitbox, hurtbox, interactable,
│   │                # inventory_component, equipment_component, state_machine, loot_dropper
│   ├── resources/   # class ItemData, CropData, AnimalData, MonsterData, QuestData, MapStateData...
│   ├── systems/     # farming, fishing, combat, crafting, shop, npc_schedule, spawn_director
│   ├── entities/    # player.gd, npc.gd, monster.gd, animal.gd, plant.gd
│   ├── ui/
│   └── utils/
├── localization/
├── tests/           # GUT
└── docs/            # GDD, API notes, changelog
```

**Quy ước đặt tên:** file và biến `snake_case`; class `PascalCase`; signal là động từ quá khứ (`item_added`, `quest_completed`); hằng số `UPPER_SNAKE_CASE`; scene và script cùng tên.

### 3.1 Autoload (singleton) và trách nhiệm

| Autoload | Trách nhiệm |
| --- | --- |
| `EventBus` | Tập hợp signal toàn cục, không chứa logic |
| `GameClock` | Thời gian, ngày, tuần, mùa, năm; phát tín hiệu mỗi phút game |
| `SeasonSystem` | Bộ tileset/bảng màu theo mùa, tuổi cây, hoạt động theo mùa |
| `WeatherSystem` | Sinh thời tiết có seed, dự báo, điều kiện đặc biệt |
| `SceneManager` | Chuyển map, fade, giữ vị trí vào/ra cổng |
| `InventoryManager` | Túi đồ, hotbar, rương, quy tắc xếp chồng |
| `QuestManager` | Trạng thái nhiệm vụ, mục tiêu, phần thưởng |
| `KnowledgeManager` | Ngân hàng câu hỏi, bậc khó, điểm 5 mảng tri thức |
| `SaveManager` | Lưu/tải toàn bộ, migrate phiên bản |
| `AudioManager` | Nhạc theo map/giờ/thời tiết, hiệu ứng âm thanh |
| `ItemDatabase` | Tra cứu `ItemData` theo `item_id` |
| `SettingsManager` | Âm thanh, phím, ngôn ngữ, trợ năng |

---

## 4. Hệ thống thời gian, mùa và thời tiết

### 4.1 Hằng số thời gian

- **1 ngày game = 24 giờ game = 240 phút thực = 14.400 giây thực.**
- **1 giờ game = 10 phút thực. 1 phút game = 10 giây thực.**
- Đồng hồ HUD nhảy theo bước **10 phút game (= 100 giây thực)**; nội bộ tính liên tục để ánh sáng chuyển mượt.
- Ngày mới bắt đầu lúc **06:00**. Người chơi chơi được từ 06:00 đến **02:00 sáng hôm sau** (20 giờ game = 200 phút thực). 40 phút thực còn lại (02:00–06:00) bị **bỏ qua** khi ngủ.
- **Tạm dừng thời gian** khi: mở menu/túi đồ, hội thoại, cutscene, đang ở màn đố/học. **Thời gian vẫn chạy** trong công trình và khi câu cá/đánh quái.
- Tuần 7 ngày (Thứ Hai → Chủ Nhật). **1 mùa = 7 ngày = 1 tuần**, nên ngày 1 mỗi mùa luôn là Thứ Hai và ngày 7 là Chủ Nhật (ngày lễ hội).
- Năm = 4 mùa = 28 ngày: **Xuân → Hạ → Thu → Đông**.

```gdscript
# scripts/autoload/game_clock.gd (khung tối giản)
extends Node

const REAL_SECONDS_PER_GAME_DAY: float = 14400.0
const GAME_MINUTES_PER_DAY: int = 1440
const DAY_START_MINUTE: int = 360        # 06:00
const FORCED_SLEEP_MINUTE: int = 1560    # 26:00 = 02:00 hôm sau
const DAYS_PER_SEASON: int = 7
const SEASONS_PER_YEAR: int = 4

signal minute_changed(total_minute_of_day: int)
signal hour_changed(hour: int)
signal day_started(day_index: int)
signal season_changed(season_index: int)
signal forced_sleep_triggered

var total_game_minutes: float = 360.0
var is_time_paused: bool = false

func _process(delta_seconds: float) -> void:
	if is_time_paused:
		return
	var game_minutes_per_real_second: float = float(GAME_MINUTES_PER_DAY) / REAL_SECONDS_PER_GAME_DAY
	total_game_minutes += delta_seconds * game_minutes_per_real_second
```

### 4.2 Các pha trong ngày và ánh sáng

Giờ mặt trời mọc (S) và lặn (D) thay đổi theo mùa (mục 4.3). Ánh sáng dùng `CanvasModulate` nội suy theo bảng, kết hợp `PointLight2D` cho đèn.

| Pha | Khoảng giờ | Màu CanvasModulate | Hiệu ứng đi kèm |
| --- | --- | --- | --- |
| Bình minh | S−1h → S+1h | `#FFC9A0` | Sương mỏng, tiếng chim, bóng dài hướng tây |
| Sáng | S+1h → 11:00 | `#FFFFFF` | Nền tảng, NPC ra khỏi nhà |
| Trưa | 11:00 → 15:00 | `#FFFFF0` | Bóng ngắn nhất, nóng hơn (mùa Hạ) |
| Chiều | 15:00 → D−1h | `#FFF0C8` | Ánh vàng, bóng dài hướng đông |
| Hoàng hôn | D−1h → D+1h | `#E8A0A0` → `#8070B0` | Đèn đường bật, đom đóm xuất hiện |
| Tối | D+1h → 23:00 | `#5060A0` | Quái đêm xuất hiện, cửa hàng đóng |
| Khuya | 23:00 → S−1h | `#3A4478` | Chỉ còn đèn nhà, nhắc người chơi đi ngủ từ 00:00 |

Bóng đổ: sprite bóng đơn giản xoay và co theo giờ (không dùng shadow động tốn kém). Đèn tự bật khi `light_level` < 0.55.

### 4.3 Bốn mùa

| Mùa | Mọc / Lặn | Bảng màu và tileset | Địa hình đặc trưng | Nhiệt độ gốc |
| --- | --- | --- | --- | --- |
| Xuân | 06:00 / 19:00 | Xanh non, hồng đào | Hoa nở, cỏ cao, suối đầy | 22°C |
| Hạ | 05:30 / 20:00 | Xanh đậm, vàng nắng | Cây um tùm, hồ lấp lánh, cát nóng | 33°C |
| Thu | 06:30 / 18:30 | Cam, đỏ, nâu | Lá rụng, bí ngô, nấm mọc nhiều | 20°C |
| Đông | 07:00 / 17:30 | Xanh lạnh, trắng | Tuyết phủ, mặt hồ đóng băng, cây trụi lá | 5°C |

Quy tắc chuyển mùa (lúc 06:00 ngày 1): đổi tileset, đổi hệ thực vật, cây trồng không hợp mùa **héo** (trừ trong Nhà kính), reset bảng cửa hàng theo mùa, bật sự kiện mùa.

### 4.4 Thời tiết cơ bản

**Xác suất theo mùa (% mỗi ngày):**

| Thời tiết | Xuân | Hạ | Thu | Đông |
| --- | --- | --- | --- | --- |
| Nắng | 45 | 55 | 35 | 25 |
| Nhiều mây | 15 | 10 | 20 | 25 |
| Mưa phùn | 15 | 5 | 10 | 0 |
| Mưa | 15 | 12 | 20 | 5 |
| Giông bão | 5 | 13 | 5 | 0 |
| Sương mù | 5 | 0 | 10 | 5 |
| Gió lớn | 0 | 0 | 0 | 0 |
| Nóng gay gắt | 0 | 5 | 0 | 0 |
| Tuyết | 0 | 0 | 0 | 30 |
| Bão tuyết | 0 | 0 | 0 | 10 |

*(Gió lớn chỉ xuất hiện như **điều kiện đặc biệt** của mùa Thu, xem 4.5. Hàng này giữ 0 để tổng mỗi cột = 100.)*

**Quy tắc sinh thời tiết (luật riêng):**

1. Dùng RNG có seed: `seed = hash(world_seed, year, season, day)`. Cùng seed ra cùng thời tiết, dễ test và tránh «save scumming».
2. Thời tiết ngày N được sinh khi ngày N−1 bắt đầu, nên luôn có **dự báo** ngày mai (TV, bảng tin quảng trường). Dự báo đúng 90%, sai thì lệch 1 bậc (nắng ↔ mây, mưa ↔ giông).
3. Ngày 1–3 của game và mọi **ngày lễ hội = Nắng**.
4. Không có 2 ngày liên tiếp cùng loại «nặng» (Giông bão, Bão tuyết, Nóng gay gắt).
5. Mỗi ngày có tối đa **2 chuyển pha** (ví dụ: nhiều mây → mưa từ 14:00 → tạnh lúc 18:00), lưu thành `weather_segments`.
6. Mưa tăng `wetness` +0.1 mỗi giờ (tối đa 1), nắng giảm 0.05 mỗi giờ. Tuyết tăng `snow_cover` +0.15 mỗi giờ, nắng tan 0.1 mỗi giờ.

### 4.5 Điều kiện thời tiết đặc biệt

| Điều kiện | Điều kiện kích hoạt | Tác động | Cách đối phó / lợi ích |
| --- | --- | --- | --- |
| Giông sét | Là một dạng của Giông bão | 1%/giờ sét đánh vật cao nhất ngoài trời; quái điện xuất hiện | Cọc thu lôi bảo vệ bán kính 8 ô; rơi «Mảnh Sét» |
| Sương Quên | 5–10% vào Xuân/Thu/Đông, thường lúc bình minh | Tầm nhìn giảm (shader, bán kính 6 ô); Ma Sương xuất hiện; nguy cơ trúng trạng thái «Quên» | Đèn Lồng Tri Thức; thu hoạch nấm hiếm |
| Nóng gay gắt | 5% mùa Hạ | Tiêu hao thể lực ngoài trời +25%; đất khô lúc 12:00 (phải tưới lần 2) | Nước mát, kem, mũ rộng vành; cá nổi gần bờ |
| Bão tuyết | 10% mùa Đông | Tốc độ ngoài trời −20%; mất 1 HP/10 giây nếu không mặc Áo Ấm; cửa hàng ngoài trời đóng | Áo Ấm, lò sưởi; mặt hồ đóng băng, mở lỗ câu cá băng |
| Gió lớn | 15% các ngày Thu (cộng thêm) | Lá và hạt bay; cây rụng thêm hạt | Hái hạt dẻ, hạt giống +30%; mini-game thả diều |
| Mưa sao băng | 4% đêm quang bất kỳ mùa nào | 1–3 điểm «Bụi Sao» xuất hiện ngoài trời | Nhặt trước 02:00; mở nhiệm vụ ẩn |
| Trăng Tròn | Đêm ngày 4 mỗi mùa | Bầy sói có Alpha, quái tinh anh +20%; chỉ lúc này mới nở «Hoa Nguyệt» | Rừng nguy hiểm hơn nhưng thưởng cao |
| Cầu vồng | 10% sau ngày mưa, khoảng 15:00–17:00 | Buff May mắn +10 trong ngày | Cá Cầu Vồng dễ xuất hiện ở Hồ Gương |
| Lễ hội | Ngày 7 mỗi mùa | Map lễ hội mở, cửa hàng thường đóng, nhiệm vụ sự kiện | Xem mục 9 |

### 4.6 Tác động của thời tiết lên các hệ thống

| Thời tiết | Cây trồng | Câu cá | Quái vật | NPC | Thể lực / HP |
| --- | --- | --- | --- | --- | --- |
| Nắng | Bình thường | Bình thường | Bình thường | Lịch thường | Bình thường |
| Mưa / Mưa phùn | **Tự tưới** cây ngoài trời | +20% tỉ lệ cắn câu, cá mưa xuất hiện | Slime mực nhiều hơn | Phần lớn ở trong nhà | Không đổi |
| Giông bão | Tự tưới; nguy cơ sét | Cá điện | Quái điện | Ở trong nhà | Sét gây 30 HP nếu bị đánh |
| Sương mù | Bình thường | Cá hiếm hơn | Ma Sương, tầm nhìn thấp | Đi chậm | Nguy cơ «Quên» |
| Nóng gay gắt | Mất nước nhanh | Cá lặn sâu | Ít quái | Ra bóng râm | +25% thể lực ngoài trời |
| Tuyết | Cây ngoài trời không mọc (trừ ô sương giá) | Câu băng | Sói tuyết | Mặc áo ấm | Chậm 10% |
| Bão tuyết | Như tuyết | Chỉ câu băng | Nhiều sói tuyết | Ở trong nhà | Chậm 20%, mất HP nếu không ấm |

### 4.7 `MapStateData` — trạng thái của một map

Mỗi map giữ một Resource mô tả **trạng thái hiện tại**, các hệ thống khác chỉ đọc nó:

| Trường | Kiểu | Ý nghĩa |
| --- | --- | --- |
| `map_id` | String | Định danh map |
| `season` | enum | Xuân/Hạ/Thu/Đông |
| `time_phase` | enum | Bình minh … Khuya |
| `light_level` | float 0–1 | Điều khiển đèn, bóng |
| `weather_segments` | Array | Danh sách {giờ bắt đầu, loại thời tiết} |
| `special_flags` | Array\[String\] | `fog_of_forgetting`, `full_moon`, `meteor_shower`, `rainbow`, `festival` |
| `wetness` | float 0–1 | Vũng nước, đất ướt |
| `snow_cover` | float 0–1 | Lớp tuyết phủ |
| `temperature` | int | °C, ảnh hưởng trang bị/hiệu ứng |
| `is_open` | bool | Công trình/khu vực có mở cửa không |
| `event_overlay` | String | Trang trí lễ hội |

**Thứ tự áp dụng hiển thị:** tileset theo mùa → lớp tuyết phủ → độ ướt (vũng nước) → CanvasModulate theo pha → hạt thời tiết (mưa, tuyết, lá) → hiệu ứng đặc biệt (sương, sao băng) → gợi ý UI.

---

## 5. Thế giới: Thị trấn Sao Mai và các khu vực

### 5.1 Sơ đồ kết nối

```
                    [Núi Mây]
                        |
 [Rừng Thì Thầm]--[Đồi Thư Viện]--[Hồ Gương & Sông Bạc]
       |                |                    |
 [Hầm Đá Thì Thầm] [Quảng Trường]----[Bãi Biển Sóng Vàng]
                   /    |     \
  [Nông Trại]--[Phố Chợ]  [Trường Ánh Dương]
       |
 [Đồng Cỏ Cỏ Xanh]
```

Nông Trại còn nối trực tiếp với Rừng Thì Thầm (lối tắt phía bắc, mở sau chương 1).

### 5.2 Danh sách map

| ID | Tên | Kích thước (tile) | Chủ đề và vai trò | Mở khóa |
| --- | --- | --- | --- | --- |
| `farm_main` | Nông Trại Mầm Xanh | 80×60 | Nhà người chơi, đất canh tác, chuồng trại, nhà kính, silo | Từ đầu |
| `ranch` | Đồng Cỏ Cỏ Xanh | 60×44 | Trại của cô Mai, bãi chăn thả, mua động vật | Từ đầu (shop mở sau chương 1) |
| `market_street` | Phố Chợ | 56×32 | Tiệm tạp hóa, lò rèn, phòng khám, quán ăn | Từ đầu |
| `town_square` | Quảng Trường Sao Mai | 64×48 | Trung tâm làng, bảng nhiệm vụ, đài phun nước, sân lễ hội | Từ đầu |
| `school_grounds` | Trường Ánh Dương | 48×36 | Lớp học, sân trường, vườn thực nghiệm | Từ đầu (lớp mở sau chương 1) |
| `library_hill` | Đồi Thư Viện | 40×32 | Thư viện cổ, bảo tàng, hầm sách | Từ đầu (hầm sách khóa đến chương 3) |
| `whispering_forest` | Rừng Thì Thầm | 90×70 | Hái lượm, chặt cây, quái nhẹ, bầy sói đêm | Sau chương 1 |
| `stone_mine` | Hầm Đá Thì Thầm | 40 tầng × 40×30 | Khai thác khoáng, quái, boss ở tầng 10/20/30/40 | Chương 1 và Cấp Cư Dân ≥ 3 |
| `mirror_lake` | Hồ Gương & Sông Bạc | 60×44 | Câu cá, vịt trời, cầu gỗ, thác nhỏ | Từ đầu |
| `golden_beach` | Bãi Biển Sóng Vàng | 70×40 | Thủy triều, cua, bến cảng, thủy thủ ngoại quốc | Sau nhiệm vụ sửa cầu Hồ Gương |
| `cloud_mountain` | Núi Mây | 80×80 | Leo núi, đài thiên văn, đỉnh tuyết quanh năm | Chương 5 và Cấp Cư Dân ≥ 8 |

### 5.3 Hồ sơ từng map: công trình, trạng thái đặc thù và quy luật riêng

| Map | Công trình và khu vực chức năng | Trạng thái / quy luật đặc thù |
| --- | --- | --- |
| Nông Trại | Nhà (nâng cấp 3 bậc), hòm gửi hàng, giếng, chuồng gà, chuồng bò, silo, nhà kính, khu đất canh tác 24×16 ô, bãi đá và gốc cây cần dọn | Mỗi ô đất có trạng thái: cỏ → đã cuốc → đã tưới → đã bón → đã gieo. Mưa tự tưới. Qua ngày: ô không tưới trở lại "khô". Đổi mùa: cây trái mùa héo. Không có quái ban ngày, quái nhẹ lẻ tẻ vào đêm trăng tròn |
| Đồng Cỏ | Nhà cô Mai, bãi cỏ chăn thả, chuồng mẫu, bảng giá động vật | Cỏ mọc lại 1 ô/ngày vào Xuân-Hạ-Thu, chết dần vào Đông. Mưa làm cỏ mọc nhanh gấp đôi |
| Phố Chợ | Tiệm tạp hóa, Lò rèn, Phòng khám, Quán Hương Lúa, sạp ngoài trời | Cửa hàng chỉ mở theo giờ (mục 5.5). Chợ phiên Chủ Nhật có sạp phụ. Bão tuyết đóng sạp ngoài trời |
| Quảng Trường | Đài phun nước, bảng nhiệm vụ hàng ngày, bảng tin dự báo thời tiết, ghế đá, sân khấu lễ hội | Là điểm hẹn NPC. Đài phun nước đóng băng vào Đông. Ngày lễ: dựng sân khấu và gian hàng |
| Trường Ánh Dương | Lớp học chính, phòng thí nghiệm, sân bóng, vườn thực nghiệm, phòng hiệu trưởng | Lớp học diễn ra 08:00–10:00 và 14:00–16:00 ngày thường. Cuối tuần: sân trường mở, lớp đóng |
| Đồi Thư Viện | Thư viện cổ (2 tầng), bảo tàng nhỏ, hầm sách bị khóa, vườn đọc sách | Vườn đọc có băng ghế dưới tán cây, mùa Thu lá vàng rơi. Hầm sách chỉ mở sau chương 3 |
| Rừng Thì Thầm | Lối mòn, khoảng trống nấm, gốc cổ thụ, trại thợ rừng, hang sói | Ban ngày yên bình (hái lượm), ban đêm sói và slime mực xuất hiện. Sương Quên làm rừng nguy hiểm gấp đôi |
| Hầm Đá | Sảnh hầm (thang máy, lều nghỉ), 40 tầng sinh ngẫu nhiên theo seed ngày | Không bị ảnh hưởng thời tiết. Mỗi tầng có cầu thang xuống, rương, điểm đào. Tầng sinh lại mỗi ngày |
| Hồ Gương & Sông Bạc | Bến câu, cầu gỗ, nhà thuyền, thác nhỏ, bãi sậy | Mặt hồ đóng băng vào Đông, nước lên cao sau mưa lớn (cầu ngập 1 ngày). Đom đóm vào đêm Hạ |
| Bãi Biển | Cầu cảng, nhà ngư dân, hang đá thủy triều, bãi san hô | **Thủy triều** chu kỳ 6 giờ game (xuống thấp tiết lộ ao nước đọng chứa vỏ sò, sao biển). Giông bão làm sóng cao, cấm xuống mép nước |
| Núi Mây | Đường mòn leo, trạm dừng chân, thác, đài thiên văn trên đỉnh | Tuyết phủ quanh năm từ độ cao 2. Sương mù dày vào sáng sớm. Trên đỉnh nhìn thấy sao rõ hơn (nhiệm vụ thiên văn) |

### 5.4 Chuyển map

- Cổng chuyển map là node `MapPortal` (Area2D, layer `trigger`) có `target_map_id`, `target_spawn_id`, `unlock_conditions[]`.
- Hiệu ứng: mờ dần 0,25 giây → tải scene → mờ hiện 0,25 giây. Thời gian game vẫn chạy.
- Map được **cache** sau lần tải đầu (giữ trạng thái đất, rương, vật rơi). Thực thể có `persistent_id` để lưu/khôi phục.
- Camera mỗi map có `limit_*` đúng kích thước map, theo nhân vật với độ trễ nhẹ (smoothing 6).
- Chuyển vào công trình dùng cùng cơ chế nhưng sang scene nội thất riêng, nhạc nền riêng.

### 5.5 Giờ hoạt động (mặc định, NPC và cửa hàng)

| Địa điểm | Giờ mở | Ngày nghỉ |
| --- | --- | --- |
| Tiệm tạp hóa | 09:00–19:00 | Chủ Nhật (chợ phiên thay thế) |
| Lò rèn | 10:00–17:00 | Thứ Bảy |
| Phòng khám | 08:00–16:00 | Không nghỉ (cấp cứu 24/7, trả phí) |
| Quán Hương Lúa | 11:00–22:00 | Không nghỉ |
| Thư viện | 09:00–18:00 | Thứ Hai |
| Trường học | Lớp 08:00–10:00, 14:00–16:00 | Thứ Bảy, Chủ Nhật |
| Đài thiên văn | 19:00–02:00 | Không nghỉ |

Ngày lễ hội: mọi cửa hàng thường **đóng**, chỉ gian hàng lễ hội mở. Cửa đóng: nhân vật gõ cửa, NPC trong nhà trả lời một câu theo ngữ cảnh.

---

## 6. Công trình, vật phẩm bên trong và tương tác

### 6.1 Chuẩn thiết kế một công trình

**Bên ngoài (exterior scene):**

- Gồm `BodySprite`, `RoofSprite` (ẩn dần khi nhân vật đi vào vùng phía sau/mái), `DoorPortal`, `CollisionPolygon2D` chỉ phủ phần chân tường, `SignLabel` (biển hiệu có chữ), `LightPoints` (cửa sổ phát sáng khi light\_level < 0,55).
- Cửa luôn có **1 ô trống phía trước** để nhân vật đứng; ô này là điểm spawn khi ra khỏi nhà.
- Kích thước chuẩn: nhỏ 4×4 ô (chuồng gà), vừa 6×5 (tiệm), lớn 9×7 (trường, thư viện).

**Bên trong (interior scene):**

- Nhiều lớp TileMap: `Floor`, `Wall`, `Furniture_Back`, `Entities` (Y-sort), `Furniture_Front`, `Light`.
- Có `SpawnPoint_FromOutside`, `AmbienceBus`, danh sách `InteractableSlot` đặt sẵn.
- Cửa sổ chiếu ánh sáng theo giờ (tia sáng xiên ban ngày, tối đen ban đêm trừ đèn).
- Trong nhà: không có thời tiết, nhưng có **âm thanh mưa/gió** vọng nhẹ qua tường.

### 6.2 Mô hình tương tác (`Interactable`)

**Luồng chuẩn (mọi thứ đều đi qua luồng này):**

1. **Phát hiện:** `InteractionDetector` (Area2D hình chữ nhật 20×20 lệch về hướng nhân vật đang nhìn). Chọn mục tiêu ưu tiên: NPC > Trạm (Station) > Rương > Vật trang trí; hòa thì chọn gần nhất.
2. **Gợi ý:** viền sáng (shader outline) + icon phím "E" nổi phía trên + 1 dòng mô tả ngắn.
3. **Kiểm tra điều kiện:** vật đang cầm, kỹ năng, giờ, nhiệm vụ, thể lực.
4. **Thực hiện:** nhấn thường (E) hoặc giữ 0,5 giây (hành động quan trọng/phá hủy).
5. **Hoạt ảnh và âm thanh** của nhân vật và vật thể.
6. **Áp dụng kết quả:** thay đổi trạng thái, trao/nhận vật phẩm, mở UI.
7. **Phát tín hiệu** lên `EventBus` (`interacted_with`) để quest, thành tích, âm thanh bắt.
8. **Lưu trạng thái** nếu vật thể có `persistent_id`.

**Các loại tương tác:**

| Loại | Ví dụ | Kết quả |
| --- | --- | --- |
| Examine | Tranh, biển, kệ sách | Hiện 1–2 dòng mô tả, có thể mở manh mối/nhiệm vụ ẩn |
| Talk | NPC | Mở hội thoại, nhận/nộp nhiệm vụ, tặng quà |
| Container | Rương, tủ, thùng | Mở UI kho đồ hai bên |
| Station | Bếp, lò nung, bàn chế tạo, máy ép | Mở UI công thức, chạy quy trình theo thời gian game |
| Shop | Quầy hàng | Mở UI mua/bán |
| Sleep | Giường | Hỏi xác nhận, kết thúc ngày, hiện tổng kết |
| Door | Cửa, cổng | Chuyển map nếu đủ điều kiện, nếu đóng thì gõ cửa |
| Puzzle | Khóa số, bảng chữ, bàn thí nghiệm | Mở mini-game, kết quả mở khóa hoặc trao thưởng |
| UseItemOn | Hạt giống lên đất, chìa khóa lên cửa, thức ăn lên máng | Cần đang cầm đúng vật phẩm |
| Toggle | Đèn, lò sưởi, cửa sổ | Đổi trạng thái bật/tắt |
| Pickup | Vật rơi, cây hái được | Nhận vật phẩm vào túi |

### 6.3 Danh mục công trình và vật phẩm bên trong

**Nhà người chơi** (nội thất nâng cấp 3 bậc: phòng đơn → thêm bếp → thêm tầng hầm và phòng khách)

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Giường | Sleep | E | Qua ngày, hồi thể lực (xem 7.4), lưu tự động |
| Rương cá nhân (×1 → ×3) | Container | E | Cất 36 ô mỗi rương |
| Bếp | Station | E | Nấu món ăn từ nguyên liệu, mất 10–60 phút game |
| Bàn chế tạo | Station | E | Chế tạo công cụ, đồ đặt (mở công thức theo tri thức) |
| Tủ quần áo | Container đặc biệt | E | Mở màn thay đồ (trang bị/thời trang) |
| Bàn học | Puzzle | E | Làm bài ôn tập cá nhân, nhận XP tri thức |
| TV | Examine | E | Xem dự báo thời tiết ngày mai và bản tin làng |
| Lò sưởi | Toggle | E | Mùa Đông: ấm, hồi nhẹ HP khi ngồi cạnh |
| Hòm thư | Container | E (ngoài sân) | Nhận thư, quà, thông báo nhiệm vụ |

**Trường Ánh Dương** (lớp học, phòng thí nghiệm)

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Bàn học sinh (×12) | Puzzle | E khi vào giờ học | Tham gia buổi học: chuỗi 5 câu đố, XP tri thức |
| Bảng đen | Examine/Puzzle | E | Đề bài trong ngày; giải đúng nhận thưởng nhỏ |
| Bàn cô Lan | Talk | E | Giao nhiệm vụ lớp, nhận điểm danh |
| Bàn thí nghiệm | Station/Puzzle | E | Mini-game khoa học: pha chất, nối mạch điện |
| Quả địa cầu, bản đồ | Examine/Puzzle | E | Câu hỏi Sử – Địa, mở bản đồ chi tiết |
| Tủ sách lớp | Container | E | Mượn sách học (vật phẩm "Sách") |
| Chuông trường | Toggle | E | Chỉ dùng trong nhiệm vụ đặc biệt |

**Thư viện cổ** (2 tầng + hầm sách)

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Kệ sách theo môn | Examine/Container | E | Mượn/trả sách, mỗi sách là 1 vật phẩm học |
| Bàn thủ thư | Talk | E | Nhận nhiệm vụ thư viện, gia hạn sách |
| Máy tra mục lục | Puzzle | E | Câu đố sắp xếp, tra tìm nhiệm vụ ẩn |
| Cầu thang xoắn | Door | E | Lên tầng 2 (khu sách cổ) |
| Cửa hầm sách | Door/Puzzle | UseItemOn (Chìa Mực) | Mở hầm bí mật (cốt truyện chương 3) |
| Bảo tàng nhỏ: tủ kính | Examine | E | Mở mục "Bách khoa" khi trưng bày đủ món |

**Tiệm tạp hóa (Dì Năm)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Quầy thu ngân | Shop | E | Mua hạt giống, thức ăn gia súc, vật dụng; bán nông sản |
| Kệ hạt giống theo mùa | Examine | E | Hiện danh sách hạt giống đang bán mùa này |
| Bảng giá | Examine/Puzzle | E | Nhiệm vụ toán: tính tiền thối, giảm giá |
| Thùng hàng đặt trước | Container | E (khi có đơn) | Nhận đơn đã đặt |

**Lò rèn (Chú Ba)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Lò nung | Station | E | Nung quặng thành thỏi (thời gian game) |
| Đe | Station | E | Nâng cấp công cụ/vũ khí, mất 2 ngày game |
| Giá vũ khí | Shop | E | Mua vũ khí cơ bản |
| Bàn mài | Station | E | Mài lại vũ khí (hồi độ sắc nếu có hệ độ bền) |

**Phòng khám (Bác sĩ Minh)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Giường bệnh | Station | E | Trả phí để hồi đầy HP và xóa trạng thái xấu |
| Tủ thuốc | Shop | E | Mua thuốc, thuốc giải "Quên" |
| Bảng cơ thể | Puzzle | E | Câu đố khoa học về cơ thể, mở công thức thuốc |

**Quán Hương Lúa (Chị Vy)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Quầy | Shop | E | Mua món ăn có buff |
| Bàn ăn | Examine/Toggle | E | Ngồi ăn: hồi nhanh, trò chuyện NPC ngồi cạnh |
| Thực đơn | Examine | E | Mở công thức món đã học |
| Bảng sự kiện | Examine | E | Hiện thông báo lễ hội |

**Đài thiên văn (Lão Quang)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Kính thiên văn | Puzzle | E (ban đêm, trời quang) | Mini-game tìm chòm sao, mở manh mối cốt truyện |
| Bàn tinh tú | Station | E | Đặt Mảnh Sao vào đài, theo dõi tiến độ 5 mảnh |
| Trụ Ngôi Sao | Examine/Puzzle | E | Điểm kết thúc cốt truyện |

**Chuồng gà / Chuồng bò (trên nông trại)**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Máng ăn | UseItemOn | Cầm cỏ khô + E | Đổ thức ăn, động vật tự ăn |
| Máng nước | UseItemOn | Cầm bình tưới + E | Đổ nước |
| Ổ đẻ / Chỗ vắt sữa | Pickup/UseItemOn | E / cầm xô sữa | Thu trứng, vắt sữa |
| Lò sưởi chuồng | Toggle | E | Mùa Đông giữ ấm cho động vật |
| Cửa chuồng | Toggle | E | Mở thả ra ngoài / đóng giữ ban đêm |
| Bảng thông tin | Examine | E | Xem chỉ số từng động vật |

**Nhà kính và Silo**

| Vật phẩm | Loại | Tương tác | Kết quả |
| --- | --- | --- | --- |
| Luống đất nhà kính | UseItemOn | Giống như đất ngoài trời | Trồng quanh năm, không bị thời tiết |
| Hệ thống tưới tự động | Toggle | E | Mở sau chương 4 |
| Silo | Container đặc biệt | E | Cất cỏ khô (tối đa 240 bó), rút ra khi cho ăn |

### 6.4 Người chơi tương tác với công trình

| Hành động | Cách thực hiện | Điều kiện |
| --- | --- | --- |
| Vào / ra | Đi vào ô cửa hoặc nhấn E | Công trình đang mở, đủ điều kiện mở khóa |
| Gõ cửa | E khi đóng | Luôn được, NPC trả lời |
| Mua / bán | Mở Shop, kéo thả hoặc nhấn Enter | Đủ Xu hoặc có hàng |
| Nhận / nộp nhiệm vụ | Nói chuyện với NPC giao nhiệm vụ | Đúng trạng thái nhiệm vụ |
| Ngủ | Giường → xác nhận | Sau 20:00 mới ngủ được (trừ khi kiệt sức) |
| Học | Bàn học / lớp học | Đúng giờ, đủ thể lực tối thiểu 10 |
| Nấu, chế, nung | Station → chọn công thức | Có nguyên liệu, trạm trống |
| Chữa bệnh | Giường bệnh | Đủ Xu |

---

## 7. Nhân vật người chơi

### 7.1 Tạo nhân vật (ở màn bắt đầu game mới)

- Nhập **tên** và **tên nông trại**; chọn **thú cưng** (mèo hoặc chó, đi theo và là bạn đồng hành, không chiến đấu).
- Ngoại hình: 2 kiểu cơ thể, 8 màu da, 14 kiểu tóc × 16 màu, 8 màu mắt, 3 bộ trang phục khởi đầu.
- Chọn **môn học yêu thích** (1 trong 5): nhận 1 cuốn sách khởi đầu của môn đó và +50 XP tri thức môn đó.
- Xem trước nhân vật xoay đủ 4 hướng, có nút ngẫu nhiên. Mọi lựa chọn ngoại hình đổi được sau ở **Tủ quần áo** trong nhà.

### 7.2 Nhân vật ghép từ các lớp sprite

Mỗi lớp là một spritesheet riêng, **cùng kích thước khung 16×32 và cùng lưới hoạt ảnh**, nên một `AnimationPlayer` điều khiển thuộc tính `frame` của tất cả lớp cùng lúc.

| Thứ tự vẽ (dưới → trên) | Lớp | Ghi chú |
| --- | --- | --- |
| 0 | Bóng (shadow) | Ellipse mờ dưới chân, không đổi |
| 1 | Đồ lưng (balo, áo choàng) | Khi quay lên: vẽ **trên** thân; quay xuống: vẽ **dưới** thân |
| 2 | Thân + đầu (body) | Đổi màu da bằng palette swap |
| 3 | Quần |  |
| 4 | Giày |  |
| 5 | Áo |  |
| 6 | Mắt, mặt | Kính nằm ở lớp phụ kiện mặt |
| 7 | Tóc | Mũ có cờ `hide_hair` để ẩn tóc |
| 8 | Mũ |  |
| 9 | Phụ kiện mặt/cổ |  |
| 10 | Vật phẩm cầm tay (`HandItem`) | Vị trí lấy từ bảng neo tay (7.3) |

- **Bố cục sheet:** mỗi hàng 1 hướng (Xuống, Lên, Trái; Phải = lật ngang Trái), mỗi cột 1 khung hình. Tên file: `{layer}_{style_id}.png`.
- **Palette swap:** sprite gốc dùng 4 sắc độ tham chiếu (viền, tối, chính, sáng). Shader thay thế từng sắc độ bằng 4 màu của người chơi chọn (tóc, da, mắt, áo...), nên 1 sprite cho vô số màu.
- Vật phẩm trang bị bổ sung lớp tương ứng; **không đổi hoạt ảnh gốc**, chỉ thêm/ẩn lớp.

### 7.3 Danh sách hoạt ảnh và neo tay

| Hoạt ảnh | Số khung | FPS | Ghi chú |
| --- | --- | --- | --- |
| `idle` | 2 | 2 | Thở nhẹ; sau 20 giây đứng yên: nhìn quanh |
| `walk` | 6 | 10 | Mỗi hướng |
| `run` | 6 | 14 | Cúi người, bụi chân |
| `tool_swing` | 4 | 14 | Cuốc, rìu, cuốc chim, lưỡi hái |
| `water` | 4 | 10 | Tưới, có nước bắn |
| `attack_*` | 4–5 | 14 | Mỗi loại vũ khí 1 bộ (kiếm, giáo, búa) |
| `fish_cast` / `fish_wait` / `fish_reel` | 5 / 2 / 4 | 10 | Quăng, chờ, kéo |
| `pickup` | 3 | 10 | Cúi nhặt |
| `carry_walk` | 6 | 8 | Bưng vật nặng (đá lớn, thùng) |
| `eat` | 4 | 8 | Ăn/uống |
| `read` | 2 | 3 | Đọc sách (bắt đầu mini-game học) |
| `hurt` | 2 | 12 | Trúng đòn, bật lùi 6 pixel |
| `roll` | 6 | 16 | Lăn né (mở khóa ở 7.7) |
| `faint` | 4 | 6 | Ngất xỉu |
| `sit` / `sleep` | 1 | 0 | Ngồi ghế, nằm giường |

**Bảng neo tay:** file `data/balance/hand_anchors.json`, mỗi dòng `{animation, direction, frame, x, y, rotation, in_front}`. Node `HandItem` đọc bảng này mỗi khung để đặt đúng vị trí cầm công cụ/vũ khí, và `in_front` quyết định vẽ trên hay dưới thân (ví dụ vung rìu về phía lưng thì vẽ dưới).

### 7.4 Trang bị và cách hiển thị

| Ô trang bị | Có sprite? | Chỉ số điển hình | Ghi chú |
| --- | --- | --- | --- |
| Mũ | Có | DEF, chống nóng/lạnh | Mũ rộng vành giảm nóng gay gắt |
| Mặt | Có | May mắn, chống Mù | Kính, khẩu trang |
| Áo | Có | DEF, HP | "Áo Ấm" chống bão tuyết |
| Quần | Có | DEF, Tốc độ |  |
| Giày | Có | Tốc độ, chống trượt băng | Ủng cao su chống bùn |
| Đồ lưng | Có | Sức chứa, mũ rơi lá | Balo mở rộng túi đồ |
| Phụ kiện 1, 2 (nhẫn, vòng cổ) | Không | Chỉ số đặc biệt (xem 8) | Hiện tại trong UI, không hiện trên người |
| Tay chính | Có (HandItem) | Công cụ hoặc vũ khí đang cầm | Lấy từ ô hotbar đang chọn |

- **Thời trang (cosmetic override):** mỗi ô Mũ/Áo/Quần/Giày có thêm ô "Ngoại hình" để hiện đồ khác mà vẫn giữ chỉ số của đồ thật.
- **Bộ trang bị (set):** mặc đủ 3 món cùng bộ nhận thưởng (ví dụ Bộ Thợ Mỏ: +10% tốc độ đào, ánh sáng đầu quanh 5 ô).
- **Màu độ hiếm:** Thường (trắng), Tốt (xanh lá), Hiếm (xanh dương), Sử thi (tím), Huyền thoại (vàng).
- Tùy chọn **"Ẩn mũ"** để nhìn rõ tóc; trang bị vẫn có tác dụng.

### 7.5 Chỉ số, máu và thể lực

| Chỉ số | Giá trị gốc | Tăng theo cấp | Ghi chú |
| --- | --- | --- | --- |
| HP tối đa | 100 | +5 mỗi cấp Cư Dân | Cộng thêm từ trang bị/buff |
| Thể lực tối đa | 200 | +3 mỗi cấp Cư Dân | Ăn món đặc biệt tăng tạm thời |
| Tấn công (ATK) | 5 | +1 mỗi cấp Chiến Đấu | Cộng từ vũ khí |
| Phòng thủ (DEF) | 0 | Từ trang bị | Công thức sát thương ở mục 11 |
| Tốc độ đi / chạy | 64 / 96 px/giây | Từ trang bị, buff | Trên đất bùn/tuyết bị chậm |
| May mắn | 0 | Từ trang bị, buff | 1 điểm = +1% tỉ lệ rơi hiếm, +0,5% chất lượng cao |
| Bán kính hút đồ | 24 px | Từ trang bị | Vật rơi bay về phía nhân vật |
| Tỉ lệ / sát thương chí mạng | 5% / ×1,5 | Từ kỹ năng |  |

**Tiêu hao thể lực:**

| Hành động | Thể lực |
| --- | --- |
| Cuốc, tưới, chặt, đào (công cụ gốc) | 2–3 mỗi lần, nhân hệ số bậc công cụ (Gỗ ×1,0; Đồng ×0,9; Sắt ×0,8; Vàng ×0,7; Tinh Thể ×0,6) và giảm 1% mỗi cấp kỹ năng liên quan |
| Gieo hạt, thu hoạch tay, hái lượm | 0,5 / 0 / 0 |
| Vung vũ khí | 1 |
| Quăng cần câu | 3 |
| Lăn né | 6 |
| Lướt (dash) | 10 |
| Chạy | 0,5 mỗi giây (chỉ khi chạy) |

**Quy tắc thể lực:**

- **Hồi nhẹ:** đứng yên 5 giây thì hồi 2 thể lực mỗi 10 giây.
- **Kiệt sức (thể lực = 0):** tốc độ −40%, **không dùng được công cụ/vũ khí**, vẫn đi và tương tác được. Ăn là hết kiệt sức.
- **Ngủ trước 24:00:** hồi 100% HP và thể lực. **Ngủ 24:00–02:00:** giảm 5% mỗi 10 phút game, thấp nhất 70%.
- **Ngất lúc 02:00:** thức dậy ở nhà (hoặc giường gần nhất) với 50% thể lực, 75% HP, mất 5% Xu (tối đa 500), có thư từ NPC đã đưa về.

**Quy tắc HP:**

- HP về 0: ngất tại chỗ, được đưa về Phòng khám (nếu trong làng) hoặc nhà, mất 10% Xu (tối đa 1.000) và **không mất vật phẩm**. Ở Hầm Đá thì về sảnh hầm.
- Hồi HP tự nhiên: sau 8 giây không bị đánh, +1 HP mỗi 3 giây. Đồ ăn và thuốc hồi nhanh.
- Bất tử 0,6 giây sau mỗi lần trúng đòn (chớp trắng).

**Trạng thái bất lợi:**

| Trạng thái | Hiệu ứng | Thời gian | Cách giải |
| --- | --- | --- | --- |
| Độc | −1 HP mỗi 2 giây | 12 giây | Thuốc giải, ngủ |
| Chậm | Tốc độ −30% | 6 giây | Hết giờ |
| Choáng | Không điều khiển | 1,5 giây | Hết giờ |
| Mù | Tầm nhìn thu hẹp | 8 giây | Rửa mặt ở giếng, thuốc |
| **Quên** | Tên vật phẩm trên hotbar bị che và **xáo vị trí ô** | 20 giây | Thuốc "Tỉnh Táo", hoặc giải 1 câu đố nhanh |
| Lạnh / Nóng | Hồi chậm hơn / tốn thể lực hơn | Theo môi trường | Áo ấm, mũ rộng vành, vào nhà |

**Buff thức ăn:** hầu hết món có thể ăn cho buff 120–300 phút game (20–50 phút thực): +Tốc độ, +May mắn, +Thể lực tối đa tạm, +ATK, chống lạnh/nóng. Chỉ 1 buff thức ăn và 1 buff đồ uống cùng lúc.

### 7.6 Kinh nghiệm và lên cấp

**Hai tầng kinh nghiệm:**

1. **Cấp Cư Dân (1–30):** cấp tổng của người chơi.
2. **5 kỹ năng (cấp 1–10):** Nông nghiệp, Hái lượm, Câu cá, Khai thác, Chiến đấu.
3. Ngoài ra còn **5 mảng Tri thức (cấp 1–10)** ở mục 9.4.

**Công thức:**

- Cấp kỹ năng: tổng XP cần để đạt cấp **L** = `50 × L × (L + 1)` (cấp 1: 100, cấp 5: 1.500, cấp 10: 5.500).
- Cấp Cư Dân: XP cần để lên từ cấp **L** lên **L+1** = `80 + 45L + 5L²` (cấp 1→2: 130; cấp 10→11: 1.030; cấp 29→30: 5.590). Tổng đạt cấp 30 ≈ 64.670 XP.
- Mỗi hành động cho XP kỹ năng; **50% số đó cộng vào XP Cư Dân**. Nhiệm vụ, quái vật, mini-game cộng trực tiếp XP Cư Dân.

**Nguồn XP Cư Dân:**

| Nguồn | XP Cư Dân |
| --- | --- |
| Nhiệm vụ Hàng ngày | 20–40 |
| Nhiệm vụ Riêng lẻ | 50–120 |
| Nhiệm vụ Phụ | 60–150 |
| Nhiệm vụ Cá nhân | 80–200 |
| Nhiệm vụ Sự kiện | 100–300 |
| Nhiệm vụ Ẩn | 150–500 |
| Nhiệm vụ Chính tuyến | 200–600 |
| Nhiệm vụ Đặc biệt | 300–800 |
| Hạ quái | Xem công thức mục 11.4 |
| Phiên học/đố (đạt ≥ 1 sao) | 5–40 theo bậc khó và số sao |
| Khám phá lần đầu (map, vật phẩm, công thức) | 50 / 5 / 10 |

Nhân thưởng theo sao đánh giá: 1 sao ×1,0; 2 sao ×1,25; 3 sao ×1,5.

**Phần thưởng khi lên cấp Cư Dân:**

- Mỗi cấp: +5 HP tối đa, +3 thể lực tối đa, hồi đầy cả hai.
- Cứ 2 cấp: +1 **Điểm Tài Năng** (dùng ở cây tài năng chung: nhặt xa hơn, ngủ hồi nhiều hơn, giảm giá tiệm 2%...).
- Các mốc cấp mở khóa nội dung: cấp 3 Hầm Đá, cấp 5 chuồng bò, cấp 8 Núi Mây, cấp 12 nhà kính, cấp 20 đài thiên văn nâng cao.

**Kỹ năng và nhánh chuyên môn:**

| Kỹ năng | Thưởng mỗi cấp | Cấp 5 (chọn 1) | Cấp 10 (chọn 1) |
| --- | --- | --- | --- |
| Nông nghiệp | +2% cơ hội chất lượng cao | A: Nông phu (+10% giá bán cây trồng) / B: Chăn nuôi gia (+10% giá sản phẩm động vật, hạnh phúc tăng nhanh) | A: Nhà nông học (8% cơ hội thu gấp đôi) / B: Nhà tạo giống (thu thêm hạt giống) |
| Hái lượm | +3% nhặt thêm | A: Thợ rừng (+20% gỗ) / B: Nhà thực vật (thảo dược chất lượng cao) | A: Thợ săn nấm (nấm hiếm) / B: Người tìm kho báu |
| Câu cá | Thanh bắt cá rộng thêm 2 pixel | A: Ngư phủ (+20% giá cá) / B: Thợ đặt bẫy (bẫy cua gấp đôi) | A: Cần thủ huyền thoại (cá hiếm xuất hiện nhiều) / B: Thủy thủ (câu được ở biển sâu) |
| Khai thác | +3% quặng thêm | A: Thợ mỏ (+1 quặng) / B: Nhà địa chất (đá quý gấp đôi) | A: Thợ nung (thỏi nung nhanh gấp đôi) / B: Nhà thám hiểm (xuống tầng nhanh) |
| Chiến đấu | +1 ATK | A: Chiến binh (+10% sát thương) / B: Du hiệp (+15% tốc độ khi chiến đấu, né tốt hơn) | A: Hộ vệ (giảm 10% sát thương nhận) / B: Sát thủ bóng đêm (+25% chí mạng ban đêm) |

### 7.7 Hành động cơ bản và hành động đặc biệt cần mở khóa

**Cơ bản (có từ đầu):**

| Hành động | Phím mặc định | Ghi chú |
| --- | --- | --- |
| Đi | WASD / mũi tên / cần trái | 4 hướng, đi chéo giữ tốc độ chuẩn hóa |
| Chạy | Giữ Shift | Tốn thể lực |
| Tương tác | E | Xem 6.2 |
| Dùng công cụ / vũ khí | J hoặc chuột trái | Theo vật đang cầm |
| Hành động phụ | K hoặc chuột phải | Ví dụ giữ để tưới diện rộng |
| Chọn ô hotbar | 1–0, -, = / cuộn chuột | 12 ô |
| Ăn / dùng | F | Dùng vật phẩm đang cầm |
| Vứt | X | Vứt 1 hoặc cả chồng khi giữ |
| Ngồi | C | Hồi thể lực nhanh hơn 50% khi ngồi ghế |
| Biểu cảm | T | Vòng chọn 6 biểu cảm |
| Túi / Nhật ký / Bản đồ | I / Q / M | Xem 7.8 |

**Đặc biệt (cần mở khóa):**

| Hành động | Mở khóa bằng | Mô tả |
| --- | --- | --- |
| Lăn né (Roll) | Chiến đấu cấp 3 | Lăn 2,5 ô, bất tử 0,3 giây, tốn 6 thể lực |
| Lướt (Dash) | Hoàn thành chương 2 | Lướt 3 ô, phá bụi rậm nhỏ, tốn 10 thể lực |
| Công cụ diện rộng | Công cụ bậc Sắt/Vàng/Tinh Thể | Giữ chuột phải để nạp: 3 ô, 5 ô, 9 ô |
| Thu hoạch quét | Nông nghiệp cấp 5 | Lưỡi hái quét hình quạt 3 ô liền |
| Quăng hoàn hảo | Câu cá cấp 4 | Thả đúng vòng sáng → xa hơn, ít cá nhỏ |
| Đòn xoay | Chiến đấu cấp 6 (kiếm/búa) | Chém vòng 360°, hồi chiêu 4 giây |
| Bơi | Mua Áo Phao (chương 4) | Đi trên nước nông, tốn thể lực mỗi giây |
| Leo vách đá | Khai thác cấp 5 + Móc leo | Leo qua vách thấp ở Núi Mây |
| Thiền | Tri thức Vật cấp 5 | Ngồi hồi 2 lần thể lực, không dùng khi có quái gần |
| Gọi thú cưng tìm đồ | Hoàn thành nhiệm vụ cá nhân với thú cưng | Mỗi ngày 1 lần, tìm vật phẩm gần |

### 7.8 Tiện ích và bố cục giao diện (HUD)

```
┌────────────────────────────────────────────────────────────────┐
│ [Nhiệm vụ đang theo dõi]               ┌───────────────────┐   │
│  • Thu 3 cà rốt (1/3)                  │ 08:40  Thứ Hai    │   │
│  • Gặp cô Lan                          │ Xuân · Ngày 3     │   │
│                                        │ [Nắng] 22°C       │   │
│                                        │ 1.250 Xu          │   │
│                                        └───────────────────┘   │
│                          (khung chơi)                [Minimap] │
│                                                                │
│ HP ████████░░ 80/100                                  Thể lực │
│ [1][2][3][4][5][6][7][8][9][0][-][=]  Hotbar            █ █   │
└────────────────────────────────────────────────────────────────┘
```

| Thành phần | Vị trí | Nội dung và hành vi |
| --- | --- | --- |
| Đồng hồ + lịch + thời tiết | Trên-phải | Giờ (bước 10 phút), thứ, mùa-ngày, icon thời tiết và nhiệt độ, đĩa mặt trời/trăng xoay |
| Xu | Dưới đồng hồ | Số Xu, nhảy số khi nhận/tiêu |
| Thanh HP | Dưới-trái | Thanh ngang, đổi màu đỏ khi < 30%, nhấp nháy khi < 15% |
| Thanh thể lực | Dưới-phải | Thanh dọc, tô vàng khi buff, đỏ khi < 15% |
| Hotbar | Dưới-giữa | 12 ô; ô đang chọn có viền sáng; số lượng ở góc; icon chất lượng ở góc trái dưới |
| Theo dõi nhiệm vụ | Trên-trái | Tối đa 3 nhiệm vụ ghim, thu gọn được |
| Minimap | Góc phải giữa (tùy chọn bật) | Chấm nhân vật, NPC, cổng map |
| Biểu tượng trạng thái | Cạnh thanh HP | Độc, Chậm, Quên, buff thức ăn kèm đếm ngược |
| Thông báo nhặt đồ | Dưới-trái, trên hotbar | Icon + tên + số lượng, tự mất sau 3 giây |
| Banner lên cấp / nhiệm vụ | Giữa-trên | Trượt vào 0,5 giây, giữ 2 giây |
| Gợi ý tương tác | Phía trên vật thể | Icon phím + 1 dòng |

HUD **tự mờ 50%** sau 6 giây không có thay đổi, trở lại đầy đủ khi có sự kiện. Có chế độ ẩn HUD để chụp ảnh.

**Menu chính (phím Tab hoặc I) gồm 10 thẻ:**

| Thẻ | Nội dung |
| --- | --- |
| Túi đồ | 36 ô (3 hàng × 12), thùng rác, tách chồng (giữ Shift), sắp xếp tự động |
| Trang bị | Búp bê nhân vật và các ô trang bị, xem trước thời trang |
| Kỹ năng & Tri thức | 5 kỹ năng, 5 mảng tri thức, nhánh chuyên môn, cây tài năng |
| Nhiệm vụ | Tab theo loại (mục 9), lọc, ghim theo dõi |
| Bách khoa | Cá, thú, quái, cây, khoáng sản đã khám phá |
| Bản đồ | Bản đồ làng và map hiện tại, điểm NPC theo giờ |
| Quan hệ | Danh sách NPC, tim hữu nghị, sở thích, ngày sinh nhật |
| Chế tạo | Công thức đã học, lọc theo trạm |
| Cài đặt | Âm thanh, phím, ngôn ngữ, trợ năng |
| Thoát | Lưu và thoát, về menu chính |

Trợ năng: cỡ chữ 3 mức, chế độ mù màu (đổi bảng màu độ hiếm), giảm rung màn hình, đổi phím, bật phụ đề âm thanh.

---

## 8. Vật phẩm

### 8.1 Cấu trúc dữ liệu `ItemData`

| Trường | Ý nghĩa |
| --- | --- |
| `id` | Định danh duy nhất, ví dụ `crop_tomato` |
| `name_key`, `description_key` | Khóa i18n |
| `category` | Công cụ / Vũ khí / Trang phục / Hạt giống / Nông sản / Hái lượm / Cá / Sản phẩm động vật / Khoáng sản / Nguyên liệu / Món ăn / Đồ đặt / Sách học / Vật phẩm nhiệm vụ / Trang trí |
| `rarity` | Thường, Tốt, Hiếm, Sử thi, Huyền thoại |
| `stack_size` | 999 cho nguyên liệu, 99 nông sản, 1 cho trang bị |
| `sell_price`, `buy_price` | Giá bán, giá mua (Xu) |
| `icon`, `world_sprite`, `held_animation` | Icon 16×16, sprite khi rơi trên đất, kiểu cầm/dùng |
| `equip_slot`, `stat_modifiers` | Ô trang bị và chỉ số cộng |
| `use_effect` | Hồi HP/thể lực, buff, mở công thức, đặt vật thể |
| `tags` | `edible`, `seed`, `ore`, `gift_loved_by:[npc_id]`, `season:[spring]`... |
| `quality_enabled` | Có hỗ trợ chất lượng sao không |

**Chất lượng:** Thường ×1,0 · Bạc ×1,25 · Vàng ×1,5 · Tinh Thể ×2,0 (giá bán). Xác suất theo kỹ năng, phân bón, May mắn và hạnh phúc động vật.

**Giá bán thực tế** = giá gốc × hệ số chất lượng × (1 + hiệu ứng nhánh chuyên môn) × (1 + 0,01 × cấp Tri thức Số, tối đa +10%).

### 8.2 Cách hiển thị vật phẩm

| Nơi hiển thị | Quy cách |
| --- | --- |
| Ô túi/hotbar | Icon 16×16 trên nền ô 20×20, viền màu theo độ hiếm, số lượng góc phải-dưới (font 5×7), ngôi sao chất lượng góc trái-dưới |
| Trên đất (vật rơi) | Sprite 16×16, bóng nhỏ, nhấp nhô ±2 px chu kỳ 1,2 giây, lóe sáng nếu hiếm; tồn tại đến hết ngày |
| Trên người | Tool/vũ khí ở `HandItem`; đồ nặng bưng trước ngực (`carry_walk`); vũ khí cất đeo lưng khi không dùng |
| Tooltip | Tên (màu độ hiếm), loại, mô tả, chỉ số, giá bán, nguồn ("Thu từ: cà chua"), cảnh báo "Chưa học công thức" |
| Bách khoa | Ảnh lớn hơn, nơi tìm thấy, mùa, giờ, thời tiết xuất hiện |

### 8.3 Nhân vật tương tác với vật phẩm

| Hành động | Điều khiển | Điều kiện | Kết quả |
| --- | --- | --- | --- |
| Nhặt | Tự động hút trong bán kính | Túi còn chỗ | Vào túi, hiện toast; túi đầy: vật dội lại và nhắc "Túi đầy" |
| Dùng / ăn | F | Vật ăn/uống/thuốc | Hiệu ứng ngay, 1 vật bị trừ |
| Vứt | X | Vật không phải nhiệm vụ | Rơi dưới chân, có thể nhặt lại sau 1 giây |
| Tách/gộp chồng | Giữ Shift + kéo | Cùng loại | Tách một nửa, gộp tự động |
| Cất vào rương | Mở rương + kéo | Rương còn chỗ | Hai UI kho đồ song song |
| Tặng NPC | Cầm vật + E vào NPC | 1 quà/ngày/NPC | Tăng tim hữu nghị theo sở thích (yêu +80, thích +45, bình thường +20, ghét −40) |
| Bán | Mở Shop | Quầy hàng mở | Nhận Xu theo giá bán thực tế |
| Đặt | Chuột trái ở chế độ đặt | Vật là đồ đặt, ô hợp lệ | Hiện bóng xanh/đỏ để biết hợp lệ |
| Trang bị | Kéo vào ô trang bị / chuột phải | Đúng ô, đủ cấp | Đổi lớp sprite trên người |
| Chế tạo | Mở bàn chế tạo | Có công thức và nguyên liệu | Nhận vật mới theo thời gian trạm |
| Đọc sách | F với "Sách học" | Chưa đọc | Mở phiên học, thưởng XP tri thức, đánh dấu đã đọc |

### 8.4 Hành động của nhân vật đi cùng vật phẩm

| Nhóm vật phẩm | Hoạt ảnh | Điểm neo / hiệu ứng | Âm thanh | Thể lực |
| --- | --- | --- | --- | --- |
| Cuốc | `tool_swing` | Quét xuống ô phía trước, đất lật tung | Tiếng thịch đất | 2 |
| Bình tưới | `water` | Nước bắn ra ô trước, nước giảm trong bình | Róc rách | 2 |
| Rìu | `tool_swing` | Mảnh gỗ bay, cây rung | Cộp | 3 |
| Cuốc chim | `tool_swing` | Tia lửa, mảnh đá vụn | Keng | 3 |
| Lưỡi hái | `tool_swing` | Cỏ cắt bay, quét hình quạt | Xoẹt | 1 |
| Cần câu | `fish_*` | Dây câu vẽ đường cong, phao nhấp nhô | Vút, tõm | 3 |
| Vũ khí | `attack_*` | Hitbox hình cung/đường thẳng/tròn theo loại | Vút, va chạm | 1 |
| Hạt giống | `tool_swing` nhẹ (rải) | Hạt bay xuống ô | Sột soạt | 0,5 |
| Món ăn / thuốc | `eat` | Hiện icon trên đầu, hiệu ứng buff | Nhai/uống | 0 |
| Sách | `read` | Sách mở ở tay, mở màn học | Lật trang | 0 |
| Đèn lồng | Cầm ở tay trái | Ánh sáng bán kính 6 ô | Không | 0 |
| Vật nặng | `carry_walk` | Bưng trước ngực, tốc độ −25% | Hừ | 0 |

### 8.5 Công cụ và vũ khí theo bậc

**Công cụ** (5 bậc, nâng cấp ở Lò rèn bằng thỏi kim loại + Xu, mất 2 ngày game):

| Bậc | Nguyên liệu nâng | Giá Xu | Hệ số sát thương lên cây/đá | Diện rộng |
| --- | --- | --- | --- | --- |
| Gỗ (khởi đầu) | — | — | ×1,0 | 1 ô |
| Đồng | 5 thỏi đồng | 2.000 | ×1,5 | 1 ô (nạp 3 ô) |
| Sắt | 5 thỏi sắt | 5.000 | ×2,0 | 3 ô |
| Vàng | 5 thỏi vàng | 10.000 | ×3,0 | 5 ô |
| Tinh Thể | 5 thỏi tinh thể | 25.000 | ×4,0 | 9 ô |

**Vũ khí (3 loại × 5 bậc):**

| Loại | Hitbox | Tốc độ | Điểm mạnh | ATK bậc 1 → 5 |
| --- | --- | --- | --- | --- |
| Kiếm | Hình cung 90°, tầm 1 ô | Nhanh (0,35 giây) | Cân bằng, đánh nhiều lần | 8 → 28 |
| Giáo | Đường thẳng 2 ô | Vừa (0,5 giây) | Đánh xa, an toàn | 10 → 32 |
| Búa | Vòng tròn 1,5 ô | Chậm (0,8 giây) | Choáng 1 giây, phá đá | 14 → 40 |

### 8.6 Nhóm vật phẩm mẫu (để dựng dữ liệu ban đầu)

| Nhóm | Ví dụ | Ghi chú |
| --- | --- | --- |
| Hạt giống | Giống cải xanh, cà rốt, khoai tây, dâu tây... | Bán ở tiệm tạp hóa, theo mùa |
| Nông sản | Cải xanh, cà rốt, cà chua, bắp, bí ngô, nho | Có chất lượng sao |
| Hái lượm | Dâu rừng, nấm, thảo dược, hạt dẻ, hoa dại | Mọc theo mùa/giờ/thời tiết |
| Khoáng sản | Đồng, sắt, vàng, tinh thể, than, đá quý | Rơi từ đá và quái hầm |
| Cá | Cá chép, cá rô, cá trê, cá chình, cá cầu vồng... | Xem mục 13.3 |
| Sản phẩm động vật | Trứng, sữa, len, mật, lông vũ, nấm cục | Xem mục 10 |
| Nguyên liệu | Gỗ, đá, cỏ khô, sợi, thỏi kim loại, bụi sao |  |
| Món ăn | Cháo gà, bánh bí ngô, canh nấm, nước chanh đá | Học công thức từ NPC/tri thức |
| Trang phục | Mũ rơm, áo len, ủng cao su, áo choàng sao | Mua, thưởng nhiệm vụ, rơi từ quái |
| Sách học | Sách Số học 1, Từ vựng 100 từ, Nhập môn thiên văn | Mở bài học và công thức |
| Vật phẩm nhiệm vụ | Chìa Mực, Mảnh Sao, thư giới thiệu | Không bán, không vứt |

---

## 9. Cốt truyện, nhiệm vụ và hệ thống học tập

### 9.1 Bối cảnh và cốt truyện

Làng Sao Mai nằm giữa năm ngọn đồi. Hàng trăm năm trước, dân làng dựng **Ngôi Sao Tri Thức** trên đài thiên văn, một trụ đá phát sáng giúp cả làng "nhớ": biết chữ, biết tính, biết nghề. Rồi Ngôi Sao vỡ thành 5 **Mảnh Sao** và **Màn Sương Quên** phủ xuống. Dân làng dần quên: trường vắng học trò, sách mờ chữ, mỏ đá lạc lối. Từ nỗi quên đó sinh ra **Quái Quên** (slime mực, dơi giấy, ma sương...).

Người chơi nhận một lá thư từ người họ hàng xa để lại **Nông Trại Mầm Xanh** và một cuốn **Sổ Tay Tri Thức** còn trống. Sổ Tay tự điền dần khi người chơi học và khám phá (chính là các menu Kỹ năng, Bách khoa). Mỗi Mảnh Sao gắn với một mảng tri thức, và được canh giữ bởi một "Bóng Quên" chỉ bị đánh bại bằng **kết hợp chiến đấu và giải đố**.

**Kết thúc:** vào lễ hội **Đêm Sao Rơi** (Đông, ngày 7), người chơi lắp 5 mảnh vào trụ và đối mặt **Kẻ Xóa Chữ**, thực thể sinh ra từ Sương Quên. Đây không phải trận giết chóc: người chơi "nhắc nhớ" bằng các câu đố trong lúc né đòn. Có 3 hậu kết tùy việc đã phát triển Trường, Thư viện hay Nông Trại nhiều nhất.

**Dàn NPC chính:**

| NPC | Vai trò | Nơi ở / làm | Giao loại nhiệm vụ | Sở thích điển hình |
| --- | --- | --- | --- | --- |
| Cô Lan | Giáo viên | Trường Ánh Dương | Chính (Số), Hàng ngày, Cá nhân | Hoa cúc, sách thiếu nhi |
| Bà Tư | Thủ thư | Thư viện cổ | Chính (Chữ), Phụ, Ẩn | Trà, sách cổ |
| Chú Ba | Thợ rèn | Lò rèn | Phụ, Đặc biệt | Khoáng sản, bia |
| Dì Năm | Chủ tiệm tạp hóa | Phố Chợ | Hàng ngày, Riêng lẻ | Bánh ngọt, vải |
| Bác sĩ Minh | Y sĩ | Phòng khám | Phụ, Cá nhân | Thảo dược, nấm |
| Ông Sáu | Ngư dân | Bãi biển / Hồ | Phụ, Sự kiện | Cá, thuốc lá hái |
| Cô Mai | Chủ trại chăn nuôi | Đồng Cỏ | Chính (hướng dẫn), Phụ | Trứng, sữa |
| Lão Quang | Thiên văn gia | Đài thiên văn | Chính (Vật, Ký, kết), Ẩn | Bụi sao, trà đêm |
| Bé Na | Học sinh | Trường / Quảng trường | Hàng ngày, Cá nhân | Kẹo, hoa dại |
| Anh Khoa | Thợ mỏ | Hầm Đá | Chính (Vật), Đặc biệt | Đá quý, đồ nướng |
| Chị Vy | Đầu bếp | Quán Hương Lúa | Hàng ngày, Sự kiện | Nông sản tươi, gia vị |
| Thuyền trưởng Marco | Thủy thủ ngoại quốc | Bến cảng | Chính (Ngữ), Cá nhân | Cá, sách địa lý |

### 9.2 Các chương chính tuyến

Chương mở khi **chương trước đã xong VÀ ngày hiện tại ≥ ngày mở tối thiểu**. Chương không hết hạn; nếu chưa xong trong năm, câu chuyện tiếp tục sang năm sau (các mùa lặp lại).

| Chương | Thời gian mở tối thiểu | Mục tiêu | Mở khóa | Đỉnh điểm |
| --- | --- | --- | --- | --- |
| Mở đầu: Lá Thư | Xuân ngày 1 | Đến nông trại, dọn đất, trồng hạt đầu, gặp Dì Năm, ngủ đêm đầu | Hướng dẫn cơ bản | Nhận Sổ Tay |
| 1. Hạt Giống Đầu Tiên | Xuân 2 | Làm quen toàn bộ NPC, trồng và thu hoạch lần đầu, cô Lan mời vào lớp | Rừng Thì Thầm, sảnh Hầm Đá, nhiệm vụ Hàng ngày | Gặp Lão Quang, biết về Ngôi Sao vỡ |
| 2. Ngôi Trường Im Lặng | Xuân 4 | Sương Quên phủ trường, giải đố Toán để cứu lớp học | Lướt (dash), lớp học đầy đủ | **Mảnh Số** — vượt "Bóng Số Không" trong hầm trường |
| 3. Thư Viện Bị Khóa | Hạ 1 | Tìm Chìa Mực, mở hầm sách, phục hồi sách bị xóa chữ | Hầm sách, công thức nâng cao | **Mảnh Chữ** — vượt "Gã Gạch Xóa" |
| 4. Tiếng Sóng Ngoại Ngữ | Hạ 5 | Sửa cầu, ra biển, giao tiếp với Marco bằng tiếng Anh | Bãi Biển, Áo Phao, nhà kính | **Mảnh Ngữ** — vượt "Thủy Thủ Câm"; Hội Biển Đêm |
| 5. Mỏ Đá Thì Thầm | Thu 1 | Xuống Hầm Đá, giải đố cơ khí và khoa học | Tầng 20–40, Núi Mây | **Mảnh Vật** — vượt "Golem Công Thức" |
| 6. Núi Mây và Ký Ức | Thu 5 | Leo núi, theo dấu di tích, ghép lịch sử ngôi làng | Đài thiên văn nâng cao | **Mảnh Ký** — vượt "Hồn Ký Ức"; Hội Gặt |
| 7. Đêm Sao Rơi | Đông 1 | Lắp 5 mảnh, chuẩn bị lễ hội, đối mặt Kẻ Xóa Chữ | Hậu kết, chế độ chơi tự do mùa 2 | **Kẻ Xóa Chữ** (Đông 7, 20:00) |

Giữa các chương luôn có **thời gian đệm** (vài ngày) để người chơi làm nhiệm vụ phụ, nuôi thú, khai thác; không gò ép tiến độ.

### 9.3 Cơ chế nhiệm vụ

**Dữ liệu `QuestData`:**

| Trường | Ý nghĩa |
| --- | --- |
| `id`, `title_key`, `description_key` | Định danh và nội dung |
| `quest_type` | Một trong 8 loại ở 9.5 |
| `giver_id`, `turn_in_id` | NPC giao / nhận (có thể khác nhau, hoặc rỗng = tự hoàn thành) |
| `prerequisites[]` | Cấp Cư Dân, chương, nhiệm vụ trước, mùa, ngày, thời tiết, hữu nghị, vật phẩm |
| `objectives[]` | Danh sách mục tiêu (xem dưới) |
| `time_limit` | Hạn theo phút game hoặc ngày (tùy chọn) |
| `rating_rules` | Điều kiện được 2 và 3 sao |
| `rewards` | Xu, XP, vật phẩm, tim hữu nghị, mở khóa |
| `repeatable`, `cooldown_days` | Có làm lại được không |

**Loại mục tiêu (`objective.type`):** `collect` (có vật phẩm), `deliver` (giao vật cho NPC), `kill` (hạ quái), `reach` (đến vị trí), `talk` (nói chuyện), `craft`, `plant`, `harvest`, `fish`, `feed_animal`, `solve_puzzle` (đạt ≥ số sao), `survive` (trụ qua giờ), `explore`, `use_item_on`. Mục tiêu chạy **tuần tự** hoặc **song song**, có thể đánh dấu **tùy chọn** (để lấy sao).

**Trạng thái:** `Locked` → `Available` → `Active` → `Ready` (đủ mục tiêu, chờ nộp) → `Completed` → `Claimed`; nhánh phụ: `Failed`, `Expired`.

**Giao nhiệm vụ:**

| Kênh | Dấu hiệu | Dùng cho |
| --- | --- | --- |
| NPC | Dấu `!` trên đầu: **vàng** Chính, **xanh dương** Phụ, **xanh lá** Hàng ngày, **hồng** Cá nhân, **tím** Đặc biệt, **cam** Sự kiện | Hầu hết loại |
| Bảng nhiệm vụ Quảng Trường | Giấy ghim, 3 nhiệm vụ Hàng ngày mới lúc 06:00 | Hàng ngày, Riêng lẻ |
| Hòm thư | Thư mới sáng sớm | Cá nhân, Sự kiện |
| Vùng kích hoạt (trigger) | Không dấu | Nhiệm vụ Ẩn |
| Vật phẩm | Đọc sách/nhật ký nhặt được | Phụ, Ẩn |

**Hoàn thành:**

1. Hệ thống nghe `EventBus` và cập nhật tiến độ mục tiêu (toast "Cà rốt 2/3").
2. Khi mọi mục tiêu bắt buộc xong: `Ready`, dấu `?` hiện trên NPC nhận. Nhiệm vụ không có NPC nhận sẽ tự hoàn thành.
3. Nộp: hội thoại ngắn, tính sao, phát thưởng, banner hiện lên.

**Đánh giá sao:**

| Sao | Điều kiện chung |
| --- | --- |
| 1 sao | Hoàn thành mục tiêu bắt buộc |
| 2 sao | Thêm 1 điều kiện phụ: đúng hạn sớm, độ chính xác ≥ 80%, không bị thương, hoặc nộp kèm vật chất lượng ≥ Bạc |
| 3 sao | Thêm điều kiện ẩn/khó: không sai câu nào, hạ gọn không dùng thuốc, chất lượng Vàng... |

**Phần thưởng gốc (nhân ×1,0 / ×1,25 / ×1,5 theo sao):**

| Loại | Xu | Phần thưởng khác |
| --- | --- | --- |
| Hàng ngày | 80–200 | Nguyên liệu, +10 hữu nghị |
| Riêng lẻ | 150–400 | Đồ đặt nhỏ |
| Phụ | 300–800 | Công thức, trang phục |
| Cá nhân | 200–500 | +100 hữu nghị, sự kiện tim |
| Sự kiện | 400–1.000 | Vật phẩm lễ hội độc quyền |
| Ẩn | 500–1.500 | Vật hiếm, bí mật |
| Chính tuyến | 800–3.000 | Mảnh Sao, mở khóa lớn |
| Đặc biệt | 1.500–5.000 | Trang bị Sử thi, nhánh tài năng |

Nhiệm vụ lớn cho **chọn 1 trong N** phần thưởng. XP Cư Dân theo bảng ở 7.6.

**Thất bại và hết hạn:** không phạt nặng. Hết hạn chỉ mất phần thưởng; nhiệm vụ Phụ/Cá nhân có thể được NPC giao lại sau `cooldown_days`. Nhiệm vụ Chính tuyến không hết hạn.

### 9.4 Hệ thống Tri thức và học tập

**Năm mảng tri thức** (cấp 1–10, dùng cùng công thức XP của kỹ năng: tổng XP cần = `50 × L × (L + 1)`):

| Mảng | Môn | Mini-game / dạng đố | Nơi học | Thưởng mỗi cấp |
| --- | --- | --- | --- | --- |
| **Số** | Toán | Tính nhẩm nhanh (tiệm tạp hóa), dãy số quy luật, đo diện tích luống (lưới), cân thăng bằng | Trường, tiệm tạp hóa, bàn học | +1% giá bán (tối đa +10%), giảm giá khi mua 1% (tối đa 10%) |
| **Chữ** | Ngữ văn | Điền từ vào ca dao/tục ngữ, ghép câu, sắp xếp đoạn, đoán chữ (kiểu Wordle), chính tả | Thư viện, bàn học | +2% hiệu quả quà tặng, mở lời thoại đặc biệt, +1% XP mọi nguồn |
| **Ngữ** | Tiếng Anh | Nối từ với hình, điền câu, hội thoại chọn câu đáp (với Marco) | Bến cảng, lớp học, sách ngoại ngữ | Mở sạp thương lái nước ngoài, giá bán đồ hiếm +2%, nhận thư/nhiệm vụ tiếng Anh |
| **Vật** | Khoa học tự nhiên | Pha trộn chất, nối mạch điện, chuỗi thức ăn, vòng đời cây, dự báo thời tiết | Phòng thí nghiệm, phòng khám, Hầm Đá | Cây lớn nhanh hơn 1% (tối đa 10%), mở công thức thuốc và máy móc, tăng hiệu quả buff thức ăn |
| **Ký** | Lịch sử – Địa lý | Sắp xếp mốc thời gian, nối địa danh với bản đồ, đố di tích | Thư viện, Núi Mây, đài thiên văn | +1 May mắn mỗi 2 cấp, mở chi tiết bản đồ và đường tắt |

**Cấu trúc một phiên học:**

- 5 câu hỏi, có thể xen kẽ nhiều dạng. Thời gian game **tạm dừng** trong phiên.
- Sao: ≥ 60% đúng = 1 sao; ≥ 80% = 2 sao; 100% hoặc (bậc 4–5 sai tối đa 1 câu) = 3 sao.
- Thưởng theo sao: XP tri thức, XP Cư Dân, và vật phẩm nhỏ ở lần đầu mỗi ngày.
- Sai: hiện **giải thích**, không phạt. Sai 3 câu liên tiếp được mời "Học lại bài này" (xem giải thích trước khi thử lại).

**Độ khó thích ứng (5 bậc):** tăng 1 bậc sau 2 phiên liên tiếp ≥ 80%; giảm 1 bậc sau 2 phiên liên tiếp < 40%. Người chơi có thể ghim bậc thủ công ở Cài đặt (cho phụ huynh/giáo viên).

**Ngân hàng câu hỏi (`data/questions/*.json`):**

```json
{
  "id": "math_0012",
  "subject": "math",
  "type": "numeric_input",
  "difficulty": 2,
  "tags": ["phep_nhan", "cua_hang"],
  "prompt_key": "Q_MATH_0012_PROMPT",
  "answer": 36,
  "hint_key": "Q_MATH_0012_HINT",
  "explanation_key": "Q_MATH_0012_EXPLAIN"
}
```

Các `type` hỗ trợ: `multiple_choice`, `fill_blank`, `ordering`, `matching`, `numeric_input`, `drag_to_sort`, `grid_puzzle`. Ngân hàng nạp lúc khởi động; thêm câu hỏi chỉ cần thêm dòng JSON.

**Ôn tập ngắt quãng đơn giản (Leitner 3 hộp):** câu trả lời đúng 3 lần liên tiếp chuyển sang hộp "đã thuộc" (gặp lại ít); câu sai quay về hộp 1 (gặp lại nhiều).

**Câu đố trong thế giới (không phải mini-game bảng):** cửa khóa dãy số, bảng chữ trên tường cần điền, cân thăng bằng cho cửa đá, mê cung la bàn (Địa lý) ở Núi Mây, bảng tuần hoàn rút gọn ở phòng thí nghiệm.

**Không chặn cứng cốt truyện:** nếu thất bại 3 lần ở một câu đố Chính tuyến, Lão Quang xuất hiện "giúp một tay" và cho qua với 1 sao. Từ màn hình Tiêu đề có **Phòng học** (chế độ ôn luyện tự do, không cần chơi game).

### 9.5 Định nghĩa tám loại nhiệm vụ

| Loại | Định nghĩa | Ai giao / kích hoạt | Hạn | Cách theo dõi | XP Cư Dân | Dấu hiệu |
| --- | --- | --- | --- | --- | --- | --- |
| **Chính tuyến** | Mạch truyện chính (mục 9.2), mỗi chương gồm 4–8 nhiệm vụ nối tiếp | NPC chính, trigger theo chương | Không hết hạn | Ghim tự động, nền vàng | 200–600 | `!` vàng |
| **Phụ** | Câu chuyện nhỏ về NPC hoặc địa phương, tự chọn | NPC, thư, vật phẩm | Có thể có hạn dài (7 ngày) | Thẻ "Phụ" | 60–150 | `!` xanh dương |
| **Hàng ngày** | Công việc lặp lại, tạo mới 06:00 mỗi ngày, tối đa 3 cái | Bảng Quảng Trường, Dì Năm, Chị Vy | Hết ngày | Thẻ "Hôm nay" | 20–40 | `!` xanh lá |
| **Riêng lẻ** | Việc làm một lần, ngắn, không thuộc chuỗi (ví dụ "đưa hộp này cho ông Sáu") | Bảng, NPC bất kỳ | Thường 1–3 ngày | Thẻ "Việc lặt vặt" | 50–120 | Giấy ghim |
| **Cá nhân** | Dành cho từng NPC, mở theo mức hữu nghị (2, 4, 6, 8, 10 tim), gắn sự kiện tim | NPC đó | Không | Thẻ "Tâm tình" | 80–200 | `!` hồng |
| **Đặc biệt** | Thử thách lớn, mở theo cấp hoặc thành tựu (thợ mỏ, thợ săn, đầu bếp) | NPC chuyên môn | Không | Thẻ "Thử thách" | 300–800 | `!` tím |
| **Sự kiện** | Chỉ trong lễ hội/sự kiện mùa | NPC lễ hội | Hết lễ hội | Thẻ "Lễ hội" | 100–300 | `!` cam |
| **Ẩn** | Không hiện trong nhật ký đến khi kích hoạt bằng khám phá/điều kiện lạ | Trigger, vật phẩm, điều kiện thời tiết/giờ | Tùy | Hiện thẻ khi kích hoạt | 150–500 | Không có |

**Ví dụ nhiệm vụ ẩn:** *Đêm có mưa sao băng*: nhặt 3 Bụi Sao trước 02:00 và đặt lên Bàn Tinh Tú. *Cuốn nhật ký ướt*: khi trời mưa, ghé ghế đá Vườn Thư Viện lúc 16:00 để thấy một trang giấy lộ chữ.

### 9.6 Khi nào nhiệm vụ được cấp

| Giai đoạn | Loại nhiệm vụ mở thêm |
| --- | --- |
| Ngày 1 (Mở đầu) | Chính (Mở đầu), 1–2 Riêng lẻ hướng dẫn |
| Sau Chương 1 | Hàng ngày (bảng Quảng Trường), Phụ đầu tiên (Dì Năm, Cô Mai), Cá nhân (mốc 2 tim) |
| Cấp Cư Dân 5 | Đặc biệt đầu tiên (Thử thách Thợ Mỏ, Thử thách Đầu Bếp) |
| Sau Chương 2 | Sự kiện (lễ hội), Ẩn đầu tiên, Phụ liên quan trường học |
| Sau Chương 3 | Phụ thư viện, Ẩn trong hầm sách, Đặc biệt học giả |
| Sau Chương 4 | Phụ biển/cảng, nhiệm vụ buôn bán quốc tế, Đặc biệt ngư phủ |
| Cấp Cư Dân 12+ | Nhiệm vụ Cá nhân mốc 6–10 tim, Ẩn mức hiếm |
| Sau Chương 7 | Nhiệm vụ "Sau Kết thúc" (xây dựng làng, mở rộng), mùa 2 lặp lại có biến thể |

### 9.7 NPC, hữu nghị và lịch sinh hoạt

- **Hữu nghị 0–10 tim**, mỗi tim = 100 điểm. Nguồn điểm: nói chuyện (+20/ngày), quà (xem 8.3), nhiệm vụ Cá nhân, tham dự lễ hội cùng NPC. Mỗi 2 tim mở một **sự kiện tim** (đoạn cutscene ngắn) và nhiệm vụ Cá nhân.
- **Lịch sinh hoạt** lưu JSON trong `data/schedules/`, theo loại ngày: `weekday`, `weekend`, `rain`, `festival`, `special`. Mỗi dòng `{start_minute, map_id, position_marker, activity}`; NPC đi theo đường điều hướng (`NavigationAgent2D`) giữa các điểm.
- **Mưa/bão:** NPC chuyển lịch `rain` (ở trong nhà, tiệm đông hơn). **Sương Quên:** một vài NPC biến mất khỏi lịch vì "quên đường", đó là một vụ hấp dẫn cho nhiệm vụ Ẩn.
- Hội thoại viết bằng Dialogue Manager, có nhánh theo hữu nghị, theo mùa, theo thời tiết, theo nhiệm vụ đang làm.

### 9.8 Lễ hội và sự kiện mùa

| Lễ hội | Thời điểm | Nội dung | Nhiệm vụ Sự kiện |
| --- | --- | --- | --- |
| Hội Hoa Xuân | Xuân ngày 7 | Triển lãm hoa, cuộc thi cắm hoa (Chữ + Số) | Thu thập 5 loại hoa, trang trí gian hàng |
| Hội Biển Đêm | Hạ ngày 7 | Thả đèn nước, thi câu cá ban đêm, đom đóm | Giải đố tiếng Anh với khách nước ngoài |
| Hội Gặt | Thu ngày 7 | Thi nông sản, nấu ăn, trò kéo co | Nộp nông sản chất lượng cao, thi hát ca dao |
| Đêm Sao Rơi | Đông ngày 7 | Lễ chính của cốt truyện, mưa sao băng đặc biệt | Kết thúc chương 7; năm sau trở thành lễ hội vui |

Mọi lễ hội: thời tiết luôn Nắng (hoặc quang đãng ban đêm), cửa hàng thường đóng, bản đồ Quảng Trường chuyển sang `event_overlay`, thời gian lễ hội 10:00–23:00.

---

## 10. Động vật

### 10.1 Phân loại

- **Vật nuôi (livestock):** gà, vịt, bò, dê, cừu, heo, ong, ngựa. Người chơi mua, nuôi, thu sản phẩm. **Không có mổ thịt**; muốn bớt vật nuôi thì "nhượng lại" cho cô Mai với 50% giá mua.
- **Thú cưng:** mèo/chó (miễn phí, chọn ở đầu game), có nhiệm vụ cá nhân riêng.
- **Động vật hoang:** sống trong map, tương tác để khám phá Bách khoa, một số cho vật phẩm (10.5).

### 10.2 Bảng vật nuôi: giá, sản phẩm, kinh nghiệm

| Vật nuôi | Công trình cần | Giá mua (Xu) | Trưởng thành | Thức ăn / ngày | Sản phẩm (chu kỳ) | Giá bán sản phẩm | XP Nông nghiệp mỗi lần thu |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Gà | Chuồng gà | 400 | 3 ngày | 1 cỏ khô | Trứng (mỗi ngày); Lông vũ (5%/ngày) | 50; 90 | 6 |
| Vịt | Chuồng gà cấp 2 + ao | 650 | 4 ngày | 1 cỏ khô + nước | Trứng vịt (mỗi 2 ngày); Lông vũ vịt (10%) | 110; 100 | 9 |
| Bò sữa | Chuồng bò | 1.500 | 5 ngày | 2 cỏ khô | Sữa bò (mỗi ngày) | 125 | 12 |
| Dê | Chuồng bò cấp 2 | 2.000 | 5 ngày | 2 cỏ khô | Sữa dê (mỗi 2 ngày) | 220 | 16 |
| Cừu | Chuồng bò cấp 2 | 2.500 | 6 ngày | 2 cỏ khô | Len (mỗi 3 ngày, cần Kéo cắt) | 340 | 20 |
| Heo | Chuồng bò cấp 3 | 5.000 | 7 ngày | 3 cỏ khô | Nấm cục (heo tự tìm ngoài trời, không mưa/Đông) | 625 | 30 |
| Ong | Tổ ong (đặt trên đất) | 1.000 | Ngay | Hoa trong 5 ô | Mật ong (mỗi 4 ngày) | 180 (hương vị theo hoa) | 10 |
| Ngựa | Chuồng ngựa | 8.000 | 8 ngày | 3 cỏ khô | Không có; cưỡi (tốc độ +40%, không dùng được công cụ) | — | — |
| Mèo / Chó | Bát ăn | 0 | — | 1 thức ăn thú cưng | Mang vật nhỏ về nhà (1 lần/ngày sau nhiệm vụ cá nhân) | — | — |

**Sản phẩm chế biến (trạm trên nông trại):** Máy mayonnaise (trứng → mayonnaise), Máy phô mai (sữa → phô mai), Máy dệt (len → vải), Thùng ủ mật (mật → rượu mật ong).

### 10.3 Cơ chế sinh tồn của vật nuôi

Mỗi con có các chỉ số sau (lưu trong `AnimalState`):

| Chỉ số | Thang | Thay đổi theo thời gian | Hậu quả khi thấp |
| --- | --- | --- | --- |
| Đói | 0–100 | −4 mỗi giờ game | < 30: sản lượng giảm 50%; 0 qua 1 ngày: Ốm |
| Khát | 0–100 | −5 mỗi giờ game (vịt −8) | Như Đói |
| Hạnh phúc | 0–1.000 | +10/ngày vuốt ve; +20 khi ra bãi cỏ; +20 khi ăn cám cao cấp; −50 khi bị đói; −100 khi ở ngoài trời cả đêm; −150 khi quái tấn công | Ảnh hưởng chất lượng và sản lượng |
| Sức khỏe | 0–100 | −10 mỗi ngày Ốm; Ốm do đói, khát, lạnh Đông không có lò sưởi, mưa bão ngoài trời | Ốm: ngừng sản xuất, cần thuốc thú y |
| Nhiệt (chuồng) | Ấm / Lạnh | Mùa Đông cần lò sưởi chuồng | Lạnh: Sức khỏe giảm, Hạnh phúc giảm |

**Quy trình mỗi ngày (06:00):** hệ thống tính từng con: đủ ăn uống? → có Ốm? → sinh sản phẩm theo chu kỳ → quyết định chất lượng sản phẩm.

| Hạnh phúc | Chất lượng sản phẩm (xác suất) |
| --- | --- |
| < 300 | 100% Thường |
| 300–599 | 85% Thường, 15% Bạc |
| 600–799 | 55% Thường, 35% Bạc, 10% Vàng |
| ≥ 800 | 30% Thường, 40% Bạc, 25% Vàng, 5% Tinh Thể |

**Chăm sóc hằng ngày của người chơi:**

| Việc | Cách làm |
| --- | --- |
| Cho ăn | Đổ cỏ khô vào máng (hoặc cho gặm cỏ ngoài bãi khi trời tốt) |
| Cho uống | Đổ nước từ bình vào máng nước |
| Vuốt ve | E vào con vật (+10 hạnh phúc, 1 lần/ngày/con) |
| Mở/đóng cửa chuồng | Thả ra bãi chăn lúc sáng; **đóng lại trước 19:00** kẻo quái/cáo |
| Dọn chuồng | Nhặt phân (cho phân bón miễn phí) |
| Chữa bệnh | Thuốc thú y từ Bác sĩ Minh (1 chai/lần) |

**Môi trường sống:**

- **Gà, vịt:** chuồng gà + sân thả; vịt cần ao nước. Không ở ngoài khi mưa lớn.
- **Bò, dê, cừu:** chuồng + **bãi cỏ** (cỏ mọc theo mùa, mục 5.3). Ăn cỏ ngoài trời thì không tốn cỏ khô và tăng hạnh phúc. Tự động vào chuồng khi mưa lớn/bão.
- **Heo:** cần khu đất ngoài trời có cây để tìm nấm cục.
- **Ong:** cần hoa trong 5 ô, ngừng hoạt động khi mưa và mùa Đông.
- **Ngựa:** chuồng ngựa có mái, cần chải lông định kỳ để giữ hạnh phúc.
- **Nguy hiểm ban đêm:** cáo và sói tấn công con vật ở ngoài hoặc chuồng không đóng cửa. Có chó trông nhà thì rủi ro giảm 70%.

### 10.4 Công trình và thức ăn cho động vật

| Công trình | Cấp / sức chứa | Chi phí | Chức năng |
| --- | --- | --- | --- |
| Chuồng gà | Cấp 1: 4 con. Cấp 2: 8 con + máng tự động. Cấp 3: 12 con + lò ấp trứng | 4.000 Xu + 300 gỗ + 100 đá. Cấp 2: 10.000 + 400 gỗ. Cấp 3: 20.000 + 600 gỗ | Nhà, ổ đẻ, máng, lò sưởi (cấp 2+) |
| Chuồng bò | Cấp 1: 4 con. Cấp 2: 8 con. Cấp 3: 12 con | 8.000 Xu + 400 gỗ + 150 đá. Cấp 2: 15.000. Cấp 3: 28.000 | Bò, dê, cừu, heo (theo cấp) |
| Chuồng ngựa | 1 con | 10.000 Xu + 100 sắt | Ngựa cưỡi |
| Silo | 240 bó cỏ khô | 100 Xu + 50 đá + 10 đồng thỏi | Cất cỏ khô |
| Máng nước | Theo chuồng | 200 Xu | Cấp nước |
| Ao vịt | 2×3 ô | 500 Xu + 50 đá | Vịt bơi, hạnh phúc +20 |
| Tổ ong | 1 tổ | 1.000 Xu hoặc chế tạo | Sản xuất mật |
| Hàng rào | Mỗi ô | 10 gỗ | Giữ vật nuôi ngoài trời trong khu |

**Thức ăn:**

| Loại | Nguồn | Giá | Hiệu quả |
| --- | --- | --- | --- |
| Cỏ khô | Cắt cỏ bằng lưỡi hái (40% rơi 1 bó), mua ở tiệm | 50 Xu/bó | Đủ ăn |
| Cám ngũ cốc | Chế biến từ bắp, lúa | 120 Xu | Đủ ăn + 20 hạnh phúc |
| Thức ăn thú cưng | Quán Hương Lúa, tiệm | 40 Xu | Giữ hạnh phúc thú cưng |

### 10.5 Động vật hoang

| Tên | Môi trường | Thời điểm | Hành vi | Tương tác | Vật phẩm |
| --- | --- | --- | --- | --- | --- |
| Thỏ rừng | Rừng, Đồng Cỏ | Sáng, chiều | Nhảy loanh quanh, chạy khi lại gần | Cho ăn cà rốt, làm quen | Lông thỏ (rụng tự nhiên), mở Bách khoa |
| Chim sẻ | Mọi map ngoài trời | Ban ngày, không mưa | Mổ hạt, bay khi lại gần | Rải hạt giống làm quen | Hạt giống (hiếm) |
| Vịt trời | Hồ Gương, sông | Sáng, chiều | Bơi theo đàn | Cho ăn bánh mì | Lông vũ, trứng vịt trời |
| Ếch | Hồ, bãi sậy | Mưa, đêm | Kêu theo nhịp | Bắt bằng vợt | Nhờ ếch, mở nhiệm vụ ẩn |
| Cua | Bãi biển | Thủy triều thấp | Bò ngang | Bắt bằng bẫy | Cua, vỏ cua |
| Bướm | Rừng, nông trại | Xuân–Hạ, nắng | Bay quanh hoa | Vợt côn trùng | Phấn bướm (nguyên liệu) |
| Đom đóm | Hồ, rừng | Đêm Hạ | Phát sáng nhấp nháy | Vợt | Bột sáng (nguyên liệu đèn) |
| Hươu | Rừng, Núi Mây | Sáng sớm, hiếm | Chạy khi bị động | Quan sát đứng yên 5 giây | Sừng rụng (Thu), nhiệm vụ ẩn |
| Cú | Rừng, Đài thiên văn | Đêm | Đậu trên cành | Đứng gần Lão Quang | Lông cú, gợi ý nhiệm vụ |
| Cáo | Rừng, rìa nông trại | Đêm | Trộm trứng, dọa vật nuôi | Đuổi bằng chó/đèn | Lông cáo khi chạy mất |

---

## 11. Quái vật

### 11.1 Tổng quan và giao diện

**Quái Quên** sinh ra từ Sương Quên, hình thù gợi sự mờ nhạt của ký ức: mực loang, giấy rách, bóng mờ. Chúng **không rơi máu**, khi bị hạ sẽ tan thành mực/giấy trong 6 khung hoạt ảnh.

**Giao diện quái:**

- Sprite 16×16 (nhỏ), 24×24 (vừa), 32×32 (lớn), 48×48 trở lên (trùm). Biến thể màu theo vùng bằng palette swap.
- **Thanh HP nhỏ** xuất hiện phía trên đầu khi bị đánh, ẩn sau 4 giây.
- Tên và **cấp** hiện khi di chuột/đưa mắt ngắm; tinh anh có viền vàng, Alpha có viền đỏ và kích thước ×1,5.
- Dấu `!` đỏ khi phát hiện người chơi; **vùng đỏ báo hiệu** (telegraph) trước mỗi đòn mạnh.
- Trúng đòn: nhấp nháy trắng 0,1 giây, bật lùi nhẹ.

### 11.2 Bảng chỉ số quái

| Quái | Vùng và thời điểm | Cấp | HP | ATK | DEF | Tốc độ (px/s) | XP gốc | Vật phẩm rơi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Slime Mực | Rừng (đêm, mưa); Hầm tầng 1–10 | 1 | 30 | 6 | 0 | 28 | 8 | Mực Quên (80%), Gel (30%), Hạt giống hiếm (5%) |
| Sâu Đá | Hầm tầng 1–15 | 2 | 45 | 7 | 3 | 22 | 12 | Đá (90%), Đồng (50%), Than (20%) |
| Dơi Giấy | Hầm 1–20; Hầm sách | 3 | 22 | 8 | 0 | 55 | 10 | Giấy Mục (70%), Trang Sách Rách (25%) |
| Nấm Độc | Rừng (sáng sương, mùa Thu) | 4 | 55 | 9 | 2 | 18 | 16 | Bào Tử (60%), Nấm (50%), Thảo dược (25%) |
| Cua Đá | Bãi biển (sáng, chiều, triều thấp) | 5 | 70 | 10 | 8 | 25 | 20 | Càng Cua (60%), Vỏ sò (40%) |
| Quái Điện | Mọi map ngoài trời khi giông | 7 | 50 | 15 | 0 | 60 | 30 | Mảnh Sét (40%), Đồng (20%) |
| Nhện Hang | Hầm 11–30 | 8 | 80 | 14 | 4 | 48 | 28 | Tơ Nhện (70%), Sắt (30%) |
| Sói Bóng Đêm | Rừng đêm; Núi Mây | 9 | 110 | 18 | 5 | 70 | 40 | Lông Sói (60%), Móng Sói (25%) |
| Ma Sương | Khi có Sương Quên; Núi Mây sáng sớm | 10 | 60 | 16 | 0\* | 40 | 35 | Tinh Sương (50%), Bụi Sao (2%) |
| Linh Băng | Đông; Núi Mây | 11 | 120 | 20 | 6 | 40 | 50 | Tinh Băng (50%), Bạc (15%) |
| Sách Hộ Pháp | Hầm sách | 12 | 160 | 22 | 10 | 30 | 60 | Trang Sách Cổ (60%), Chìa Mực (nhiệm vụ) |
| Golem Đá | Hầm tầng 25–40 | 15 | 300 | 30 | 20 | 20 | 90 | Tinh Thể (40%), Vàng thỏi (20%), Đá quý (30%) |

*\*Ma Sương: DEF 0, nhưng nhận **chỉ 50% sát thương** khi đứng ngoài vùng sáng; trong vùng ánh sáng đèn lồng nhận 100%.*

**Công thức sát thương:**

- `sát_thương = max(1, round(ATK_công × 100 / (100 + DEF_thủ) × ngẫu_nhiên(0,9; 1,1)))`, nhân chí mạng nếu có.
- Chỉ số quái **tăng theo tầng hầm:** HP × `(1 + 0,12 × (tầng − 1))`, ATK × `(1 + 0,08 × (tầng − 1))`.

### 11.3 Phương thức tấn công, kỹ năng và hiệu ứng

| Quái | Kiểu tấn công | Báo hiệu | Kỹ năng / hiệu ứng đặc biệt |
| --- | --- | --- | --- |
| Slime Mực | Nhảy lao 2 ô | 0,5 giây | Chết thì 30% tách thành 2 slime nhỏ (HP 8); đòn trúng có 5% gây **Mù** |
| Sâu Đá | Chui xuống → trồi lên đánh vòng tròn 1 ô | 0,6 giây | Khi chui xuống miễn sát thương |
| Dơi Giấy | Bay ngoằn ngoèo, lao cắn | 0,3 giây | Khi trúng đòn tản ra thành mảnh giấy rồi gom lại sau 1 giây |
| Nấm Độc | Không đuổi theo; phun bào tử vùng 2,5 ô mỗi 3 giây | 0,4 giây | Gây **Độc**; tiêu diệt bằng giáo từ xa là an toàn nhất |
| Cua Đá | Kẹp càng trước mặt 1 ô | 0,5 giây | Giả làm đá; co vỏ (+10 DEF 3 giây), búa phá được vỏ |
| Quái Điện | Nhảy chớp 3 ô | 0,4 giây | Chạm gây **Choáng** 1,5 giây |
| Nhện Hang | Phun tơ thẳng 4 ô, nhảy 3 ô | 0,5 giây | Tơ gây **Chậm**; đẻ nhện con khi chết (10%) |
| Sói Bóng Đêm | Lao nhào 4 ô | 0,6 giây | **Tru** gọi bầy (thêm 1–2 sói, 1 lần mỗi trận) |
| Ma Sương | Lướt xuyên tường, vồ | 0,5 giây | Gây **Quên** 20 giây; yếu dưới ánh sáng |
| Linh Băng | Bắn tinh băng thẳng, bay 5 ô | 0,6 giây | Gây **Chậm** và **Lạnh** |
| Sách Hộ Pháp | Ném 3 trang sách xoay (hình quạt) | 0,7 giây | Tạo ô "cấm chữ" trên sàn: đứng vào bị Choáng 1 giây |
| Golem Đá | Dậm đất vòng tròn 2 ô; ném đá 5 ô | 0,9 giây | Dậm: **Choáng**; phá được bằng búa ở giáp lưng |

**Máy trạng thái AI (`StateMachine`):**

`Idle` → `Wander` → `Alert` (0,4 giây, dấu !) → `Chase` → `Telegraph` → `Attack` → `Recover` (0,5–1 giây) → quay lại `Chase`; nhánh phụ: `Flee` (khi HP < 20%, chỉ một số loại), `Stunned`, `Dead`.

- **Phát hiện:** bán kính 6–9 ô, mất dấu sau 2 giây ngoài tầm nhìn.
- **Dây xích (leash):** rời tổ hơn 12 ô thì quay về và hồi 5% HP mỗi giây.
- **Điều hướng:** `NavigationAgent2D`, tránh vật cản và nước sâu.
- **Trạng thái gây ra** dùng đúng danh sách ở mục 7.5.

### 11.4 Kinh nghiệm và vật phẩm khi hạ quái

**XP Cư Dân khi hạ quái** = `XP_gốc × hệ_số_phẩm × hệ_số_chênh_cấp`

- `hệ_số_chênh_cấp = clamp(1 + 0,1 × (cấp_quái − Cấp_Cư_Dân), 0,25; 1,5)`.
- XP **Chiến đấu** nhận thêm = 60% con số trên (không áp dụng quy tắc 50% chung nữa).

| Phẩm | Hệ số XP | Số lượt rơi vật phẩm | Ghi chú |
| --- | --- | --- | --- |
| Thường | ×1 | 1 | Bảng rơi ở 11.2 |
| Tinh anh | ×2,5 | 2 | Thêm rơi hiếm |
| Alpha (thủ lĩnh bầy) | ×4 | 3 | 1 lượt chắc chắn là hiếm |
| Mini-boss | ×10 | 4 + rương | Vật phẩm độc quyền |
| Boss / Bóng Quên | ×25 | Bảng riêng + rương lớn | Mảnh Sao (nếu là Bóng Quên) |

- **May mắn** của người chơi cộng 1% mỗi điểm vào tỉ lệ rơi vật phẩm hiếm.
- Vật rơi nằm trên đất đến hết ngày; túi đầy thì bật dội lại.

### 11.5 Vùng hoạt động và quy tắc xuất hiện (`SpawnDirector`)

| Vùng | Điều kiện xuất hiện | Quái và số lượng tối đa |
| --- | --- | --- |
| Rừng Thì Thầm | Ban ngày: chỉ Nấm Độc khi sương/mùa Thu. Từ 20:00: nhiều quái | Slime Mực ×6, Sói Bóng Đêm ×2 (Alpha 20%; Trăng Tròn 60%), Nấm Độc ×3 |
| Hầm Đá tầng 1–10 | Luôn luôn | Slime Mực, Sâu Đá, Dơi Giấy; **Boss tầng 10: Slime Mực Mẹ** |
| Hầm Đá tầng 11–20 | Luôn luôn | Thêm Nhện Hang, Nấm Độc; **Boss tầng 20: Chúa Dơi Giấy** |
| Hầm Đá tầng 21–30 | Luôn luôn | Thêm Quái Điện, Golem nhỏ; **Boss tầng 30: Golem Công Thức** (Bóng Quên của Mảnh Vật) |
| Hầm Đá tầng 31–40 | Luôn luôn | Golem Đá, Nhện Hang, Ma Sương, nhiều tinh anh; **Boss tầng 40: Hầm Vương** |
| Hầm sách | Sau chương 3 | Dơi Giấy, Sách Hộ Pháp; **Gã Gạch Xóa** |
| Bãi biển | Sáng–chiều khi triều thấp; đêm có Ma Sương | Cua Đá ×5 |
| Núi Mây | Quanh năm, sương sớm | Sói Bóng Đêm, Linh Băng, Ma Sương; **Hồn Ký Ức** |
| Nông trại, Làng | Không xuất hiện (vùng an toàn), trừ đêm Trăng Tròn | Vài Slime Mực lạc vào nông trại |

**Quy tắc chung:** sinh ngoài tầm nhìn (≥ 12 ô), tối đa theo bảng, nhóm 2–4 con, **reset mỗi ngày lúc 06:00** (quái chưa chết biến mất). Thời tiết đổi bảng: mưa +30% Slime Mực; giông thêm Quái Điện; Sương Quên thêm Ma Sương; Đông thay Sói Bóng Đêm bằng Sói Tuyết (cùng chỉ số, +10% HP).

### 11.6 Bầy quái, quái đặc biệt và Bóng Quên

| Loại đặc biệt | Cách nhận biết | Chỉ số | Hành vi / kỹ năng thêm |
| --- | --- | --- | --- |
| **Tinh anh** | Viền vàng | HP +60%, ATK +20% | 1 kỹ năng thêm (ví dụ Sói tinh anh lao 2 lần) |
| **Alpha** (thủ lĩnh bầy) | To ×1,5, viền đỏ, tiếng tru đặc biệt | HP +150%, ATK +30% | Tạo **hào quang** +15% ATK cho bầy trong 5 ô; gọi thêm 2 con; chết thì cả bầy hoảng sợ, bỏ chạy 5 giây |
| **Quái biến dị theo thời tiết** | Đổi màu (Slime Mưa xanh dương, Sói Tuyết trắng) | Nhanh hơn 20% | Hiệu ứng riêng theo thời tiết |
| **Quái Quên Vàng** | Lấp lánh, chạy trốn | HP thấp, tốc độ cao | Hiếm 1%; hạ được rơi **Bụi Sao** |
| **Mini-boss vùng** | Thanh HP lớn trên màn hình | HP ×10 | 2–3 pha, thưởng độc quyền |

**Bầy (`MonsterPack`):** là Resource mô tả tỉ lệ thành viên (ví dụ bầy sói: 2–3 thường + 0–1 Alpha), đội hình (vòng vây, một hàng) và hành vi chung (cả bầy đuổi theo khi một con phát hiện).

**Năm Bóng Quên canh Mảnh Sao (và trùm cuối):** mỗi trận là **chiến đấu + đố**, người chơi không thể chỉ đánh liều.

| Bóng Quên | Địa điểm | Pha chiến đấu | Cách thắng (phần đố) |
| --- | --- | --- | --- |
| Bóng Số Không | Hầm trường | Né các con số rơi từ trần | Ở pha 2, 3 phép tính hiện lên; đánh trúng con số kết quả đúng để làm nứt Số Không |
| Gã Gạch Xóa | Hầm sách | Gạch xóa chữ trên sàn đấu | Điền từ đúng vào câu để khôi phục ô sàn, ô sàn khôi phục thì không bị xóa nữa |
| Thủy Thủ Câm | Bến cảng (trên tàu) | Sóng đánh, mỏ neo quét | Trả lời hội thoại tiếng Anh để "giải bùa im lặng", mỗi câu đúng làm lộ điểm yếu |
| Golem Công Thức | Hầm tầng 30 | Dậm đất, ném đá | Đánh các "khớp" sáng theo đúng thứ tự công thức khoa học (nối mạch) |
| Hồn Ký Ức | Núi Mây | Sương dày, ảo ảnh | Sắp xếp các mốc ký ức theo thứ tự thời gian để mở đường đến Mảnh Ký |
| **Kẻ Xóa Chữ** | Đài thiên văn | 3 pha: xóa chữ, xóa số, xóa ngôn ngữ | Dùng cả 5 mảng tri thức; mỗi mảng đạt cấp cao hơn thì được thêm "nhắc nhớ" (hỗ trợ) |

---

## 12. Cây cối, hoa cỏ và thực vật

### 12.1 Phân loại và cách biểu diễn

| Nhóm | Đại diện | Biểu diễn | Thu hoạch bằng |
| --- | --- | --- | --- |
| Cây trồng | Cà rốt, cà chua, bí ngô... | Thực thể `Plant` trên 1 ô đất | E / lưỡi hái |
| Cây ăn quả | Táo, đào, cam, hồng | Thực thể 3×3 ô (thân + tán) | E vào trái chín / lắc cây |
| Cây rừng | Sồi, thông, phong | Thực thể có HP, thân + tán tách lớp | Rìu |
| Hoa | Cúc, tulip, hướng dương, hoa tuyết | Thực thể 1 ô, trồng hoặc mọc dại | E |
| Cỏ và bụi | Cỏ cao, bụi dâu, bụi rậm | Tile trang trí có hành vi | Lưỡi hái / E |
| Hái lượm | Nấm, dâu rừng, hạt dẻ, tỏi dại | Vật nhỏ mọc ngẫu nhiên | E |

**Quy cách hiển thị:**

- Mỗi cây trồng có **4–6 khung sinh trưởng**: hạt → mầm → non → trưởng thành → **chín** (có điểm nhấn sáng) → héo. Cây cao dùng sprite 16×32 gốc ở chân.
- Ô đất **đã tưới** tối hơn một sắc; ô đã bón có chấm sáng; ô khô trở lại sáng màu khi qua ngày.
- **Gió:** shader làm cây đung đưa nhẹ; gió lớn đung đưa mạnh và rụng lá. Nhân vật đi qua bụi/cỏ cao làm nó rung.
- **Mùa:** cây rừng và cỏ đổi sprite theo mùa (xuân hoa trắng, hạ xanh đậm, thu cam đỏ, đông trụi lá và phủ tuyết khi `snow_cover` > 0,3).
- Y-sort theo điểm gốc; tán cây vẽ ở lớp trên, mờ dần (alpha 60%) khi nhân vật đi sau.

### 12.2 Quy tắc trồng trọt

1. **Cuốc** ô cỏ → ô đất; **gieo** hạt (đúng mùa, đất đã cuốc); **tưới** mỗi ngày (mưa tự tưới ngoài trời).
2. Cây chỉ tăng **1 ngày sinh trưởng** khi ô được tưới trong ngày. Không tưới thì đứng im; **3 ngày liền không tưới** thì héo.
3. Chuyển mùa: cây trái mùa **héo** lúc 06:00 ngày 1 (trong Nhà kính thì không). Khi gieo, UI cảnh báo nếu "không kịp thu hoạch trước khi hết mùa".
4. **Phân bón:** Phân thường (+chất lượng), Phân tăng trưởng (−1 ngày sinh trưởng, tối thiểu 2 ngày), Phân giữ nước (giữ ẩm 1 ngày không cần tưới).
5. **Chất lượng nông sản:** phụ thuộc cấp Nông nghiệp, phân bón, May mắn và tưới đủ liên tục.
6. **Thời tiết:** mưa tự tưới; Nóng gay gắt làm đất khô lúc 12:00; Giông có nguy cơ sét đánh; Tuyết/Bão tuyết giết cây ngoài trời trái mùa.

### 12.3 Bảng cây trồng

| Cây | Mùa | Ngày lớn | Thu lại | Giá hạt | Giá bán | XP Nông nghiệp |
| --- | --- | --- | --- | --- | --- | --- |
| Cải xanh | Xuân | 2 | Không | 20 | 40 | 4 |
| Cà rốt | Xuân | 3 | Không | 30 | 70 | 6 |
| Khoai tây | Xuân | 4 | Không (1–2 củ) | 50 | 110 | 9 |
| Dâu tây | Xuân | 5 | Mỗi 2 ngày | 100 | 120 | 12 |
| Ớt | Hạ | 3 | Mỗi ngày | 40 | 45 | 5 |
| Cà chua | Hạ | 4 | Mỗi 2 ngày | 50 | 80 | 8 |
| Bắp | Hạ | 5 | Mỗi 2 ngày | 150 | 50 | 7 |
| Dưa hấu | Hạ | 6 | Không | 80 | 250 | 22 |
| Khoai lang | Thu | 3 | Không | 60 | 100 | 8 |
| Cà tím | Thu | 4 | Mỗi 2 ngày | 20 | 60 | 7 |
| Nho | Thu | 5 | Mỗi 2 ngày | 60 | 80 | 9 |
| Bí ngô | Thu | 6 | Không | 100 | 320 | 26 |
| Củ cải tuyết | Đông (Nhà kính, ô sương giá) | 3 | Không | 40 | 90 | 7 |
| Nấm tuyết | Đông (Hầm nấm trong nhà) | 4 | Không | 60 | 140 | 10 |

### 12.4 Cây ăn quả

| Cây | Mùa ra quả | Thời gian lớn | Quả mỗi ngày | Giá bán quả | XP |
| --- | --- | --- | --- | --- | --- |
| Đào | Xuân | 5 ngày | 1 (tối đa 3 tích) | 100 | 8 |
| Cam | Hạ | 5 ngày | 1 | 120 | 8 |
| Táo | Thu | 5 ngày | 1 | 140 | 9 |
| Hồng | Thu | 5 ngày | 1 | 160 | 10 |

Cây non cần 3×3 ô trống quanh nó. Ngoài mùa ra quả cây vẫn sống nhưng không ra quả; Mùa Đông trụi lá.

### 12.5 Cây rừng và thu hoạch gỗ

| Cây | Xuất hiện | Độ bền | Vật phẩm rơi | Ghi chú |
| --- | --- | --- | --- | --- |
| Sồi | Rừng, nông trại | 40 | Gỗ ×8–12, Nhựa (30%), Quả sồi (25%) | Cây gỗ phổ biến |
| Thông | Rừng, Núi Mây | 35 | Gỗ ×6–10, Nhựa thông (30%), Hạt thông (25%) | Xanh quanh năm |
| Phong | Rừng (mùa Thu) | 40 | Gỗ ×8–12, Xi-rô phong (khi gắn ống dẫn nhựa) | Lá đỏ rơi mùa Thu |
| Cây già (cổ thụ) | Rừng sâu | 120 | Gỗ cứng ×4, vật phẩm hiếm | Cần Rìu Sắt |

- Số nhát chặt = `ceil(độ_bền / (sát_thương_rìu × hệ_số_bậc))`. Cây đổ ngả **ngược hướng người chơi**, bị chặn bởi vật cản.
- Gốc cây còn lại: cần Rìu Đồng trở lên hoặc cuốc chim để nhổ, rơi thêm gỗ.
- Trồng lại bằng hạt: cây non lớn qua 4 giai đoạn trong 4 ngày. XP Hái lượm: chặt đổ cây 10, nhổ gốc 4.

### 12.6 Hoa, cỏ và bụi

| Loại | Mùa / nơi | Thu hoạch | Vật phẩm |
| --- | --- | --- | --- |
| Hoa cúc, tulip | Xuân | E | Hoa (quà tặng, nguyên liệu nước hoa, mật ong) |
| Hướng dương | Hạ | E | Hoa, hạt hướng dương |
| Cúc vàng | Thu | E | Hoa, dùng cho lễ hội Gặt |
| Hoa tuyết | Đông | E | Hoa hiếm |
| Hoa Nguyệt | Đêm Trăng Tròn, Rừng | E | Nguyên liệu thuốc quý |
| Cỏ cao | Mọi mùa trừ Đông (chết dần) | Lưỡi hái | 40% rơi cỏ khô |
| Bụi dâu | Xuân, Thu | E | Dâu rừng ×2–4, mọc lại sau 2 ngày |
| Bụi rậm | Mọi map | Lưỡi hái / Lướt qua | Gỗ vụn, đôi khi hạt giống |

### 12.7 Hái lượm theo mùa

| Mùa | Rừng / Nông trại | Bờ nước / Biển | Hầm / Núi |
| --- | --- | --- | --- |
| Xuân | Tỏi dại, rau dớn, hoa dại | Rau cải xoong | Tuyết lan (chân núi) |
| Hạ | Dâu rừng, hoa hướng dương dại | Vỏ sò, rong biển | Nấm đá |
| Thu | Nấm, hạt dẻ, mâm xôi | Sò điệp | Nấm hang |
| Đông | Rễ củ, quả cây trụi lá | San hô (biển lặng) | Tinh băng, hoa Nhung Tuyết |

**Quy tắc:** mỗi sáng 06:00 spawn 3–8 vật hái lượm mỗi map; **nấm mọc nhiều hơn sau mưa**; hái được +3 XP Hái lượm; cấp Hái lượm tăng cơ hội chất lượng cao và nhặt thêm.

---

## 13. Sông, núi, biển, hồ

### 13.1 Cách thể hiện chung

- **Nước** là lớp TileMap riêng `Water` dùng tile hoạt hình 4 khung (0,4 giây/khung), viền bờ dùng Terrain autotile (bọt sóng). Nước sâu có va chạm chặn, nước nông cho đi (chậm 30%).
- Shader nước: gợn sóng, phản chiếu mờ bầu trời và bóng cây (cường độ theo `light_level`).
- Mỗi vùng nước có `FishingZone` (Area2D) chứa bảng cá theo mùa/giờ/thời tiết.
- **Địa hình cao (núi)** dùng nhiều `height_level` (0–3): vách đá là tile chặn, bậc thang là tile nối giữa các mức, nhân vật đổi lớp vẽ khi lên cao.

### 13.2 Hồ sơ từng địa hình

| Địa hình | Giao diện | Hiệu ứng / trạng thái | Động vật | Vật phẩm | Tương tác |
| --- | --- | --- | --- | --- | --- |
| **Sông Bạc** | Nước chảy một chiều (tile hoạt hình + đốm bọt), cầu gỗ, đá nổi | Mưa lớn: nước dâng, cầu ngập 1 ngày. Đông: viền sông đóng băng mỏng. Âm thanh róc rách | Cá, vịt trời, ếch, rùa | Sỏi, sậy, cát vàng | Câu cá, đặt bẫy cá, đi trên đá nổi |
| **Hồ Gương** | Mặt hồ phẳng, phản chiếu rõ; sen nở mùa Hạ | Sương sớm; đom đóm đêm Hạ; Đông **đóng băng hoàn toàn**, đi bộ được, đục lỗ câu băng | Cá chép, cá cầu vồng, vịt trời, ếch, đom đóm | Sen, rong hồ, Ngọc Hồ (hiếm) | Câu cá, thả bè (sau Ch4), thả đèn nước (lễ hội) |
| **Bãi biển và biển** | Cát vàng, sóng vỗ vào bờ, hải âu bay | **Thủy triều** 6 giờ game: triều thấp lộ ao nước đọng; giông: sóng cao, cấm mép nước; đêm: đèn bến cảng | Cua, hải âu, sao biển, cá biển, rùa biển (hiếm) | Vỏ sò, san hô, rong biển, chai thư, ngọc trai | Nhặt, đặt bẫy cua, câu biển (cần Áo Phao ở vùng sâu) |
| **Núi Mây** | Vách đá nhiều tầng, đường mòn zig-zag, thác nước hoạt hình + sương | Tuyết phủ từ độ cao 2; sương dày sáng sớm; trời quang đêm: sao rõ nhất | Hươu, chim ưng, sói tuyết, Linh Băng | Quặng lộ thiên, Hoa Nhung Tuyết, tinh băng | Leo vách (Móc leo), cắm trại hồi phục tại trạm dừng chân, quan sát sao |
| **Thác nước** | Dòng nước đổ, màn sương mờ, cầu vồng khi nắng | Âm thanh lớn che tiếng quái | Cá Sao (đêm sao băng) | Đá ẩm, rêu | Câu cá ở chân thác, hang sau thác (nhiệm vụ ẩn) |

**Tương tác của nhân vật với nước:**

| Hành động | Điều kiện | Kết quả |
| --- | --- | --- |
| Múc nước | Cầm bình tưới + E vào nước | Đầy bình |
| Rửa mặt | E vào nước (ở giếng/bờ) | Xóa trạng thái Mù |
| Lội nước nông | Đi vào | Tốc độ −30%, không dùng công cụ |
| Bơi vùng sâu | Có Áo Phao (Ch4) | Đi trên nước sâu, tốn thể lực mỗi giây |
| Đi trên băng | Đông, hồ đóng băng | Trượt nhẹ (giày chống trượt khử hiệu ứng) |

### 13.3 Câu cá

**Cơ chế (3 bước):**

1. **Quăng:** giữ J nạp thanh lực; thả đúng vòng sáng thì "quăng hoàn hảo" (mở khóa Câu cá cấp 4).
2. **Chờ:** dấu `!` xuất hiện sau 0,5–3 giây (mồi tốt rút ngắn). Có 1 giây để nhấn J.
3. **Kéo:** mini-game thanh kiểm soát: con cá di chuyển lên xuống, giữ J để nâng thanh xanh của người chơi, giữ cá nằm trong thanh để đầy thanh tiến độ. Độ khó cá 1–5 quyết định tốc độ và độ giật. **Hoàn hảo** (không để tuột lần nào) thì chất lượng cao hơn và XP ×1,5.

**Cần câu:** Tre (khởi đầu), Sợi Thủy Tinh, Sắt, Vàng, Tinh Thể (nâng cấp ở Lò rèn); cần bậc cao mở vùng sâu và rút ngắn thời gian chờ.

| Cá | Nơi | Mùa | Giờ | Thời tiết | Độ khó | Giá bán | XP Câu cá |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Cá bống | Sông | Cả năm | Cả ngày | Mưa | 1 | 30 | 4 |
| Cá chép | Hồ Gương | Xuân–Thu | Cả ngày | Mọi | 2 | 70 | 8 |
| Cá rô | Sông | Xuân, Thu | 06:00–19:00 | Nắng, mây | 2 | 80 | 8 |
| Cá trê | Sông | Hạ, Thu | 18:00–02:00 | Mưa tăng tỉ lệ | 3 | 120 | 12 |
| Cá lóc | Hồ | Hạ | 06:00–12:00 | Nắng | 3 | 150 | 14 |
| Cá cầu vồng | Hồ | Hạ | 10:00–18:00 | Nắng, cầu vồng | 3 | 200 | 16 |
| Cá hồi băng | Hồ (lỗ băng) | Đông | 08:00–17:00 | Mọi | 3 | 220 | 18 |
| Cá thu | Biển | Xuân, Hạ | 06:00–18:00 | Nắng | 3 | 140 | 14 |
| Cá ngừ | Biển | Hạ | 08:00–16:00 | Nắng | 4 | 260 | 20 |
| Mực ống | Biển | Thu, Đông | 20:00–02:00 | Mọi | 3 | 160 | 15 |
| Cá chình | Sông | Thu | 20:00–02:00 | Mưa | 4 | 280 | 22 |
| Cá mặt trăng | Biển | Đông | 22:00–02:00, đêm Trăng Tròn | Quang | 5 | 600 | 40 |
| **Cá Sao** (huyền thoại) | Thác nước | Mọi mùa | Đêm có mưa sao băng | Quang | 5 | 1.200 | 70 |
| **Rồng Sương** (huyền thoại) | Hồ Gương | Thu | 05:00–09:00, khi Sương Quên | Sương mù | 5 | 1.500 | 80 |

**Bẫy cua / bẫy cá:** đặt ở mép nước, mồi nhử, kiểm tra mỗi sáng. Cho cua, tôm, sò (giá 40–120).

---

## 14. Màn hình và luồng giao diện

### 14.1 Sơ đồ luồng

```
Boot → Splash (logo) → Màn hình Tiêu đề
                          ├─ Tiếp tục → Tải save → Map cuối cùng
                          ├─ Trò chơi mới → Tạo nhân vật → Thú cưng/Môn yêu thích → Cutscene mở đầu → Nông trại (Xuân 1, 06:00)
                          ├─ Tải game (3 ô)
                          ├─ Phòng học (ôn luyện, không cần save)
                          ├─ Cài đặt
                          └─ Thoát

Trong game:  Playing ⇄ Menu / Hội thoại / Mini-game / Cutscene / Tổng kết ngày / Màn hình ngất
```

### 14.2 Màn hình Tiêu đề (màn hình bắt đầu)

- **Phông nền:** toàn cảnh làng 4 lớp parallax (sao – núi – đồi – làng). Cảnh phản ánh **mùa, giờ, thời tiết của bản lưu gần nhất**; chưa có save thì là bình minh mùa Xuân.
- **Hoạt động nền:** khói ống khói, chim bay, mây trôi, đom đóm vào đêm, tuyết/mưa rơi theo thời tiết; ngôi sao nhỏ nhấp nháy tượng trưng cho Ngôi Sao Tri Thức.
- **Logo** "Làng Sao Mai" pixel ở trên-giữa; menu dọc ở trái-giữa: Tiếp tục, Trò chơi mới, Tải game, Phòng học, Cài đặt, Thoát. Con trỏ là Sổ Tay nhỏ.
- **Ô tải game (3 ô):** tên nhân vật, tên nông trại, ngày-mùa-năm, giờ chơi, ảnh chụp cảnh lúc lưu.
- **Nhạc:** giai điệu piano nhẹ + sáo; âm nền chim và gió.

### 14.3 Tạo nhân vật và cảnh mở đầu

1. **Tạo nhân vật** (7.1): xem trước 4 hướng, hoạt ảnh đi/đứng.
2. **Chọn thú cưng và môn yêu thích.**
3. **Cutscene mở đầu (\~90 giây, có thể bỏ qua):** xe buýt đến làng lúc sáng sớm, cảnh trượt qua các khu vực, người chơi đến cổng nông trại; Dì Năm đưa chìa khóa và lá thư; con thú cưng chạy ra.
4. Vào nông trại 06:00 ngày 1 mùa Xuân; hướng dẫn nhẹ bằng gợi ý trên màn hình, không khóa điều khiển.

### 14.4 Mỗi khu vực một chủ đề riêng (bố cục, bảng màu, âm thanh)

| Màn hình / map | Bố cục và hướng đi | Bảng màu chủ đạo | Nhạc và âm thanh | Cảm giác |
| --- | --- | --- | --- | --- |
| Nông Trại | Mở, lối ra ở 4 hướng, trung tâm là khu đất canh tác | Xanh lá, nâu đất, ấm | Guitar mộc, tiếng gà, gió | Bình yên, của riêng mình |
| Đồng Cỏ | Thảo nguyên rộng, rào gỗ | Xanh nhạt, vàng nắng | Sáo, bê kêu | Thư thái |
| Phố Chợ | Hẹp, dài, cửa hàng hai bên | Cam ấm, đỏ gạch | Jazz nhẹ, tiếng rao | Nhộn nhịp |
| Quảng Trường | Đối xứng, đài phun nước ở giữa | Xám be, hoa nhiều màu | Accordion, tiếng người | Cộng đồng |
| Trường Ánh Dương | Dạng chữ U, sân trước, vườn sau | Vàng chanh, xanh dương | Xylophone vui | Tươi vui, ham học |
| Đồi Thư Viện | Dốc nhẹ lên đỉnh, vườn đọc | Nâu vàng, xanh rêu | Piano + cello, lá xào xạc | Tĩnh lặng, suy tư |
| Rừng Thì Thầm | Mê cung lối mòn, ánh sáng lọt tán | Xanh thẫm, tím đêm | Sáo thì thầm; đêm: bass trầm | Huyền bí, lo âu nhẹ |
| Hầm Đá | Tầng ngang, hang động quanh co | Xám xanh, lam, đỏ lửa nhỏ | Nhỏ giọt, synth u trầm | Căng thẳng, tò mò |
| Hồ Gương & Sông | Nước ở giữa, bờ vòng quanh | Xanh lam bạc | Đàn hạc, tiếng nước | Thiền, chậm |
| Bãi Biển | Dải dài ngang, bến cảng bên phải | Xanh ngọc, vàng cát | Ukulele, sóng | Nghỉ ngơi, phiêu lưu |
| Núi Mây | Lên dọc theo nhiều tầng | Trắng, xanh lạnh, tím | Dàn dây rộng, gió | Hùng vĩ, cô độc |

### 14.5 Các màn hình phụ

| Màn hình | Kích hoạt | Bố cục và thông tin | Hành động |
| --- | --- | --- | --- |
| Hội thoại | Nói chuyện NPC | Hộp ở đáy, chân dung 48×48 bên trái, tên NPC, văn bản hiện từng chữ, lựa chọn 2–4 dòng | Phím E tiếp, số chọn, Esc đóng |
| Cửa hàng | Mở Shop | Hai cột: Hàng của tiệm / Túi đồ; tổng tiền dưới đáy | Kéo, Enter mua/bán, giữ Shift mua cả chồng |
| Tổng kết ngày | Ngủ hoặc ngất | Danh sách: Xu kiếm, vật bán, XP nhận, nhiệm vụ xong, kỹ năng/tri thức lên cấp, mất mát (nếu ngất), dự báo thời tiết mai, ảnh cảnh hoàng hôn | Nút Tiếp tục → tự động lưu → sáng hôm sau 06:00 |
| Màn hình ngất | HP = 0 hoặc 02:00 | Mờ dần đen, dòng chữ lý do, mất mát ngắn gọn | Tự chuyển sang tổng kết |
| Mini-game học | Bàn học, lớp học, câu đố | Khung riêng giữa màn hình, đề bài lớn, bộ đếm lượt, nút Gợi ý/Bỏ qua | Trả lời, xem giải thích, nhận sao |
| Bản đồ | Phím M | Bản đồ làng, đánh dấu vị trí, NPC theo lịch (nếu mở khóa Tri thức Ký) | Chọn điểm để ghim nhiệm vụ |
| Cutscene | Sự kiện tim, cốt truyện | Letterbox đen trên dưới, hội thoại, camera di chuyển | Bỏ qua bằng giữ Esc |

---

## 15. Kiến trúc kỹ thuật và lộ trình thực hiện

### 15.1 Cây node chuẩn của Player

```
Player (CharacterBody2D)
├── Visuals (Node2D)
│   ├── ShadowSprite, BodySprite, BottomSprite, ShoesSprite, TopSprite,
│   │   EyesSprite, HairSprite, HatSprite, AccessorySprite
│   └── HandItem (Node2D)
├── CollisionShape2D            # chỉ phần chân
├── AnimationPlayer             # điều khiển frame của mọi lớp
├── StateMachine                # Idle, Walk, Run, UseTool, Attack, Roll, Hurt, Faint...
├── HealthComponent
├── StaminaComponent
├── InventoryComponent
├── EquipmentComponent
├── InteractionDetector (Area2D)
├── Hurtbox (Area2D)
├── Hitbox (Area2D)             # bật theo khung hoạt ảnh tấn công
└── Camera2D
```

### 15.2 Tín hiệu mẫu trên `EventBus`

`item_added(item_id, amount)`, `item_used(item_id)`, `tool_used(tool_id, target_cell)`, `crop_harvested(crop_id, quality)`, `monster_killed(monster_id, tier)`, `quest_state_changed(quest_id, state)`, `knowledge_session_finished(subject, stars)`, `day_started(day_index)`, `season_changed(season_index)`, `weather_changed(weather_id)`, `map_entered(map_id)`, `npc_gift_given(npc_id, item_id)`, `player_leveled_up(new_level)`.

### 15.3 Dữ liệu lưu game (`save_version` bắt buộc)

| Khóa | Nội dung |
| --- | --- |
| `meta` | Phiên bản, tên, tên nông trại, ngày giờ chơi, thời gian chơi |
| `clock` | `total_game_minutes`, ngày, mùa, năm, `world_seed` |
| `player` | Vị trí, map, HP, thể lực, XP, cấp, kỹ năng, tri thức, trang bị |
| `inventory` | Túi, hotbar, rương (mỗi rương theo `persistent_id`) |
| `maps` | Trạng thái từng map: ô đất, cây, vật đặt, thú nuôi, vật rơi |
| `quests` | Trạng thái và tiến độ từng nhiệm vụ |
| `npcs` | Tim hữu nghị, quà đã tặng, sự kiện đã xem |
| `knowledge` | Cấp bậc, lịch sử câu hỏi, hộp Leitner |
| `flags` | Cờ cốt truyện, mở khóa, bách khoa |

### 15.4 Hiệu năng

- Map lớn chia **chunk**; chỉ cập nhật thực thể trong bán kính 2 màn hình quanh camera.
- Thực vật ngoài tầm nhìn chỉ cập nhật **theo ngày**, không chạy mỗi khung.
- Dùng **object pooling** cho vật rơi, hạt hiệu ứng, đạn.
- Mục tiêu: 60 FPS, dưới 300 MB RAM, nạp map dưới 1 giây trên máy phổ thông.

### 15.5 Lộ trình các cột mốc

| Cột mốc | Nội dung | Tiêu chí hoàn thành |
| --- | --- | --- |
| M0 | Dựng dự án, cấu trúc folder, autoload rỗng, pixel-perfect, CI/test | Chạy cảnh trống ở 320×180 scale nguyên |
| M1 | Player di chuyển, hoạt ảnh ghép lớp, tilemap, camera, Y-sort | Đi vòng nông trại mẫu không lỗi chồng lớp |
| M2 | `GameClock`, ánh sáng theo giờ, mùa, `WeatherSystem` có seed và dự báo | Chạy 1 ngày game trong 240 phút thực (có nút tua nhanh khi dev) |
| M3 | `ItemData`, túi đồ, hotbar, rương, UI Menu | Kéo thả, chồng, cất/lấy ổn định, lưu/tải được |
| M4 | Vòng lặp nông nghiệp: đất, tưới, cây trồng, thu hoạch, bán | Trồng–thu–bán trọn vẹn qua 3 ngày |
| M5 | `Interactable`, `MapPortal`, công trình nội/ngoại thất, `SceneManager` | Vào/ra mọi công trình, trạng thái giữ nguyên |
| M6 | NPC, lịch sinh hoạt, Dialogue Manager, Shop, hữu nghị | NPC đi theo lịch, mưa đổi lịch |
| M7 | `QuestManager`, nhật ký, theo dõi, 8 loại nhiệm vụ | Hoàn thành 1 nhiệm vụ mỗi loại từ đầu đến cuối |
| M8 | Chiến đấu, quái, `SpawnDirector`, Hầm Đá, rơi vật phẩm | 5 loại quái hoạt động, XP và drop đúng bảng |
| M9 | Động vật nuôi, công trình, chăm sóc, sản phẩm | Nuôi gà–bò qua 7 ngày, chất lượng theo hạnh phúc |
| M10 | Nước, câu cá, thủy triều, bẫy | Câu mọi loại cá theo điều kiện |
| M11 | `KnowledgeManager`, ngân hàng câu hỏi, 5 mảng mini-game, Phòng học | Thêm câu hỏi mới chỉ bằng JSON, độ khó thích ứng chạy đúng |
| M12 | Nội dung cốt truyện chương 0–7, 5 Bóng Quên, lễ hội | Chơi trọn vẹn 1 năm game |
| M13 | Âm thanh, hiệu ứng, cân bằng, trợ năng, di trú save | Qua bài test cân bằng và 60 FPS |
| M14 | Thử nghiệm kín, sửa lỗi, đóng gói | Bản build ổn định cho Windows |

### 15.6 Mẫu "Nhiệm vụ hiện tại" để điền vào Master Prompt

- *"Làm M2: viết `GameClock` autoload theo mục 4.1, tín hiệu `minute_changed`, `hour_changed`, `day_started`; thêm `WeatherSystem` sinh thời tiết có seed theo 4.4 và dự báo ngày mai; kèm scene test hiển thị giờ và thời tiết, và unit test GUT cho công thức chuyển đổi thời gian."*
- *"Làm M4 phần đất canh tác: `SoilTile` có các trạng thái ở mục 5.3 (cỏ, cuốc, tưới, bón, gieo), `Plant` đọc `CropData` theo bảng 12.3, tưới lúc mưa tự động, héo khi đổi mùa."*
- *"Làm M11 phần ngân hàng câu hỏi: nạp JSON theo schema 9.4, chọn câu theo bậc khó thích ứng và hộp Leitner, trả về 5 câu cho một phiên học."*

---

## 16. Phụ lục

### 16.1 Danh sách asset tối thiểu để bắt đầu (MVP)

| Nhóm | Số lượng gợi ý |
| --- | --- |
| Tileset ngoài trời (4 mùa) | 4 bộ × (cỏ, đất, đường, nước, cây, đá) |
| Tileset nội thất | 1 bộ chung (sàn, tường, đồ nội thất cơ bản) |
| Nhân vật | 1 body × 2 kiểu, 6 tóc, 6 áo, 4 quần, 3 giày, 3 mũ |
| NPC | 12 sprite 16×32 + 12 chân dung 48×48 |
| Công cụ và vũ khí | 6 công cụ × 5 bậc, 3 vũ khí × 5 bậc |
| Cây trồng | 14 loại × 5 khung |
| Động vật | Gà, bò (4 hướng, 3 trạng thái) trước, các loài khác sau |
| Quái | 6 loại đầu (Slime Mực, Sâu Đá, Dơi Giấy, Nấm Độc, Cua Đá, Sói) |
| UI | Khung, nút, thanh HP/thể lực, hotbar, icon vật phẩm 16×16 |
| Âm thanh | 11 nhạc nền theo map, 40 hiệu ứng, 6 âm nền (mưa, gió, sóng...) |

### 16.2 Các điểm cần bạn xác nhận trước khi bắt đầu code

1. **Độ dài mùa:** 7 ngày/mùa là phù hợp khi 1 ngày game dài 240 phút thực; nếu muốn mùa dài hơn thì chỉ sửa hằng số `DAYS_PER_SEASON` và dãn cốt truyện tương ứng.
2. **Bản quyền asset:** chọn gói asset cụ thể để chốt kích thước khung hoạt ảnh nhân vật (16×32 là giả định).
3. **Nền tảng:** PC là mặc định; nếu nhắm mobile cần thêm điều khiển cảm ứng và giảm kích thước map.
4. **Ngôn ngữ nội dung học tập:** khối lượng ngân hàng câu hỏi ban đầu (đề xuất 50 câu mỗi môn cho bản MVP).


---

# PHẦN II — BỔ SUNG ĐẶC TẢ TOÀN BỘ THẾ GIỚI GAME

# LÀNG SAO MAI — ĐẶC TẢ TOÀN BỘ THẾ GIỚI GAME

**World Design Bible / World Art & Level Specification — Bản bổ sung GDD v1.1**  
**Dự án:** Làng Sao Mai — RPG nông trại 2D top-down, khám phá, giải đố và học tập  
**Nền tảng thiết kế:** Godot 4.3+, GDScript, viewport gốc 320×180, tile 16×16, nhân vật 16×32, 60 FPS  
**Đầu vào:** (1) *Game Design Document & Master Prompt v1.0*; (2) *Đặc tả thiết kế giao diện*; (3) sáu bảng minh họa do người dùng cung cấp.  
**Trạng thái:** Bản đặc tả **bổ sung** để làm world map, level, môi trường, art asset, NPC, sự kiện và sản xuất. Không tự sửa các quy tắc nền của GDD.

> **Quy ước nguồn gốc**
> - **[GDD]**: đã được quy định trong Game Design Document; giữ nguyên khi triển khai.
> - **[UI]**: đã được quy định trong tài liệu giao diện.
> - **[HÌNH]**: chi tiết nhìn thấy ở sáu bảng minh họa, dùng làm chuẩn định hướng hình ảnh, không mặc nhiên là dữ liệu gameplay.
> - **[MỚI — ĐỀ XUẤT]**: phần viết thêm để lấp chỗ trống; chỉ trở thành nguồn sự thật sau khi được chấp thuận.
> - **[CẦN CHỐT]**: mâu thuẫn hoặc quyết định còn mở; không tự ý hợp nhất vào dữ liệu chính thức.

---

## 0. TÓM TẮT THẾ GIỚI VÀ RANH GIỚI ĐẶC TẢ

### 0.1 Trải nghiệm cốt lõi

**Làng Sao Mai là một ngôi làng sống được, không phải chỉ là bản đồ nối giữa các cửa sổ UI.** Buổi sáng người chơi nghe gà gáy ngoài nông trại, tới chợ mua giống, ngang qua trường học nghe tiếng trống, ghé bờ hồ câu cá, tối trở về trong ánh đèn vàng; sau đó dần khám phá vì sao những cuốn sách mất chữ, rừng xuất hiện Ma Sương, và năm Mảnh Sao bị phân tán. [GDD]

Mỗi vùng phải thỏa mãn ba tầng mục đích:

1. **Nơi chốn:** có địa hình, kiến trúc, âm thanh và vòng sinh hoạt nhận diện tức thì.
2. **Hoạt động:** có tối thiểu một vòng chơi 1–3 phút và một mục tiêu quay lại dài hạn.
3. **Ý nghĩa:** chứa ký ức, NPC, cơ chế tri thức hoặc dấu vết cốt truyện; không phải vùng trống chỉ để đi ngang.

Người chơi có thể tập trung vào nông nghiệp, quan hệ, nghề, sưu tầm và giải đố mà không bị ép chiến đấu liên tục. Học tập trợ giúp mở đường nhưng không khóa cứng mạch truyện. [GDD]

### 0.2 Phạm vi phiên bản này

- **11 bản đồ ngoài trời/chức năng chính** theo đúng danh sách GDD (Hầm Đá gồm 40 tầng). [GDD]
- **Hệ thống nội thất** của nhà, cửa hàng, lớp học, thư viện, chuồng, trạm chế tạo, đài thiên văn. [GDD + MỚI]
- **4 mùa, 7 ngày/mùa, 28 ngày/năm**; giờ hoạt động, thời tiết, vòng sống NPC và động vật. [GDD]
- **12 NPC chính**, sinh vật hoang, vật nuôi, quái Quên, 5 Bóng Quên và trùm cuối. [GDD]
- Quy tắc **mỹ thuật môi trường, thiết kế level, tương tác, dữ liệu, asset, QA** có thể triển khai bằng Godot. [MỚI — ĐỀ XUẤT]

**Không bao gồm:** thay thế GDD bằng lore mới, thêm hệ thống cốt lõi mới, đổi giá vật phẩm, đổi tiến độ chương, đổi chỉ số đã ghi trong GDD.

### 0.3 Sáu bảng hình được dùng như thế nào

| Bảng minh họa | Tính chất | Hệ quả cho đặc tả thế giới |
|---|---|---|
| 1 — Tiêu đề / tải / tạo nhân vật | Toàn cảnh làng, núi xanh, hoa đào, gỗ, mặt trời mọc | Khóa ngôn ngữ phong cảnh nông thôn ấm áp; quy tắc cảnh nền parallax và nhận diện thế giới |
| 2 — Hội thoại / cửa hàng / mini-game | Phố nhỏ, mái tranh, cây hoa, hàng rào, NPC | Khóa phong cách kiến trúc dân dã, đường đi đủ rộng để hội thoại, cửa hàng có không gian giao dịch |
| 3 — Chế tạo / cài đặt | Cảnh làng lúc tối, đèn lồng, vật liệu gỗ–giấy | Định hướng nhà/xưởng ban đêm, lò rèn có ánh lửa, đồ gỗ có silhouette dễ đọc |
| 4 — Bách khoa / bản đồ / quan hệ | Bản đồ vẽ tay, vùng nước, rừng, núi, địa danh | Hình bản đồ thế giới là đồ họa sổ tay; tên địa danh trong hình là **tham khảo hình ảnh**, không thay thế tên trong GDD |
| 5 — Túi đồ / kỹ năng / nhiệm vụ | Tranh nông trại, NPC, vật phẩm 16×16 | Tính nhất quán đồ vật trong thế giới với icon, sprite cầm tay, biểu tượng nhiệm vụ |
| 6 — Gameplay / chiến đấu / câu cá | Nông trại, lối làng, ao sen, nhà mái tranh, HUD | Khóa bố cục top-down ¾ nhìn từ trên, tâm nhìn ưu tiên nhân vật, thế giới sống phía dưới HUD |

**Lưu ý art:** các bảng minh họa có độ chi tiết và chữ lớn nhằm giải thích thiết kế. Tài sản đưa vào game phải được **vẽ lại trên lưới pixel thực**; không cắt trực tiếp hình bảng UI thành tileset rồi thu nhỏ, vì sẽ vỡ tỉ lệ, mất kiểm soát va chạm và khó animation. [MỚI — ĐỀ XUẤT]

---

## 1. WORLD BIBLE — BỐI CẢNH, BẢN SẮC VÀ KÝ ỨC

### 1.1 Câu chuyện địa phương

[GDD] Làng Sao Mai nằm giữa năm ngọn đồi. Hàng trăm năm trước, cư dân dựng **Ngôi Sao Tri Thức** ở đài thiên văn. Khi ngôi sao vỡ thành năm **Mảnh Sao** — Số, Chữ, Ngữ, Vật, Ký — Màn Sương Quên khiến những tri thức và kỹ năng của làng dần bị phai nhạt. Quái Quên là biểu hiện vật chất của những ký ức bị xóa. Người chơi thừa hưởng **Nông Trại Mầm Xanh** và một cuốn **Sổ Tay Tri Thức** tự đầy lên nhờ khám phá.

[MỚI — ĐỀ XUẤT] Thể hiện truyền thuyết qua môi trường thay vì lời kể dài:

- Tranh tường và hoa văn ngôi sao năm cánh xuất hiện kín đáo tại trường, thư viện, mỏ, bến cảng và đài thiên văn; mỗi nơi thiếu một nét ký hiệu.
- Vùng an toàn mang dấu hiệu **tri thức được chăm sóc**: sách mở, bảng ghi chép, cây thẳng hàng, biển đường rõ chữ.
- Vùng bị Sương Quên chạm tới mang dấu hiệu **thông tin suy yếu**: biển mờ chữ, trang giấy bay, dấu chân lặp, đèn lạc nhịp, bản đồ rách góc.
- Sau khi người chơi lấy Mảnh Sao, môi trường cải thiện có chọn lọc: một biển được đọc lại, một cửa mở, NPC nhớ lại công thức, không biến thế giới thành phông nền hoàn toàn khác.

### 1.2 Ba lớp cảm xúc của hành trình

| Lớp | Nơi điển hình | Cảm giác | Nguyên tắc trình bày |
|---|---|---|---|
| **Mái nhà** | Nông trại, Đồng Cỏ, Phố Chợ | Có thể về, ấm, quen thuộc | Màu kem–nâu–xanh; đường thấy rõ; tiếng người và gia súc |
| **Làng học hỏi** | Quảng Trường, Trường, Thư Viện, Hồ | Tò mò, kết nối, sáng tạo | Bố cục dẫn mắt về bảng tin, sách, cầu, hiện vật; nhiều tương tác không chiến đấu |
| **Vùng ký ức thất lạc** | Rừng, Mỏ, Núi, hầm sách, khu boss | Huyền bí nhưng không kinh dị | Tương phản sáng/tối có kiểm soát; biểu tượng tri thức luôn tạo lối về |

### 1.3 Ngôn ngữ Việt trong thiết kế

[HÌNH] Ưu tiên mái tranh hoặc ngói đất nung, cổng gỗ, hàng rào tre/gỗ, hiên nhà, giếng, chậu hoa, đèn lồng, ruộng chia luống, đường đá–đất, ao sen, mây núi xanh phía xa. [MỚI — ĐỀ XUẤT] Thẩm mỹ là **làng quê Việt hư cấu**: ấm, có tính kể chuyện, không rập khuôn nguyên mẫu địa lý, không dùng biểu tượng văn hóa thiêng một cách tùy tiện.

**Bộ dấu hiệu thị giác chung:** năm cánh sao (tri thức), hình lá/mầm (trồng trọt), mái nhà chữ A (cộng đồng), đường nước cong (thư thái), giấy ngả kem (ký ức được lưu giữ). Mỗi khu vực chỉ dùng 1–2 biểu tượng làm chủ đạo để không quá dày đặc.

---

## 2. ĐỊA LÝ, KẾT NỐI VÙNG VÀ HƯỚNG KHÁM PHÁ

### 2.1 Đồ thị kết nối chính thức

[GDD] Giữ nguyên các vùng và trục kết nối đã mô tả ở GDD mục 5.1:

```text
                        [Núi Mây]
                            |
[Rừng Thì Thầm] — [Đồi Thư Viện] — [Hồ Gương & Sông Bạc]
        |                   |                   |
[Hầm Đá Thì Thầm]    [Quảng Trường] ─── [Bãi Biển Sóng Vàng]
                       /         \
              [Phố Chợ]      [Trường Ánh Dương]
                  |
           [Nông Trại Mầm Xanh]
                  |
           [Đồng Cỏ Cỏ Xanh]
```

*Bản đồ chữ là sơ đồ kết nối, không định nghĩa tọa độ tuyệt đối. GDD còn cho Nông Trại một lối tắt trực tiếp vào Rừng, mở sau chương 1. Vị trí kết nối Phố Chợ/Nông Trại và lối đi Quảng Trường/Bãi Biển sẽ phải được kiểm tra với sơ đồ gốc khi dựng `MapPortal`.*

### 2.2 Danh sách 11 map nền

| `map_id` | Tên chính thức [GDD] | Kích thước tile [GDD] | Vai trò / chủ đề | Trạng thái ban đầu |
|---|---|---:|---|---|
| `farm_main` | Nông Trại Mầm Xanh | 80×60 | Nhà, canh tác, nâng cấp | Mở |
| `ranch` | Đồng Cỏ Cỏ Xanh | 60×44 | Chăn nuôi, bãi cỏ | Mở vùng; cửa hàng sau Ch1 |
| `market_street` | Phố Chợ | 56×32 | Mua bán, chữa bệnh, nghề thủ công | Mở |
| `town_square` | Quảng Trường Sao Mai | 64×48 | Trung tâm xã hội, nhiệm vụ, lễ hội | Mở |
| `school_grounds` | Trường Ánh Dương | 48×36 | Toán, khoa học, hoạt động học | Mở sân; lớp sau Ch1 |
| `library_hill` | Đồi Thư Viện | 40×32 | Ngữ văn, ký ức, bảo tàng | Mở; hầm sách Ch3 |
| `whispering_forest` | Rừng Thì Thầm | 90×70 | Hái lượm, mối nguy, bí ẩn | Sau Ch1 |
| `stone_mine` | Hầm Đá Thì Thầm | 40 tầng × 40×30 | Khoáng sản, đố cơ khí, boss | Ch1 và cấp Cư Dân ≥3 |
| `mirror_lake` | Hồ Gương & Sông Bạc | 60×44 | Câu cá, nước, cầu | Mở |
| `golden_beach` | Bãi Biển Sóng Vàng | 70×40 | Biển, thủy triều, ngoại ngữ | Sau sửa cầu Hồ Gương |
| `cloud_mountain` | Núi Mây | 80×80 | Leo núi, sử–địa, đài thiên văn | Ch5 và cấp Cư Dân ≥8 |

### 2.3 Nguyên tắc định hướng và nhịp di chuyển [MỚI — ĐỀ XUẤT]

- Mỗi map có **một landmark cấp vùng** (nhà lớn, tháp, cây cổ thụ, thác, giếng, đỉnh núi) và **hai landmark cấp đường đi** (cầu, biển chỉ đường, cổng, cụm hoa khác màu).
- Trong vòng 3–6 giây kể từ khi vào cổng, người chơi phải nhận ra khu vực qua silhouette và âm nền, dù HUD bị ẩn.
- Các đường chính rộng tối thiểu **2 tile trống hữu dụng**; gần điểm NPC thường đứng, cổng ra vào và tương tác quan trọng nên ưu tiên 3 tile để tránh tắc nghẽn. Đây là **mục tiêu thiết kế level**, chưa phải thông số GDD.
- Cảnh nhiều chi tiết tập trung ở mép đường, không phủ vật trang trí lên điểm tương tác, ô câu cá, bậc thang hay nút cửa.
- Luồng trở về luôn có dấu hiệu: cổng gỗ chung, biển tên vùng, hoặc lối đá dẫn ra; không được tạo nhánh một chiều gây kẹt trước khi có bản đồ.
- Khám phá theo cấu trúc **trục an toàn → nhánh tài nguyên → bí mật có điều kiện**, thay vì một mê cung ngẫu nhiên cho tất cả vùng.

### 2.4 Cổng vùng và mở khóa [GDD + MỚI]

Mọi liên kết dùng `MapPortal` (`Area2D` layer `trigger`) với `target_map_id`, `target_spawn_id`, `unlock_conditions[]`. Thời gian tiếp tục chạy khi đổi map; fade-out 0,25 giây và fade-in 0,25 giây. [GDD]

[MỚI — ĐỀ XUẤT] Bổ sung `portal_id`, `return_portal_id`, `approach_facing`, `unlock_hint_key`, `camera_entry_mode`, `transition_sfx`, `enabled_weather_flags`, `safe_spawn_radius_tiles`. Với mỗi cổng phải có cặp spawn hai chiều và kiểm tra spawn không chồng vật thể. Cửa bị khóa cho đọc lời nhắc ngắn thay vì im lặng.

---

## 3. ART BIBLE — QUY CHUẨN MÔI TRƯỜNG PIXEL ART

### 3.1 Khung hình thực thi

| Thuộc tính | Quy tắc |
|---|---|
| Viewport & tỷ lệ | **320×180**, 16:9 [GDD/UI] |
| Grid thế giới | **16×16 px/tile** [GDD/UI] |
| Sprite người/NPC | **16×32 px**, gốc sắp chiều sâu ở chân [GDD] |
| Quái | Nhỏ 16×16, vừa 24×24, lớn 32×32, boss từ 48×48 [GDD] |
| Lọc ảnh | **NEAREST**, không mipmap, không để sprite lọt nửa pixel [GDD/UI] |
| Hiển thị | Scale nguyên khi có thể, không làm mờ pixel [GDD/UI] |
| Mặt nhìn | Top-down ¾ cách điệu: thấy mặt trước nhà, mép mái, nền đất và phía trên vật trang trí [HÌNH + MỚI] |
| Chiều sâu | Y-Sort thực thể; thân cây, mái nhà có lớp chồng và vùng mờ khi người chơi đi phía sau [GDD] |

### 3.2 Quy tắc màu môi trường [MỚI — ĐỀ XUẤT]

Không áp bảng màu UI lên môi trường một cách máy móc. Dùng UI làm *màu hòa hợp*: viền mực `#2B1B17`, giấy `#F4E4BC`, gỗ tối `#5A3A2A`, vàng nhấn `#F2C14E`, xanh lá `#6DB04A`. [UI]

| Vùng cảnh quan | Màu đề xuất | Tác dụng |
|---|---|---|
| Cỏ xuân sáng | `#8FCB72`, `#5FA65B` | Nền sống, dễ đọc đường |
| Cỏ đậm / rừng | `#4D8A5B`, `#315B49` | Tăng chiều sâu |
| Đất / luống | `#B07A4E`, `#785036` | Phân biệt đã cuốc/đã tưới |
| Đường đá | `#C9B48F`, `#9A917C` | Dẫn mắt, ít cạnh sắc |
| Mái ngói | `#C97859`, `#8E493E` | Hồn làng, landmark |
| Mái tranh | `#E4BC74`, `#A57C47` | Nông trại, xưởng, sạp |
| Nước hồ | `#67B8C8`, `#347C9C` | Mát, trong |
| Hoa đào | `#F5A0BE`, `#D977A1` | Dấu hiệu mùa Xuân |
| Ánh đèn | `#FFD27C`, `#E8A15A` | An toàn trong cảnh đêm |
| Sương Quên | `#9185B9`, `#555174` | Vùng ký ức bất thường |

Mỗi map cần một **palette môi trường ban ngày** và một bộ LUT/CanvasModulate theo pha giờ. Không vẽ riêng mọi object cho mọi giờ; chỉ vật thể phát sáng và trạng thái mùa cần sprite độc lập.

### 3.3 Kiến trúc, vật liệu và tỷ lệ [HÌNH + MỚI]

**Nhà dân:** mái tranh/ngói đỏ dốc; tường vôi kem hoặc ván gỗ; cửa 1–2 tile, hiên thấp, bậc đá; cửa sổ sáng khi đèn bật. **Công trình công cộng:** mái lớn hơn, cổng nhận diện bằng biểu tượng sách, trống trường, búa rèn, cây thuốc hoặc sao. **Cấu trúc nông trại:** rào 1 tile, cổng 2 tile, hàng luống thẳng, nhà kho thô mộc, giếng đá, máng nước.

[GDD] Kích thước ngoại thất mẫu: nhỏ 4×4 tile, vừa 6×5 tile, lớn 9×7 tile; dùng `BodySprite`, `RoofSprite`, `DoorPortal`, `CollisionPolygon2D`, `SignLabel`, `LightPoints` và một ô đứng trống trước cửa. [MỚI] Với kiến trúc đặc biệt lớn có thể ghép module phụ, nhưng cửa/điểm chân và va chạm vẫn theo chuẩn này.

### 3.4 Lớp đồ họa đề xuất

```text
WorldMap
├── GroundBase             # cỏ, đất, đá nền
├── GroundDetails          # cánh hoa rơi, sỏi, vết xe, chấm cỏ
├── Water                  # tile nước động, bờ
├── TerrainSolid           # mép vực, bờ cao, tường đá
├── BackDecoration         # bụi thấp, biển đặt phía sau nhân vật
├── BuildingBacks          # chân tường, hàng rào sau
├── YSortedWorld           # Player, NPC, animal, monster, furniture, trunks
├── BuildingFronts         # mái và phần che trước có xử lý alpha
├── CanopyOverlay          # tán cây, lá che, đèn cao
├── EnvironmentalFX       # bóng, nước, bụi, lá, mưa, tuyết
└── SpawnAndTriggerNodes   # portal, điểm NPC, vùng câu cá, tương tác
```

Đây là mẫu cấu trúc **mở rộng**, không thay đổi các layer vật lý đã có trong GDD.

### 3.5 Nguyên tắc bố cục cảnh [MỚI]

1. Một màn hình điển hình có **60% khoảng trống đọc được** (đường, nước, ruộng, sân), 25% cụm vật thể lớn và 15% chi tiết nhỏ; là mục tiêu thẩm mỹ, không phải luật cứng.
2. Trang trí hoa/đá dùng **cụm bất đối xứng** 2–5 object; tránh rải đồng đều tạo nhiễu.
3. Cầu, rìa vực, bậc thang, bến câu và cây cần chặt phải có silhouette tách khỏi nền từ màn hình scale 2×.
4. Ánh sáng trong bóng râm giảm bão hòa thay vì biến cả cảnh thành một mảng đen; hành động quan trọng không phụ thuộc chỉ vào sắc màu.
5. Các đối tượng xa như núi, nhà nhỏ phía chân trời trong bảng minh họa chỉ đưa vào **background/parallax**; nhân vật không thể đi tới nếu chưa có map thật.

---

## 4. QUY TẮC THẾ GIỚI CHẠY THEO THỜI GIAN

### 4.1 Đồng hồ, mùa và ngủ [GDD]

- 1 ngày game = 1.440 phút game = **240 phút thực**; 1 giờ game = 10 phút thực.
- Ngày chơi bắt đầu **06:00**, ngủ muộn nhất **02:00 hôm sau**; quãng 02:00–06:00 được bỏ qua khi ngủ.
- 1 mùa 7 ngày, năm 4 mùa: Xuân → Hạ → Thu → Đông; Chủ Nhật/ngày 7 của mỗi mùa là ngày lễ.
- Thời gian tạm dừng khi mở menu, hội thoại, cutscene và màn học/đố; **vẫn chạy** khi ở nhà, câu cá, chiến đấu, đi qua cổng map.
- HUD giờ hiển thị theo bước 10 phút game, chuyển pha ánh sáng nội suy liên tục.

### 4.2 Bốn mùa tác động đến *cả* thế giới [GDD + MỚI]

| Mùa | Phong cảnh & thời tiết [GDD] | Thay đổi môi trường cần vẽ [MỚI] | Tương tác cần test |
|---|---|---|---|
| **Xuân** | Cỏ xanh non, hoa hồng đào, suối đầy; nắng/mưa phùn | Cành đào 2–3 biến thể, vũng nước mỏng, cánh hoa bay nhẹ, mái rêu sáng | Mưa tưới đất, xuất hiện hoa Xuân và cây Xuân |
| **Hạ** | Lá rậm, nắng vàng, hồ lấp lánh, nóng/giông | Tán cây phủ rộng, sen nở, đom đóm đêm, bóng cây rõ | Nắng gắt làm đất khô; câu cá/động vật đổi nhịp |
| **Thu** | Lá cam đỏ, nấm, mưa, gió | Lá rụng dưới gốc, đường đất có lá, giàn quả vàng; luống thu hoạch | Hái hạt dẻ, nấm; Hội Gặt và Trăng Tròn |
| **Đông** | Tuyết, cành trơ, băng và bão tuyết | Rìa mái có tuyết, bậc đi trơn, tuyết trên cọc gỗ; cửa sổ vàng nổi bật | Hồ đóng băng; áo ấm; cây trái mùa héo |

[MỚI] **Thứ tự layer thay mùa:** `seasonal_ground_tiles → object_variants → snow/wetness overlay → light_phase → weather particles → special effects → interactable indicators`. Đúng nguyên tắc `MapStateData` trong GDD.

### 4.3 Thời tiết, điều kiện đặc biệt [GDD]

Lưu/đọc thời tiết qua `WeatherSystem` có seed `hash(world_seed, year, season, day)`, dự báo ngày mai đúng 90%, ba ngày đầu và lễ hội nắng, không có hai ngày thời tiết nặng liên tiếp; một ngày tối đa hai đoạn chuyển thời tiết. Các điều kiện nổi bật: **Giông sét, Sương Quên, Nóng gay gắt, Bão tuyết, Gió lớn mùa Thu, Mưa sao băng, Trăng Tròn ngày 4, Cầu vồng, Lễ hội ngày 7**.

[MỚI] Mỗi thời tiết cần **bốn lớp phản hồi**: (a) hình ảnh, (b) âm thanh, (c) NPC/sinh vật, (d) gameplay. Ví dụ trời mưa: mái nhỏ giọt, âm mưa và ếch, NPC che ô/chuyển lịch, đất tự ướt và cá cắn câu nhiều hơn. Không chỉ thay particle.

### 4.4 Vòng sống môi trường [MỚI — ĐỀ XUẤT]

- **06:00:** chạy cập nhật nông trại, spawn tài nguyên hái lượm, reset quái theo GDD, tính động vật, làm mới nhiệm vụ và bảng tin.
- **Theo giờ game:** chuyển pha ánh sáng, mở/đóng cửa, đổi NPC theo lịch, phát đèn, cập nhật thủy triều và môi trường.
- **Khi quay lại map:** mọi vật thể có `persistent_id` giữ trạng thái, nhưng đối tượng trang trí chỉ cần nội suy dựa trên `MapStateData`.
- **Mỗi đêm sau lưu:** dọn vật phẩm rơi hết ngày theo GDD, lưu biến đổi đất/đồ đặt/hộp chứa; không reset lén vật phẩm người chơi sở hữu.

---

## 5. HỒ SƠ CHI TIẾT 11 KHU VỰC

> Các **tên, kích thước, mở khóa, quy luật đã có** giữ nguyên từ GDD. Những bố cục không gian, cách bài trí và điểm quay hình dưới đây là **[MỚI — ĐỀ XUẤT]** để họa sĩ/level designer có thể dựng map.

### W01 — NÔNG TRẠI MẦM XANH (`farm_main`, 80×60)

**Vai trò [GDD]:** Nhà chính người chơi, 24×16 ô đất canh tác, giếng, hòm gửi hàng, silo, chuồng gà/bò, nhà kính, bãi đá/gốc cây cần dọn; không có quái ban ngày, chỉ vài quái nhẹ vào đêm Trăng Tròn. Nằm trên tuyến đường tới Phố Chợ, Đồng Cỏ và lối tắt Rừng sau Ch1.

**Bố cục [MỚI]:**

- **Tây-bắc:** nhà chính và khoảng sân đón người chơi, hòm thư, chậu hoa, ghế gỗ; góc máy đầu trò nhìn được mái nhà, cửa, thùng đồ và khoảng đất trống.
- **Giữa:** cụm đất canh tác 24×16 ô, chia vùng thị giác bằng bờ đất/lối nhỏ; đặt giếng trong tầm nhìn từ ruộng để việc tưới không bắt người chơi đi vòng khó chịu.
- **Đông:** không gian xây chuồng, máng và hàng rào; để đủ khoảng trống nâng cấp hoặc tự sắp xếp theo GDD.
- **Nam:** bãi cỏ và đường ra Đồng Cỏ; có bảng chỉ hướng dễ nhận diện.
- **Bắc:** dải cây tự nhiên, gốc lớn/đá làm mục tiêu dọn đất; lối tắt Rừng có biển gỗ cũ, mở sau Ch1.

**Landmark:** nhà mái ngói/khung gỗ có hiên, giếng tròn, ruộng thành dải thẳng và một cây đào nở hoa gần cổng (hoa biến thể theo mùa). **Màu:** xanh lá–đất nâu–hồng đào, tương phản vàng kem. **Âm:** chim, gà, ve mùa Hạ, mưa trên mái, tiếng cuốc. [HÌNH + MỚI]

**Tương tác và vòng chơi:** cuốc → gieo → tưới → chăm → thu hoạch → bán; đặt hàng rào và máy; chữa đất, chăn nuôi, nấu, học ở bàn; ngủ, lưu. Không để cây trang trí tự nhiên chiếm các ô dự kiến mở rộng nhà hoặc chặn lối tới hòm gửi hàng. [GDD + MỚI]

**Thay đổi theo chương:** Ch0 chỉ một phần đất sạch; Ch1 có nhánh rừng; Ch4 có nhà kính mở; từ cấp 12 có điều kiện xây nhà kính theo GDD. **Chú ý [CẦN CHỐT]:** GDD ghi nhà kính mở sau chương 4 và cấp Cư Dân 12; UI phải hiển thị rõ nếu cần đồng thời cả hai.

**Cảnh mẫu / screenshot mục tiêu:** bình minh với nhân vật tưới hàng rau, nhà mái tranh/ngói bên trái, lối làng hướng ra trung tâm, ao sen nhỏ/đường đá ở rìa cảnh; HUD gọn như bảng hình 6, nhưng đồ vật chiếm kích thước tile thật. [HÌNH]

### W02 — ĐỒNG CỎ CỎ XANH (`ranch`, 60×44)

**Vai trò [GDD]:** trại cô Mai, bãi chăn thả, chuồng mẫu, bảng giá động vật. Vùng đi vào từ đầu, dịch vụ mua vật nuôi mở sau Ch1. Cỏ mọc lại 1 ô/ngày trong Xuân–Hạ–Thu, nhanh gấp đôi khi mưa, chết dần vào Đông.

**Bố cục [MỚI]:** lối vào phía nông trại → nhà cô Mai và cổng bán vật nuôi → đồng cỏ chính mở rộng → ao nhỏ dành cho vịt và cụm bóng cây; chuồng mẫu nằm ở cạnh trên để người chơi nhìn động vật từ ngoài rào. Có một khu tương tác **giáo trình nuôi vật** (biển hỏi về ăn, nước, nhiệt độ) nhưng không ép kiểm tra để mua vật.

**Landmark:** hàng rào liên tục, vòng cỏ vàng, cối xay gió nhỏ hoặc mái che thức ăn **chỉ để trang trí nếu chưa có công năng**. **Cư dân:** cô Mai; động vật gà, vịt, bò/dê/cừu theo tiến độ. **Âm:** tiếng chuông nhỏ, bước chân trên cỏ, gió, gia súc. **Thay mùa:** rực xanh Xuân/Hạ, cỏ vàng Thu, mái chuồng và hàng rào phủ tuyết Đông. **Rủi ro:** đường đi không được để động vật gây bít cổng; chúng có vùng đi riêng.

### W03 — PHỐ CHỢ (`market_street`, 56×32)

**Vai trò [GDD]:** Tiệm tạp hóa của **Dì Năm**, Lò rèn **Chú Ba**, Phòng khám **Bác sĩ Minh**, Quán Hương Lúa **Chị Vy**, các sạp ngoài trời. Tiệm tạp hóa 09:00–19:00, nghỉ Chủ Nhật; lò rèn 10:00–17:00, nghỉ Thứ Bảy; phòng khám 08:00–16:00 (cấp cứu 24/7); Quán Hương Lúa 11:00–22:00. Ngày lễ đóng cửa thường. [GDD]

**Bố cục [MỚI]:** đường đất/đá dài theo trục ngang; đầu phố là biển gỗ tới Quảng Trường, phía còn lại dẫn về Nông Trại. Tòa nhà đặt so le để mái không che biển hiệu. Tiệm hạt giống gần hướng nông trại; lò rèn có ống khói và sân đặt phôi; quán ăn có hiên, bàn ngoài trời; phòng khám có bảng cây thuốc. Các sạp mở thành một dải vào ngày chợ phiên.

**Landmark:** dãy mái ngói đất, dây vải phơi, chậu hoa, đèn lồng đỏ-vàng, luồng khói mềm từ lò rèn. **Âm:** tiếng rao nhỏ, tiếng bước chân, búa gõ, chảo xèo, nhạc jazz nhẹ theo GDD. **Hệ thống thế giới:** lịch mở cửa làm thay đổi **cửa sổ/biển quầy/đám đông**; không chỉ khóa nút mua. Các sạp đóng khi bão tuyết. **Gắn tri thức Số:** bảng giá và nhiệm vụ tính tiền thối. [GDD + MỚI]

**Lưu ý:** hình 2 ghi “Cửa Hàng Bà Tư”; theo GDD **Bà Tư là thủ thư**. Không đổi tên NPC chủ tiệm nếu chưa duyệt mục [CẦN CHỐT].

### W04 — QUẢNG TRƯỜNG SAO MAI (`town_square`, 64×48)

**Vai trò [GDD]:** tâm điểm làng, đài phun nước, bảng nhiệm vụ ngày, bảng dự báo thời tiết, ghế đá, sân khấu ngày lễ. NPC thường hẹn nhau ở đây, đài phun đóng băng mùa Đông.

**Bố cục [MỚI]:** trục đi bộ hình vòng quanh đài phun; **bảng nhiệm vụ** đặt ở một cạnh của vòng, dễ tiếp cận dù người chơi đến từ Phố Chợ, Trường hoặc Đồi. Khu lễ hội chừa sân trống và điểm dựng gian hàng bằng `event_overlay`. Rìa quảng trường có bồn hoa bốn mùa, cột đèn, ghế cho NPC ngồi, đường lát đá định hướng 4 cổng.

**Landmark:** bồn nước và phù điêu ngôi sao (phiên bản dân gian), sân khấu có cờ giấy khi lễ hội. **Âm:** accordion, nước róc rách, tiếng chợ xa, người chuyện trò. **Tương tác:** nhận 3 nhiệm vụ Hàng ngày mới lúc 06:00, kiểm tra dự báo, gặp NPC, nhận lời mời dự lễ. **Thời tiết:** khi mưa, NPC trú hiên; khi tuyết, bồn nước đóng băng; ngày hội phải có biến thể bề mặt/ánh sáng gian hàng.

**Cảnh kiểm thử:** từ bất kỳ cổng nào phải nhìn được một phần đài phun hoặc đường dẫn về nó trong một màn hình; không để UI bảng nhiệm vụ che đầu NPC chính.

### W05 — TRƯỜNG ÁNH DƯƠNG (`school_grounds`, 48×36)

**Vai trò [GDD]:** sân trường, lớp học, phòng thí nghiệm, vườn thực nghiệm, sân bóng, phòng hiệu trưởng. Giờ học 08:00–10:00 và 14:00–16:00 trong ngày thường; cuối tuần lớp đóng, sân mở. Lớp mở sau Ch1.

**Bố cục [MỚI]:** ngoại thất chữ U với sân chung trung tâm, bảng thông báo ở cổng; dãy lớp ở một cánh, phòng thí nghiệm ở cánh còn lại, vườn thực nghiệm phía sau có lối lát gạch để trẻ đi giữa các ô trồng. Cây lớn ở sân là chỗ giao nhiệm vụ với **Cô Lan** và gặp **Bé Na**. Nội thất lớp có 12 bàn học theo GDD, bảng đen ở phía trên, lối đi giữa tối thiểu 2 tile.

**Landmark:** cổng trường vòm gỗ, biển nắng/sách và chuông trường. **Âm:** xylophone, tiếng chim, tiếng bút phấn, bước chân học sinh; trống/chuông giờ học làm âm báo nhỏ. **Tri thức:** Số tại bàn/bảng, Vật tại bàn thí nghiệm, Ký tại quả địa cầu/bản đồ. **Cốt truyện:** Ch2 tạo lớp “trường bị Sương Quên” với bảng bị mờ, cổng hầm trường dẫn tới Bóng Số Không, sau thắng phục hồi chữ/số.

**Nguyên tắc học ẩn trong thế giới:** công thức thật được giải bằng dụng cụ phòng thí nghiệm, ô đất minh họa diện tích, bản đồ xã hội; không mở màn thi chỉ để khóa cổng phụ. [GDD + MỚI]

### W06 — ĐỒI THƯ VIỆN (`library_hill`, 40×32)

**Vai trò [GDD]:** Thư viện cổ hai tầng, bảo tàng nhỏ, hầm sách khóa tới Ch3, vườn đọc sách; Thư viện 09:00–18:00, nghỉ thứ Hai. **Bà Tư** là thủ thư, giao nhiệm vụ Chữ, Phụ và Ẩn.

**Bố cục [MỚI]:** lối lên đồi là đường đá cong chữ S qua vườn đọc, có băng ghế nhìn xuống làng. Thư viện nằm ở phần cao nhất dễ nhận thấy mái ngói cũ; bảo tàng ở một cánh ngắn sát lối đi; cổng xuống hầm sách được đặt bên trong để lời kể dẫn dắt hợp lý. Có ít nhất hai nơi “ngồi đọc” không che đường NPC, một góc bóng cây để kích hoạt nhiệm vụ ẩn ngày mưa lúc 16:00 (từ GDD).

**Landmark:** cây cổ thụ lá vàng hoặc xanh rêu tùy mùa, mái thư viện với huy hiệu cuốn sách/sao, đèn dầu ấm; giấy bay một vài chỗ khi có Sương Quên. **Âm:** piano/cello, gió qua lá, tiếng lật trang và chuông nhỏ. **Tương tác:** mượn/trả sách, máy tra mục lục, trưng bày Bách khoa, cầu thang xoắn, hầm sách và Chìa Mực. **Cốt truyện:** Ch3 làm mờ chữ trên biển/kệ trong một trạng thái có kiểm soát, boss Gã Gạch Xóa và phục hồi dần các dòng chữ sau khi thắng.

**Quy tắc:** đọc sách là hoạt động yên tĩnh; không sinh quái trên sân thư viện trong trạng thái bình thường. Quái Dơi Giấy/Sách Hộ Pháp chỉ ở **hầm sách** theo GDD.

### W07 — RỪNG THÌ THẦM (`whispering_forest`, 90×70)

**Vai trò [GDD]:** hái lượm, chặt cây, quái nhẹ, sói đêm, gốc cổ thụ, trại thợ rừng, hang sói; mở sau Ch1. Sương Quên làm rừng nguy hiểm hơn. Lối tắt tới nông trại sau Ch1.

**Bố cục [MỚI]:**

- **Vành đai an toàn:** cổng rừng, bảng kiểm tra thời tiết, cây sồi/thông thưa, nhiều nấm/hái lượm dễ nhìn, đường về luôn sáng hơn.
- **Lối mòn giữa:** phân nhánh ôm hồ cạn và khúc gỗ đổ; có vòng đi bộ cho người thích khám phá không đánh quái.
- **Khoảng trống nấm:** nguồn thực vật đổi theo mùa, địa điểm gặp Nấm Độc lúc sương/Thu.
- **Khu cổ thụ:** thân lớn, rễ tạo lối cong, một điểm bí mật điều kiện tri thức, nhưng không đặt nhầm trên đường bắt buộc.
- **Vành đai đêm:** hang sói ở mép ngoài; nhiều vùng ẩn núp và đèn đặt được; vùng boss/khám phá chỉ vào khi người chơi chủ động.

**Nhận diện:** xanh rêu–lục thẫm ban ngày; tím lam ban đêm; tia sáng xuyên tán, rêu trên đá, nấm nhỏ sáng nhẹ. **Âm:** sáo thì thầm, côn trùng, cú; đêm thêm bass trầm và tiếng sói xa. **Sinh vật:** thỏ, chim sẻ, bướm, hươu, cú; Slime Mực, Nấm Độc, Sói Bóng Đêm, Ma Sương theo điều kiện đã có trong GDD.

**Thiết kế công bằng:** đòn quái luôn telegraph; vị trí spawn tối thiểu 12 ô ngoài tầm nhìn theo GDD; cây cao có vùng mờ khi che nhân vật; người chơi không bị “úp sọt” ở sát portal. **Sương Quên:** fog giảm tầm nhìn nhưng đèn lồng, biển hiệu và đường gỗ vẫn tạo hệ thống dẫn đường. **Thu thập:** gỗ, nấm, hoa Nguyệt, quả rừng, vật phẩm cốt truyện.

### W08 — HẦM ĐÁ THÌ THẦM (`stone_mine`, 40 tầng × 40×30)

**Vai trò [GDD]:** 40 tầng sinh theo seed ngày, sảnh hầm cố định với thang máy và lều nghỉ; hầm không phụ thuộc thời tiết. Các boss: tầng 10 **Slime Mực Mẹ**, 20 **Chúa Dơi Giấy**, 30 **Golem Công Thức** (Bóng Quên Mảnh Vật), 40 **Hầm Vương**. Mở Ch1 khi cấp Cư Dân ≥3.

**Bố cục [MỚI]:** sảnh hầm là “nút an toàn” rộng có biển tầng, quầy thiết bị và ghế nghỉ. Mỗi tầng chiến đấu cần có: ô vào an toàn, đường chính tới lối xuống, 1–3 nhánh tài nguyên, chỗ đặt khoáng, rương/biến thể phòng, lối thoát hợp lệ. **Không bắt buộc người chơi tiêu diệt tất cả quái** để xuống, trừ các trận khóa rõ ràng do thiết kế chương/boss.

**Ngôn ngữ tầng [MỚI]:**

| Tầng | Quần thể và màu | Cơ chế / nhịp |
|---|---|---|
| 1–10 | Đá nâu/xám ẩm, đồng, gel mực; ánh đèn ấm | Hướng dẫn đập đá, đường nhỏ, Slime/Sâu Đá/Dơi Giấy; boss 10 |
| 11–20 | Đá xám lam, tơ nhện, kệ gỗ hỏng | Nhánh đường phức tạp, Nhện Hang/Nấm Độc, cầu gỗ; boss 20 |
| 21–30 | Vách đá đậm, tinh thể sáng, máy móc cổ | Kênh tri thức Vật, mạch điện/cơ cấu, Golem nhỏ; boss 30 |
| 31–40 | Tinh thể tím–xanh, sương mờ, rãnh sâu | Tăng mật độ tinh anh, nhiều nhánh cần chuẩn bị; boss 40 |

**Nguyên tắc tạo tầng:** phân vùng không gian chạy được trước khi trang trí, đặt portal vào/ra trước, sau đó phòng thưởng/quái/tài nguyên theo seed; không có đồ rơi hoặc rương nằm ngoài lưới có thể tới. Trạng thái khai thác giữ trong phiên/ngày theo GDD; tầng sinh lại mỗi ngày. Tránh dùng ánh sáng lung linh gây khó đọc hitbox.

**Tương tác tri thức:** cân thăng bằng, mạch điện, trật tự công thức, ký hiệu khoáng. Với đố Chính tuyến thất bại ba lần, cơ chế hỗ trợ Lão Quang cho qua 1 sao vẫn áp dụng [GDD]. **Âm:** giọt nước, lửa nhỏ, va chạm kim loại, dội bước chân; nhạc synth trầm nhẹ, tránh làm game trở thành kinh dị.

### W09 — HỒ GƯƠNG & SÔNG BẠC (`mirror_lake`, 60×44)

**Vai trò [GDD]:** bến câu, cầu gỗ, nhà thuyền, thác nhỏ, bãi sậy; mặt hồ đóng băng toàn bộ vào Đông, đom đóm đêm Hạ, mưa lớn làm nước lên/cầu ngập một ngày. Hồ có sen mùa Hạ và cá theo lịch; đường tới Bãi Biển liên quan nhiệm vụ sửa cầu.

**Bố cục [MỚI]:** hồ là hình khối xanh lớn ở trung tâm; một đường đi bộ ôm bờ, ba vị trí câu với silhouette khác nhau (cầu gỗ, bãi sậy, chân thác), nhà thuyền ở cạnh lối chính. Sông chảy tới thác và nối biên map; cầu nằm trên tuyến di chuyển quan trọng, khi bị ngập phải có chỉ báo và phương án đi/đợi hợp lý chứ không làm người chơi mắc kẹt ở bên sai bờ.

**Landmark:** cầu gỗ, bụi sen, bến câu có ghế gỗ, thác phản chiếu ánh trời. **Âm:** đàn hạc, nước, ếch, vịt trời; đêm Hạ thêm đom đóm. **Tương tác:** lấy nước cho bình tưới, câu cá, bẫy, rửa mặt xóa Mù, bơi sau Ch4 có Áo Phao, đi bộ trên băng mùa Đông, câu băng.

**Mỹ thuật nước [GDD + MỚI]:** tile hoạt hình 4 frame ×0,4 giây; gợn sáng hạn chế tương phản, đường bờ autotile rõ. Mưa tạo gợn tròn; mùa Đông đóng băng thành mặt phẳng có khe băng và cảnh báo khu đi trơn. **Khu câu:** `FishingZone` độc lập theo bến, đồng bộ mùa/giờ/thời tiết.

### W10 — BÃI BIỂN SÓNG VÀNG (`golden_beach`, 70×40)

**Vai trò [GDD]:** cầu cảng, nhà ngư dân, hang đá thủy triều, bãi san hô và thuyền trưởng **Marco**; mở sau nhiệm vụ sửa cầu ở Hồ Gương. Thủy triều chu kỳ 6 giờ game; khi thấp lộ ao nước đọng, vỏ sò, sao biển; giông bão có sóng cao cấm tới mép nước.

**Bố cục [MỚI]:** đường tới bãi đi qua dải cát rộng; vùng nhà ngư dân/quầy câu ở trái, cầu cảng và thuyền ở phải; khu ao nước đọng và hang thủy triều chỉ lộ/lối đi rõ khi nước rút. Nhìn thấy đèn hải đăng nhỏ từ xa **nếu dùng như landmark trang trí**, không biến thành công trình mới có chức năng trừ khi được duyệt.

**Landmark:** đường chân trời, nước ngọc lam, thuyền buồm/bến cảng, mái chòi cọ hoặc ngói, đèn vàng lúc đêm. **Âm:** ukulele, sóng, hải âu, chuông cảng. **Động vật:** cua, hải âu, sao biển, rùa biển hiếm. **Quái:** Cua Đá lúc triều thấp; Ma Sương ban đêm; trận Thủy Thủ Câm trên tàu theo Ch4. **Học Ngữ:** giao tiếp với Marco, biển chỉ dẫn song ngữ, phân loại đồ trao đổi.

**Quy tắc thời gian:** mọi `tide_state` phải là kết quả từ `GameClock`; không dùng timer thật 6 giờ. Cảnh bờ nước phải luôn có **cảnh báo hình học + hiệu ứng sóng** khi bão ngăn tiếp cận. Trẻ hóa cảnh bằng đèn nước lễ Hội Biển Đêm, không tạo điểm chói gây che thanh câu.

### W11 — NÚI MÂY (`cloud_mountain`, 80×80)

**Vai trò [GDD]:** địa hình lên cao 0–3, trạm dừng, thác nước, vách đá, đài thiên văn; tuyết quanh năm ở cao độ từ 2, sương sáng sớm; mở ở Ch5 và cấp Cư Dân ≥8. Đỉnh núi chứa nhiệm vụ thiên văn và Bóng Quên **Hồn Ký Ức**, đồng thời nơi đặt năm Mảnh Sao và đối mặt **Kẻ Xóa Chữ**.

**Bố cục [MỚI]:**

1. **Chân núi (cao độ 0):** đường đá, cây thông, lều nghỉ, cảnh nhìn lại làng.
2. **Sườn núi (cao độ 1):** đường zig-zag, cầu gỗ nhỏ và bậc đá; điểm mở khóa Móc leo sau yêu cầu kỹ năng.
3. **Vành tuyết (cao độ 2):** băng, gió, mái che hiếm, quái Linh Băng và nguồn tinh băng; trạm nghỉ có đèn.
4. **Đỉnh thiên văn (cao độ 3):** khoảng sân rộng, đường nét sao trên đá và Đài Thiên Văn; tầm nhìn hướng núi/hồ, ít cây để bầu trời là chủ đề chính.

**Landmark:** cột đá đánh dấu cao độ, thác, cầu treo, mái đài thiên văn hình sao. **Âm:** dây kéo dài, gió, tiếng băng, chuông xa; khi trời quang có motif Ngôi Sao Tri Thức. **Tương tác:** leo vách khi có Móc leo và Khai thác cấp 5, nhặt Hoa Nhung Tuyết, quan sát sao khi trời quang 19:00–02:00, giải mê cung la bàn và ký ức, nghỉ tại trạm.

**Khả năng đọc:** đường lên tầng phải liên tục, đoạn không có tay vịn dùng bóng chân vách rõ, không để background giả đánh lừa là có lối đi. **Cốt truyện:** Ch6 mở các mảnh ký ức dọc đường; Ch7 đài thiên văn chuyển sang `event_overlay` nghi lễ, nhưng vẫn giữ lối đi từ cổng tới bàn tinh tú. Không bắt buộc đêm nào cũng đối đầu boss.

---

## 6. MẠNG NỘI THẤT, CÔNG TRÌNH VÀ ĐỒ VẬT TƯƠNG TÁC

### 6.1 Nguyên tắc nội thất [GDD + MỚI]

[GDD] Nội thất dùng các lớp `Floor`, `Wall`, `Furniture_Back`, `Entities` (Y-sort), `Furniture_Front`, `Light`, có `SpawnPoint_FromOutside`, `AmbienceBus`, các `InteractableSlot`; cửa sổ đổi ánh sáng theo giờ, trong nhà nghe tiếng mưa/gió vọng mờ. [MỚI] Mỗi nội thất xác định **đường từ cửa → điểm phục vụ chính → lối quay lại**; ở khung nhìn 320×180 phải nhìn thấy hoặc suy ra được nơi cần tới ngay sau khi vào.

| Nội thất | Điểm nhìn đầu | Vật phải có [GDD] | Vật/chi tiết thêm [MỚI] | Quy tắc đặc biệt |
|---|---|---|---|---|
| Nhà chính | Giường, rương, bàn nhỏ | Giường, rương, bếp theo cấp, bàn chế tạo, tủ đồ, bàn học, TV, lò sưởi | Cửa sổ nhìn ra luống, thảm vải, đèn bàn | Nâng cấp 3 bậc; đồ đặt cá nhân lưu theo `persistent_id` |
| Tiệm Dì Năm | Quầy ngay cạnh lối vào | Quầy thu ngân, kệ hạt mùa, bảng giá, thùng đặt hàng | Sọt rau, thùng gỗ, sổ bán hàng | Mở Shop hai cột; nghỉ Chủ Nhật |
| Lò rèn Chú Ba | Lò nung và đe nhìn thấy | Lò nung, đe, giá vũ khí, bàn mài | Than hồng, quặng bày từng bậc | Nâng công cụ mất 2 ngày game |
| Phòng khám | Quầy tiếp đón, giường bệnh | Giường bệnh, tủ thuốc, bảng cơ thể | Chậu thuốc, kệ khăn sạch | Cấp cứu mở 24/7 có phí |
| Quán Hương Lúa | Quầy và bàn ăn | Quầy, bàn, thực đơn, bảng sự kiện | Bếp lửa, nồi cơm, bàn góc cửa sổ | Có NPC ngồi theo lịch, mở tới 22:00 |
| Lớp học | Bảng đen ở đầu, 12 bàn | Bàn học, bảng, bàn Cô Lan, tủ sách, chuông | Bài tập trên bàn, tranh thiên nhiên | Chỉ phiên học theo giờ lớp |
| Phòng thí nghiệm | Bàn dụng cụ và bảng sơ đồ | Bàn thí nghiệm, bản đồ/quả địa cầu | Lọ, dây, bóng đèn giả lập | Đố Vật dùng minh họa rõ, không dựa màu |
| Thư viện cổ tầng 1 | Quầy Bà Tư và kệ sách | Kệ sách, bàn thủ thư, máy mục lục | Trần gỗ, đèn đọc, bàn học nhóm | Thứ Hai đóng cửa |
| Thư viện tầng 2 | Kệ sách cổ, cầu thang | Cầu thang xoắn, sách cổ | Bản đồ sao, kính đọc, đồng hồ | Chữ/ký ức theo nhiệm vụ |
| Hầm sách | Lối tối, biểu tượng Chìa Mực | Cửa khóa, tủ kính liên quan truyện | Sàn chữ rơi, kệ xiên, đèn mờ | Ch3, quái Dơi Giấy/Sách Hộ Pháp |
| Chuồng gà/bò | Lối giữa hai dãy | Máng ăn, nước, ổ trứng/điểm vắt, lò sưởi, bảng tin | Thùng rơm, cửa thông gió | Vật nuôi cần tiếp cận từ 2 phía |
| Nhà kính | Luống và van tưới | Luống trồng quanh năm, tưới tự động Ch4 | Kính hơi sương, chậu ươm | Không bị thời tiết ngoài trời |
| Đài thiên văn | Kính thiên văn và Bàn Tinh Tú | Kính, bàn đặt Mảnh Sao, Trụ Ngôi Sao | Đèn sao, tranh chòm sao | Hoạt động 19:00–02:00; nghi lễ cuối |

**Kích thước nội thất:** GDD chưa chốt từng scene. [MỚI — ĐỀ XUẤT] Khởi đầu bằng module 16×12, 20×14 hoặc 24×16 tile tùy công trình; dùng kiểm tra khả năng đọc và di chuyển để chốt cuối, **không xem đây là kích thước đã phê duyệt**.

### 6.2 Luồng tương tác thống nhất [GDD]

`InteractionDetector` kích thước 20×20 hướng về trước; ưu tiên NPC → Station → Rương → Trang trí; phát hiện đối tượng, viền sáng, icon `E`, kiểm điều kiện, hoạt ảnh/SFX, cập nhật thế giới, phát EventBus và lưu nếu có `persistent_id`.

[MỚI] Thiết kế nội thất theo **luồng vật lý** này: icon không được hiện xuyên tường; cự ly từ cửa đến quầy phải đủ ngắn; NPC không đứng chặn máy/cửa; mỗi trạm có điểm đứng tương tác bên cạnh; đồ trang trí có collider riêng hoặc không collider nhất quán, không để tủ cao vừa che nhân vật vừa chặn cửa.

### 6.3 Trạng thái dựng công trình [MỚI — ĐỀ XUẤT]

Mọi công trình có tối thiểu: `closed` (đèn/tấm biển hợp lý), `open` (NPC/âm thanh/đồ tương tác hoạt động), `festival` (cửa tiệm thường đóng hoặc chuyển cảnh), `night_lit`, và `snowy/rainy` ở ngoại thất. Những công trình gắn chương có thêm `locked_story` và `restored_story` nhưng chỉ khi GDD yêu cầu.

---

## 7. VĂN HÓA ĐỜI SỐNG VÀ NHỊP SINH HOẠT NPC

### 7.1 Mười hai NPC chính [GDD]

| NPC | Nghề / nơi làm | Vai trò trong thế giới | Dấu hiệu thị giác [MỚI] | Hành vi quan sát được [MỚI] |
|---|---|---|---|---|
| Cô Lan | Giáo viên, Trường Ánh Dương | Số, chính tuyến lớp học | Áo màu sáng, sách/bút | Đứng bảng, ra vườn thực nghiệm, trò chuyện cùng Bé Na |
| Bà Tư | Thủ thư, Đồi Thư Viện | Chữ, sách cổ, nhiệm vụ ẩn | Tóc bạc búi, áo tím/kem | Sắp sách, đi vườn đọc, tra mục lục |
| Chú Ba | Thợ rèn, Phố Chợ | Nâng công cụ/vũ khí | Tạp dề nâu, búa | Đập đe, nung, nghỉ hiên khi đóng cửa |
| Dì Năm | Tiệm tạp hóa, Phố Chợ | Giống, vật dụng, toán mua bán | Khăn quàng, giỏ hàng | Sắp kệ, cân hàng, khóa cửa Chủ Nhật |
| Bác sĩ Minh | Phòng khám | Chữa bệnh, khoa học cơ thể | Túi thuốc, áo sáng | Kiểm tra giường, đọc thảo dược |
| Ông Sáu | Hồ / Bãi Biển | Ngư nghiệp, câu cá | Nón rộng, cần câu | Câu theo giờ, kiểm bến, trò chuyện ngư dân |
| Cô Mai | Đồng Cỏ | Chăn nuôi, hướng dẫn | Mũ vải/giỏ cỏ | Cho ăn, mở cổng chuồng, vuốt ve động vật |
| Lão Quang | Đài thiên văn | Truyện sao, Vật/Ký, hỗ trợ đố | Áo choàng đơn giản, cuộn bản đồ | Quan sát bầu trời, ghi sổ, nghỉ ở đài |
| Bé Na | Trường / Quảng Trường | Nhiệm vụ học sinh và quan hệ | Cặp sách nhỏ, hoa cài | Tới lớp, chơi sân, hỏi bài người chơi |
| Anh Khoa | Hầm Đá | Hướng dẫn khai thác, Vật | Đèn đầu, đồ thợ mỏ | Kiểm mỏ, ngồi sảnh, chở khoáng |
| Chị Vy | Quán Hương Lúa | Nấu ăn, lễ hội, giao thương | Khăn bếp, tạp dề | Băm rau, mời khách, ghi thực đơn |
| Marco | Bến cảng | Tri thức Ngữ, giao thương ngoại quốc | Áo thủy thủ/khăn cổ | Gỡ dây buồm, xem hàng, nói chuyện tại cảng |

GDD đã quy định **hữu nghị 0–10 tim**, trò chuyện +20/ngày, quà theo sở thích, sự kiện quan hệ mỗi 2 tim; lịch NPC là JSON theo `weekday`, `weekend`, `rain`, `festival`, `special`, sử dụng `NavigationAgent2D`. **MỚI:** khi nhân vật không chạy mô phỏng đầy đủ ngoài camera, hãy giữ trạng thái logic theo mốc giờ rồi đưa vào vị trí hợp lệ lúc camera đến, tránh “dịch chuyển ngay trước mắt”.

### 7.2 Vai phụ làm nền [MỚI — ĐỀ XUẤT, KHÔNG PHẢI NPC CHÍNH THỨC]

Để không tạo làng hoang vắng có thể có `background_villagers` không có đường hữu nghị riêng: người gánh hàng vào chợ, trẻ em trong sân trường, người lớn nghỉ bên hồ, khách du lịch trong lễ hội. Số lượng và spawn phải theo hiệu năng; **không** tự tạo quest/cốt truyện/quan hệ nếu chưa thêm vào danh sách GDD. Mỗi mẫu dùng quần áo/điệu bộ riêng, không sao chép cùng sprite ở mọi vùng.

### 7.3 Quy tắc lịch sinh hoạt có thể tin cậy

- Lịch cơ bản: nơi ở → nơi làm → nghỉ trưa ngắn → hoạt động sau giờ → về nhà. **Các giờ cụ thể của từng NPC chưa được GDD chốt**; tạo file dữ liệu riêng để tác giả điền.
- Khi có mưa/bão, hoạt động ngoài trời chuyển sang nơi trú theo `rain`; ngày lễ dùng `festival`; nhiệm vụ chương dùng `special` ưu tiên cao.
- NPC đi giữa các map bằng `MapPortal` có điểm đến, không xuyên tường, không đi vào vùng boss hoặc nhà riêng của người chơi nếu không có sự kiện.
- Khi NPC không hiện diện, vật tương tác có thể báo lịch hoặc gợi ý, nhưng **không tự mở cửa hàng** ngoài giờ.
- Nếu NPC đang ở cutscene/nhận nhiệm vụ, `NpcScheduleController` tạm giữ vị trí rồi tiếp tục lịch sau khi kết thúc; người chơi không mất hội thoại giữa chừng.

### 7.4 Một ví dụ lịch **chỉ để minh họa cấu trúc**, chưa canon [MỚI]

```json
{
  "npc_id": "teacher_lan",
  "weekday": [
    {"start_minute": 360, "map_id": "school_grounds", "position_marker": "staff_room", "activity": "prepare_lessons"},
    {"start_minute": 480, "map_id": "school_grounds", "position_marker": "classroom_board", "activity": "teach"},
    {"start_minute": 720, "map_id": "school_grounds", "position_marker": "school_garden", "activity": "garden_check"},
    {"start_minute": 840, "map_id": "school_grounds", "position_marker": "classroom_board", "activity": "teach"}
  ]
}
```

Dữ liệu thực cần được duyệt lại theo buổi học 08–10 và 14–16; các mốc khác do team nội dung quyết định.

---

## 8. HỆ SINH THÁI: CÂY, VẬT NUÔI, ĐỘNG VẬT HOANG, NGUỒN LỢI

### 8.1 Thảm thực vật và vòng đời [GDD]

**Cây trồng:** 14 loại nông nghiệp theo GDD, 4–6 frame phát triển (hạt, mầm, non, trưởng thành, chín, héo). Cần tưới trong ngày để tăng 1 ngày sinh trưởng; ba ngày liền không tưới thì héo; trái mùa héo trừ trong nhà kính. **Cây ăn quả:** đào, cam, táo, hồng; cần khoảng trống 3×3 ô khi lớn. **Cây rừng:** sồi, thông, phong, cổ thụ; gốc chặt còn lại. **Hoa và bụi:** cúc, tulip, hướng dương, hoa tuyết, hoa Nguyệt, bụi dâu, cỏ cao... [GDD]

[MỚI] Mỗi cây có ba lớp rõ trong world asset: **silhouette** để nhận dạng loài từ xa, **trạng thái tương tác** để biết có thể thu hoạch/chặt, và **dấu mùa** để cho thế giới thay đổi. Tránh dựa vào tooltip để phân biệt cây đã chín. Dùng ít nhất một dấu hình: quả to hơn, chấm sáng, lá khác, búp mở.

### 8.2 Vùng hái lượm theo mùa [GDD + MỚI]

| Môi trường | Xuân | Hạ | Thu | Đông |
|---|---|---|---|---|
| Rừng / nông trại | Tỏi dại, rau dớn, hoa | Dâu rừng, hướng dương dại | Nấm, hạt dẻ, mâm xôi | Rễ củ, quả khô |
| Bờ nước / biển | Rau cải xoong | Vỏ sò, rong biển | Sò điệp | San hô khi biển lặng |
| Hầm / núi | Tuyết lan chân núi | Nấm đá | Nấm hang | Tinh băng, Hoa Nhung Tuyết |

[GDD] 06:00 mỗi map ngoài trời spawn 3–8 vật hái lượm; mưa làm nấm nhiều hơn. [MỚI] Spawn chỉ trên ô đi được, cách portal và điểm quest bắt buộc ít nhất một khoảng an toàn; không rơi vào ô có đồ người chơi đặt. Biến thể hình ảnh phải phản ánh đúng vật phẩm nhận được.

### 8.3 Vật nuôi [GDD]

Tám nhóm vật nuôi **gà, vịt, bò, dê, cừu, heo, ong, ngựa** và thú cưng **mèo/chó**. Không giết/mổ; có thể nhượng vật nuôi cho cô Mai. Chỉ số Đói/Khát/Hạnh phúc/Sức khỏe/Nhiệt; sản phẩm đổi theo chất lượng, mùa và chăm sóc. Cần cho ăn, cho uống, vuốt ve, đóng cửa chuồng trước 19:00, chữa bệnh; mùa Đông cần sưởi. Người chơi học được ý nghĩa nuôi dưỡng chứ không chỉ lấy tài nguyên.

[MỚI] Hoạt ảnh vật nuôi tối thiểu cần thấy: đứng, đi, ăn, ngủ, nhận vuốt ve, trạng thái ốm/đói (icon trên đầu). Cho con vật **vùng quay đầu/lối về chuồng** để không đi xuyên rào. Mèo/chó đi theo có khoảng cách mềm, tránh đẩy người chơi khi tương tác hoặc chiến đấu.

### 8.4 Động vật hoang [GDD]

**Thỏ, chim sẻ, vịt trời, ếch, cua, bướm, đom đóm, hươu, cú, cáo** có hành vi theo giờ, mùa, thời tiết; đa số dùng quan sát/cho ăn/bắt nhẹ để mở Bách khoa và nhận nguyên liệu. [MỚI] Quy tắc art: động vật phải có chuyển động nhận diện trước khi người chơi tới gần: sẻ mổ hạt rồi bay, thỏ giật tai, vịt tạo sóng, cua đi ngang, hươu ngoái nhìn rồi chạy. Không sử dụng cùng một kiểu `idle` cho tất cả.

### 8.5 Phân bố sinh thái không gian [MỚI]

- Vùng cư trú có **thú hiền và gia súc**; đêm Trăng Tròn nông trại có hiểm họa hiếm theo GDD, nhưng quảng trường và chợ vẫn được thiết kế là nơi an toàn.
- Vùng bờ hồ ưu tiên **vịt trời, ếch, đom đóm**; chỉ xuất hiện vào những khoảng giờ thích hợp.
- Rừng và núi ưu tiên **thỏ, hươu, cú**, khu rậm/đêm có quái.
- Biển ưu tiên **hải âu, cua, rùa biển**, thay đổi theo triều.
- Mỏ ưu tiên sinh vật/quái phù hợp với đá và bóng tối, không tự đưa động vật trang trại vào.

---

## 9. QUÁI QUÊN, VÙNG NGUY HIỂM VÀ KHÔNG GIAN CHIẾN ĐẤU

### 9.1 Bản sắc của Quái Quên [GDD]

Quái vật là biểu tượng của **ký ức bị xóa**, không phải sinh vật đẫm máu. Khi bị đánh bại, chúng tan thành mực, giấy, bột sáng trong hoạt ảnh 6 khung. Các dạng chính: Slime Mực, Sâu Đá, Dơi Giấy, Nấm Độc, Cua Đá, Quái Điện, Nhện Hang, Sói Bóng Đêm, Ma Sương, Linh Băng, Sách Hộ Pháp, Golem Đá. Chỉ số, loot, bán kính phát hiện, hành vi và tỉ lệ spawn phải đọc từ GDD mục 11/data, không tự đặt lại trong world spec này.

**Ngôn ngữ hình ảnh [MỚI]:**

| Nhóm | Dấu hiệu nhận ra | Hiệu ứng sinh ra/thua |
|---|---|---|
| Mực/gel | Đầu hoặc thân nửa trong, giọt mực chảy ngược | Bong bóng mực tụ rồi tách |
| Giấy/sách | Mép rách, dòng chữ vụn, cánh như trang sách | Trang giấy rơi chậm rồi tan |
| Sương/ảo ảnh | Viền rời, ánh tím xanh, bóng không ổn định | Chụm thành một ký hiệu ngôi sao thiếu nét |
| Đá/tinh thể | Khối góc sắc, vết nứt ký hiệu công thức | Mảnh đá và bụi lắng xuống |
| Sinh vật biến dị | Silhouette vẫn giống loài nền, chỉ thêm dấu Quên | Trở về hình rừng/biển không bạo lực |

### 9.2 Không gian chiến đấu có đường lui [MỚI]

- Trận chạm trán thường phải có **khung sàn đủ để né**, không đặt vật trang trí cản mọi hướng cạnh portal; mục tiêu 3–4 tile đất trống theo một trong các hướng thoát.
- Khi địch phát hiện, `!` và telegraph phải hiện nổi trên cỏ, đá, nước hoặc nền tối. [GDD/UI]
- Đòn lớn luôn có **khoảng báo hiệu** như bảng quái trong GDD; không dùng hạt mưa/tuyết giống màu đòn để đánh lừa.
- Chạm trán boss tách khỏi vòng giao thương làng bằng **phòng/đấu trường riêng**, có lối vào và cơ chế trở ra.
- Nếu người chơi mất hết HP, áp dụng ngất/đưa về nhà, Phòng khám hay sảnh hầm theo GDD, không đặt lại ở một tile nguy hiểm.

### 9.3 Năm đấu trường Bóng Quên [GDD + MỚI]

| Trùm | Đấu trường / dấu hiệu [MỚI] | Đòn/cơ chế chiến đấu [GDD] | Câu đố & biểu đạt tri thức [GDD] | Phản hồi sau thắng [MỚI] |
|---|---|---|---|---|
| **Bóng Số Không** | Hầm trường có sàn ô số, bảng phấn nứt | Né số rơi, sang pha 2 | Đánh đúng con số đáp án của 3 phép tính | Các con số trên bảng học hiện lại rõ |
| **Gã Gạch Xóa** | Hầm sách, sàn ghép dòng chữ | Gạch xóa vùng sàn | Điền từ đúng để khôi phục ô an toàn | Kệ/biển thư viện sáng chữ |
| **Thủy Thủ Câm** | Boong tàu, mỏ neo và làn sóng quanh mép | Sóng, mỏ neo quét | Hội thoại tiếng Anh lộ điểm yếu | Đèn cảng/biển chỉ dẫn đọc được |
| **Golem Công Thức** | Phòng máy hầm tầng 30, cột mạch | Dậm đất, ném đá | Đánh khớp sáng theo chuỗi công thức khoa học | Máy cũ nhấp nháy ổn định |
| **Hồn Ký Ức** | Bệ đá Núi Mây, bia thời gian | Sương, ảo ảnh | Xếp mốc ký ức đúng thứ tự | Cột mốc trên đường núi phục hồi |

**Trùm cuối — Kẻ Xóa Chữ [GDD]:** tại Đài Thiên Văn, đêm Đông ngày 7 lúc 20:00, ba pha xóa chữ/số/ngôn ngữ và dùng cả năm tri thức; kết thúc bằng “nhắc nhớ”, không giết chóc. [MỚI] Thiết kế visual theo nhịp: nền sao yên tĩnh → ký hiệu dần biến mất → năm vòng sáng trở lại khi người chơi giải thành công. Bố cục boss UI không che các điểm cần tương tác trên sân.

### 9.4 Các chế độ nguy hiểm theo ngày

[GDD] **Trăng Tròn** ngày 4 mỗi mùa làm bầy sói mạnh hơn, mở Hoa Nguyệt; **Sương Quên** gây hạn chế tầm nhìn và trạng thái Quên; mưa làm Slime Mực xuất hiện nhiều hơn; giông sinh Quái Điện; Đông có Sói Tuyết/Linh Băng. [MỚI] Để không phá nhịp chơi thư thái, mỗi vùng cần có ít nhất một **tín hiệu báo trước** bằng âm thanh, biển chỉ dẫn hoặc ánh sáng, cùng đường rút an toàn.

---

## 10. TRI THỨC NẰM TRONG THẾ GIỚI, KHÔNG TÁCH RỜI THẾ GIỚI

### 10.1 Phân bổ năm mảng tri thức [GDD]

| Mảng | Địa bàn và vật thể học chính | Bài học thế giới | Phần thưởng vai trò |
|---|---|---|---|
| **Số** — Toán | Trường, bảng giá Dì Năm, bàn học | Tính tiền thối, đo diện tích, nhận quy luật | Bán có giá tốt hơn, mua giảm giá, Mảnh Số |
| **Chữ** — Ngữ văn | Thư viện, sách, bia có chữ | Điền ca dao, ghép câu, phục hồi đoạn văn | Hội thoại phong phú, quà tốt hơn, Mảnh Chữ |
| **Ngữ** — Tiếng Anh | Bến cảng, Marco, thương lái ngoại quốc | Nối từ–hình, giao tiếp, điền hội thoại | Mở giao thương, Mảnh Ngữ |
| **Vật** — Khoa học tự nhiên | Vườn trường, phòng thí nghiệm, Hầm Đá, Phòng khám | Vòng đời cây, mạch điện, cơ thể, máy móc | Công thức/chế tạo, cây tốt hơn, Mảnh Vật |
| **Ký** — Lịch sử–Địa lý | Bản đồ, thư viện, Núi Mây, đài thiên văn | Định hướng, lịch sử làng, sắp xếp mốc ký ức | Đường tắt, bản đồ, Mảnh Ký |

### 10.2 Mẫu thiết kế một câu đố gắn môi trường [MỚI]

**Ví dụ A — Bảng giá chợ, Số:** người chơi thấy ba rổ rau và thẻ giá ở quầy Dì Năm. Nhấn `E` mở khung câu hỏi nhỏ theo UI chuẩn, tính tổng tiền/thối tiền; đáp đúng, Dì Năm nhận xét và trao XP. Nếu sai, giải thích ngắn, không phạt Xu hàng hóa thật.

**Ví dụ B — Vườn thực nghiệm, Vật:** ba luống có ánh sáng, đất và nước khác nhau. Người chơi quan sát cây, kéo thẻ điều kiện “nước/ánh sáng/không khí/chất dinh dưỡng” vào bảng. Sau giải thích, người chơi nhận biết quy tắc cây trồng đang áp dụng trong game.

**Ví dụ C — Bia ký ức trên Núi Mây, Ký:** các phiến đá khắc bốn sự kiện làng; người chơi xem di vật ở các vùng rồi sắp thứ tự mốc. Nếu sai, có thể đọc lại gợi ý trên bia, không buộc đi tìm vật phẩm ngẫu nhiên.

**Ví dụ D — Marco ở bến, Ngữ:** lời thoại liên quan việc chỉ đường tới thuyền, các đáp án hiện dưới dạng hội thoại như UI đã thiết kế. Trả lời đúng giúp Marco hiểu; sai thì NPC diễn đạt lại đơn giản hơn.

**Ví dụ E — Hầm sách, Chữ:** câu ca dao bị trống một từ, đáp án tương ứng các mảnh giấy trên sàn; điền đúng giúp hiện lại một đoạn đường an toàn.

### 10.3 Quy tắc sư phạm xuyên thế giới [GDD + MỚI]

- 5 câu/phiên học, tối đa 5 mức độ khó thích ứng; đúng/sai đều có phản hồi bằng lời giải thích. [GDD]
- Không có đồng hồ đếm giờ mặc định; `Gợi ý` và `Bỏ qua tạm` có ở mọi dạng. [GDD/UI]
- Thất bại 3 lần ở câu đố Chính tuyến sẽ có hỗ trợ của Lão Quang để đi tiếp với 1 sao. [GDD]
- [MỚI] **Ngôn ngữ câu đố phải khớp đồ vật địa phương**: bài toán nông nghiệp dùng giá nông sản, bài khoa học dùng cây, bài địa lý dùng đường đến bản đồ; không dùng nội dung ngẫu nhiên lệch bối cảnh.
- [MỚI] Mỗi “bài học lần đầu” nên có dấu hiệu tương tác trên scene; lượt ôn lại không cần hiện một nhiệm vụ mới.

---

## 11. CỐT TRUYỆN VÀ CÁC LỚP BIẾN ĐỔI THẾ GIỚI

### 11.1 Thứ tự 7 chương [GDD]

| Chương | Mốc sớm nhất | Map trọng tâm | Biến đổi có thể nhìn thấy [MỚI] | Kết quả [GDD] |
|---|---|---|---|---|
| Mở đầu: Lá Thư | Xuân 1 | Nông Trại, Phố Chợ | Nhà cũ, cỏ cần dọn, phong thư/chiếc chìa khóa | Nhận Sổ Tay |
| 1. Hạt Giống Đầu Tiên | Xuân 2 | Nông Trại, Chợ, Trường | Nhân vật trong làng giới thiệu nhau, đường rừng có dấu mở | Rừng, sảnh Hầm, nhiệm vụ ngày |
| 2. Ngôi Trường Im Lặng | Xuân 4 | Trường, hầm trường | Bảng bị xóa số, sân bớt học sinh, sau thắng sáng lại | Mảnh Số, lướt |
| 3. Thư Viện Bị Khóa | Hạ 1 | Đồi Thư Viện, hầm sách | Trang sách phai, cửa hầm mở sau Chìa Mực | Mảnh Chữ, công thức nâng cao |
| 4. Tiếng Sóng Ngoại Ngữ | Hạ 5 | Hồ Gương, Biển | Sửa cầu, mở đường ra bến, đèn nước lễ hội | Mảnh Ngữ, Áo Phao, nhà kính |
| 5. Mỏ Đá Thì Thầm | Thu 1 | Hầm Đá tầng sâu | Máy cơ khí phục hồi từng phần | Mảnh Vật, Núi Mây |
| 6. Núi Mây và Ký Ức | Thu 5 | Núi Mây, đài thiên văn | Bia lịch sử sáng lên, dấu sao dẫn đỉnh | Mảnh Ký, đài nâng cao |
| 7. Đêm Sao Rơi | Đông 1; trận cuối Đông 7 20:00 | Đài thiên văn, Quảng Trường | Làng chuẩn bị trang trí, bầu trời có dấu năm cánh | Trùm cuối, hậu kết, chơi tự do |

Các chương chỉ mở khi chương trước hoàn thành và đạt ngày tối thiểu; **không hết hạn**, có thể đi tiếp trong năm sau. [GDD] Vì vậy môi trường phải dựa vào **cờ tiến trình**, không chỉ dựa vào mùa/ngày: nếu tới Đông mà người chơi chưa xong Ch4, cảnh không được tự giả định cầu đã sửa.

### 11.2 Phân lớp sự kiện (`event_overlay`) [GDD + MỚI]

**Thế giới cơ sở** được dựng từ tileset mùa; **trạng thái chương** bổ sung cổng/đồ vật/câu chữ; **lễ hội** dựng sân khấu/cờ/gian hàng; **thời tiết** phủ hiệu ứng; cuối cùng là ánh sáng theo giờ. Các lớp độc lập giúp không phải nhân bản một map cho mỗi chương.

[MỚI] Quy tắc ưu tiên xung đột:

1. Khả năng đi lại và portal bắt buộc.
2. Trạng thái cốt truyện/đối tượng tương tác.
3. Lễ hội theo ngày.
4. Công trình do người chơi đặt.
5. Thời tiết, mùa và trang trí ngẫu nhiên.

Một sự kiện không được xóa hoặc chiếm ô công trình/vật nuôi của người chơi. Nếu một NPC có nhiệm vụ chương nhưng là ngày lễ, nội dung phải có nhánh hội thoại tại lễ hội hoặc giải pháp sau lễ, không khiến nhiệm vụ mắc kẹt.

### 11.3 Bốn lễ hội [GDD + MỚI]

| Lễ hội | Ngày [GDD] | Trang trí thế giới [MỚI] | Hoạt động gắn gameplay [GDD] |
|---|---|---|---|
| **Hội Hoa Xuân** | Xuân 7 | Cổng hoa đào, dây hoa giấy, gian trưng bày cạnh đài phun | Cắm hoa, thu thập 5 loại hoa, đố Số/Chữ |
| **Hội Biển Đêm** | Hạ 7 | Đèn nước, đèn cảng, bến gỗ có cờ, đom đóm | Thi câu cá đêm, giao tiếp tiếng Anh |
| **Hội Gặt** | Thu 7 | Rơm cuộn, bó lúa, giỏ bí ngô, sân bày nông sản | Nộp nông sản chất lượng, nấu, ca dao |
| **Đêm Sao Rơi** | Đông 7 | Bàn sao, đèn vàng ấm, sao giấy năm cánh, trời quang | Kết thúc Ch7, năm sau là ngày hội vui |

[GDD] Lễ hội diễn ra 10:00–23:00; cửa hàng thường đóng; thời tiết bảo đảm nắng/trời quang. [MỚI] Lối tới các gian hàng phải đi được từ cổng chính, có các điểm đứng dành cho NPC chính; tránh overlay ngày hội làm biến mất bảng nhiệm vụ hoặc gây lỗi NPC pathfinding.

### 11.4 Ba hậu kết và dấu vết lưu lại [GDD + MỚI]

[GDD] Hậu kết phụ thuộc mức phát triển **Trường**, **Thư Viện** hoặc **Nông Trại**. [MỚI] Mỗi hậu kết có thể dùng một thay đổi xã hội nhẹ trong thế giới sau kết thúc: thêm bàn học ngoài sân, triển lãm sách ở quảng trường hoặc vườn cộng đồng; chỉ là **ý tưởng mỹ thuật/không gian**, chưa có công thức tính phát triển được GDD xác nhận. Hậu kết không xóa thành tựu, NPC hay tài sản người chơi.

---

## 12. HỆ THỐNG KINH TẾ, KHÁM PHÁ VÀ ĐỜI SỐNG

### 12.1 Dòng lưu chuyển vật phẩm trong không gian

```text
Nông Trại ──nông sản──► Hòm gửi hàng / Dì Năm / Quán Hương Lúa
    ▲                            │
    │                       Xu / công thức
    │                            ▼
Đồng Cỏ ──sữa, trứng──► Bếp / trạm chế biến / quà NPC

Rừng ──gỗ, nấm──► Bàn chế tạo ──đồ dùng──► Nông Trại
Mỏ ──quặng──► Lò rèn ──công cụ mạnh──► Rừng / Mỏ / Nông Trại
Hồ & Biển ──cá, rong──► Chợ / Quán ăn / Bách khoa
Trường & Thư viện ──tri thức──► kỹ năng mở rộng / câu đố / công thức
```

Đây là **sơ đồ luồng**, không thêm giá mới. Mọi hệ số kinh tế, kỹ năng, XP, chất lượng và thời gian chế biến được lấy theo GDD mục 7–13.

### 12.2 Mỗi vùng phải có vòng chơi ngắn và dài [MỚI]

| Vùng | Vòng chơi ngắn (1–3 phút) | Lý do quay lại (ngày/mùa/chương) |
|---|---|---|
| Nông Trại | Tưới, thu, cất đồ | Tăng vụ, nâng nhà/chuồng/nhà kính |
| Đồng Cỏ | Quan sát, chăm con vật | Chọn giống mới, tăng hạnh phúc |
| Phố Chợ | Mua giống, bán, ghé quán | Giá/giống mùa, đơn hàng, NPC |
| Quảng Trường | Nhận nhiệm vụ, đọc bảng tin | Nhiệm vụ ngày, dự báo, lễ hội |
| Trường | Làm một câu/quan sát vườn | Lớp theo buổi, tri thức Số/Vật |
| Đồi Thư Viện | Đọc, tra mục lục | Sách mới, hầm Ch3, Chữ/Ký |
| Rừng | Hái nấm, chặt một cây | Tài nguyên theo mùa, bí mật đêm |
| Hầm | Đập quặng, xuống một tầng | Kim loại cao cấp, boss, Vật |
| Hồ | Một lượt câu/bẫy | Cá theo thời tiết, băng mùa Đông |
| Biển | Nhặt vỏ sò, nói với Marco | Triều thấp, thương nhân, Ngữ |
| Núi | Tìm một mốc, nhặt tinh băng | Đài thiên văn đêm quang, Ký |

### 12.3 Giới hạn áp lực [GDD + MỚI]

- Thất bại chiến đấu/ngủ muộn chỉ mất một phần Xu hoặc thể lực/HP như GDD; không dùng “game over vĩnh viễn”.
- Nhiệm vụ Chính tuyến không hết hạn; gợi ý và đường hỗ trợ không bị khóa do trả lời sai.
- [MỚI] Những nhiệm vụ tạo cảm giác thời hạn (trồng theo vụ, chợ mở theo giờ, cá theo mùa) nên có nhắc bằng sổ tay và bảng tin, nhưng không spam cảnh báo.
- [MỚI] Mọi khu khóa phải có **lời giải thích theo thế giới**: cầu chưa sửa, đường rừng cần chỉ dẫn, cổng mỏ cần chuẩn bị, núi cần móc leo; không hiển thị chỉ một ổ khóa trơ trọi.

---

## 13. MẠNG ÂM THANH VÀ KHÔNG KHÍ TỪNG VÙNG

### 13.1 Phân lớp âm thanh [MỚI — ĐỀ XUẤT]

`MusicMap` (nhạc theo map) + `AmbienceBiome` (môi trường lặp) + `SpotSFX` (âm từ vị trí: giếng, búa, chim) + `WeatherLoop` (mưa/gió/tuyết) + `StoryStinger` (cốt truyện) + `InteractionSFX` (công cụ, UI). `AudioManager` quyết định chuyển nhạc theo map/giờ/thời tiết như GDD.

| Map | Nhạc đặc trưng [GDD] | Điểm phát âm trong thế giới [MỚI] |
|---|---|---|
| Nông Trại | Guitar mộc | Giếng, cây, gà gáy, mái mưa |
| Đồng Cỏ | Sáo | Bò kêu, chuông cỏ, bước chân đàn |
| Phố Chợ | Jazz nhẹ | Lò rèn gõ, tiếng rao, nấu ăn, sạp bán |
| Quảng Trường | Accordion | Đài phun, tiếng nói xa, cờ gió |
| Trường | Xylophone | Chuông, phấn, bước chân, chim |
| Đồi Thư Viện | Piano/cello | Lá khô, giấy, tiếng cửa gỗ |
| Rừng | Sáo thì thầm; đêm bass trầm | Cú, cành gãy, côn trùng, sói xa |
| Hầm Đá | Nhỏ giọt và synth | Nước, đá vỡ, thang, tinh thể |
| Hồ | Đàn hạc | Sóng bờ, vịt, cá quẫy, thác |
| Biển | Ukulele | Sóng, hải âu, thuyền, dây buồm |
| Núi | Dàn dây, gió | Gió tầng cao, băng, chuông đài |

### 13.2 Phản hồi âm thanh có tính năng

- Tiếng `!` khi cá cắn, đổi giờ học, tiếng chuông rèn hoàn thành, cảnh báo quái và thông báo nhiệm vụ đều phải có **phụ đề âm thanh tùy chọn** theo UI Spec. [UI + MỚI]
- Trời mưa bên trong công trình nghe **mưa qua mái/cửa sổ giảm âm**, không phát vòng lặp mưa giống ở ngoài. [GDD]
- Đêm khuya giảm âm dân cư, tăng côn trùng/gió, đèn bật đồng bộ `light_level < 0.55`. [GDD + MỚI]
- Khi mở menu/học tập thời gian tạm dừng, âm môi trường có thể giảm âm lượng nhẹ nhưng không được để nhạc tiếp tục báo nguy hiểm như trận đang chạy. [MỚI]

---

## 14. THIẾT KẾ CẤP ĐỘ MAP, CAMERA, ĐƯỜNG ĐI VÀ LỚP VA CHẠM

### 14.1 Hợp đồng một scene map [MỚI]

Mỗi scene cần có: `map_id`, kích thước tile cố định, ít nhất một `SpawnPoint`, danh sách `MapPortal`, các `NavigationRegion2D`/ô đi được, layer render chuẩn, vùng âm thanh, ánh sáng, điểm spawn NPC/động vật/quái, `FishingZone` nếu có nước, vị trí camera có giới hạn, và mô tả `map_state_id`.

### 14.2 Thông số phải bám GDD

- Physics layers 1–10: `world_solid`, `player`, `npc`, `monster`, `animal`, `interactable`, `hitbox_player`, `hitbox_monster`, `pickup`, `trigger`. [GDD]
- Camera bám nhân vật, smoothing 6, giới hạn đúng kích thước map; tính y-sort theo chân thực thể. [GDD]
- Portal fade 0,25 giây vào + 0,25 giây ra; thời gian vẫn chạy; map cache giữ state. [GDD]
- Vật cao dùng điểm gốc ở chân, mái nhà và tán cây ẩn/mờ khi cần. [GDD]
- Thực thể ngoài bán kính 2 màn hình giảm cập nhật; cây ngoài tầm nhìn cập nhật theo ngày; object pooling cho vật rơi, hạt, đạn. [GDD]

### 14.3 Tiêu chuẩn khả năng đi và camera [MỚI]

1. **Khu spawn:** không va chạm, không quái xuất hiện sát, không đẩy người chơi vào nước sâu, không đứng ngay bên rìa tile bị chặn.
2. **Cửa & quầy:** có ít nhất một ô đứng trước tương tác; mỗi NPC trọng tâm có `position_marker` không chồng cửa.
3. **Giao lộ:** dấu chỉ đường/landmark thấy từ vùng vào; mũi tên không đè NPC hoặc ảnh hưởng bối cảnh.
4. **Vật thể che:** khi người chơi đi sau tán/mái, che mờ phần cần thiết trong chốc lát; hitbox không đổi do alpha.
5. **Nước sâu:** có va chạm cho tới khi mở Bơi/Áo Phao; chỗ lội phải có ranh giới rõ. [GDD]
6. **Địa hình cao:** mỗi bậc 0–3 có lối nối rõ (cầu, thang, đường dốc); không có chỗ rơi vô hình.
7. **Ngày lễ:** kiểm tra lại đường đi vì gian hàng xuất hiện, đám đông và NPC đổi lịch.
8. **Tăng font/độ phóng UI:** menu/tooltip không quyết định vị trí vật thể trong thế giới; gợi ý tương tác lật phía khi sát cạnh màn hình. [UI]

### 14.4 Sổ ghi cổng cần lập khi dựng [MỚI]

| `portal_id` mẫu | `from_map` | `to_map` | Điều kiện | Ghi chú |
|---|---|---|---|---|
| `farm_to_market` | `farm_main` | `market_street` | Không | GDD có liên kết tuyến đi |
| `farm_to_ranch` | `farm_main` | `ranch` | Không | Vào vùng tự do |
| `farm_to_forest_shortcut` | `farm_main` | `whispering_forest` | Ch1 | Lối tắt phía bắc |
| `square_to_school` | `town_square` | `school_grounds` | Không (sân) | Lớp học mở sau Ch1 |
| `square_to_library` | `town_square` | `library_hill` | Không | Đường lên đồi |
| `library_to_forest` | `library_hill` | `whispering_forest` | Ch1 | GDD sơ đồ chính |
| `forest_to_mine` | `whispering_forest` | `stone_mine` | Ch1 + cấp ≥3 | Cổng sảnh hầm |
| `library_to_lake` | `library_hill` | `mirror_lake` | Không | Đường ra nước |
| `lake_to_beach` | `mirror_lake` | `golden_beach` | Sửa cầu | Theo điều kiện mở bãi biển |
| `library_to_mountain` | `library_hill` | `cloud_mountain` | Ch5 + cấp ≥8 | Cần phân biệt cổng chân núi và leo vách |

**Chưa chốt:** một số mũi liên kết trung tâm trong sơ đồ chữ GDD cần mô tả portal hai chiều chính xác trước khi dựng scene. Bảng trên là **đề xuất danh sách liên kết tối thiểu**, không khẳng định đã đủ mọi cổng.

---

## 15. CẤU TRÚC DỮ LIỆU THẾ GIỚI — DATA-DRIVEN GODOT

### 15.1 Ranh giới trách nhiệm [GDD + MỚI]

| Hệ thống | Sự thật quản lý | Không nên quản lý |
|---|---|---|
| `GameClock` | Phút game, ngày, mùa, năm, sự kiện thời gian | Nội dung cụ thể của cây/NPC |
| `SeasonSystem` | Biến thể mùa, luật cây đổi mùa | Chi tiết hội thoại |
| `WeatherSystem` | RNG thời tiết, dự báo, điều kiện đặc biệt | Sinh quái tự do không qua `SpawnDirector` |
| `SceneManager` | Portal, spawn, cache map, chuyển cảnh | Giá bán hàng |
| `QuestManager` | Cờ nhiệm vụ, mục tiêu, tiến trình chương | Chỉnh thẳng tile nếu không qua hệ thống map |
| `InventoryManager` | Túi/rương/hotbar và số lượng | Lịch NPC |
| `KnowledgeManager` | Câu đố, năm mảng tri thức, độ khó | Cửa map ở trạng thái tùy ý |
| `SaveManager` | Snapshot trạng thái, `save_version`, migrate | Tự suy đoán cờ chưa lưu |
| `AudioManager` | Nhạc, âm tầng, fade giữa vùng | Sinh NPC |
| `EventBus` | Signal thông báo giữa hệ thống | Chứa logic gameplay |
| **`WorldStateService` [MỚI]** | Trả về dữ liệu `MapStateData`/biến thể/cờ vùng một cách nhất quán | Không ghi đè GDD; là lớp truy cập dữ liệu đề xuất |

[MỚI] `WorldStateService` là tiện ích tùy chọn, không bắt buộc thêm Autoload. Có thể đặt là component/service của `SceneManager` nếu muốn tránh singleton mới.

### 15.2 Hợp đồng `MapStateData` [GDD]

Các trường đã ghi trong GDD: `map_id`, `season`, `time_phase`, `light_level`, `weather_segments`, `special_flags`, `wetness`, `snow_cover`, `temperature`, `is_open`, `event_overlay`.

[MỚI] Cần liên kết tới **phần trạng thái lưu bền** riêng: công trình/vật đặt, cây trồng, ô đất, vật rơi, rương, portal mở, đối tượng nhiệm vụ và NPC đang ở đâu. Không ép thông tin lưu bền vào tất cả instance `MapStateData`; GDD đã quy định lưu ở nhánh `maps` của save.

### 15.3 `MapDefinition` đề xuất [MỚI]

Đây là dạng dữ liệu thiết kế, không phải class đã có trong dự án. Có thể triển khai thành `Resource`/`.tres`.

```json
{
  "map_id": "mirror_lake",
  "name_key": "MAP_MIRROR_LAKE_NAME",
  "scene_path": "res://scenes/maps/mirror_lake.tscn",
  "size_tiles": [60, 44],
  "biome_id": "lake_river",
  "music_id": "bgm_mirror_lake",
  "spawn_points": ["from_library", "from_beach", "lake_pier"],
  "portal_ids": ["lake_to_library", "lake_to_beach"],
  "fishing_zone_ids": ["lake_central", "river_bank", "waterfall_foot"],
  "poi_ids": ["lake_pier", "boathouse", "bridge", "waterfall"],
  "seasonal_variant_group": "four_seasons",
  "story_overlay_group": "mirror_lake_story",
  "festival_overlay_group": null
}
```

**Quy ước:** ID/đường dẫn minh họa phải được xác nhận trước khi code; không dùng dữ liệu placeholder để tạo đường đi thật mà thiếu cặp return portal.

### 15.4 `WorldPOI` đề xuất [MỚI]

Một điểm đáng chú ý (Point of Interest) có: `poi_id`, `map_id`, `tile_position`, `display_name_key`, `type` (`landmark`, `shop`, `quest`, `resource`, `fishing`, `transition`, `lore`, `hazard`), `interaction_id`, `unlock_conditions[]`, `minimap_icon`, `world_icon`, `time_windows[]`, `season_windows[]`, `discovery_flag`, `audio_emitter_id`. `WorldPOI` chỉ làm **danh mục địa điểm**, không trùng toàn bộ dữ liệu Shop/Quest/Interactable.

Ví dụ điểm `bridge` của Hồ Gương: `type=transition`, `unlock_conditions=[quest_repair_bridge_completed]`, `discovery_flag=bridge_seen`; icon bản đồ thay đổi theo `quest` và state. **ID điều kiện là tên minh họa**, chưa có trong tài liệu nguồn.

### 15.5 Tín hiệu đề xuất cho sự thay đổi môi trường

Bên cạnh tín hiệu đã có trong GDD, có thể bổ sung qua `EventBus`: `map_poi_discovered(poi_id)`, `portal_unlocked(portal_id)`, `world_prop_state_changed(persistent_id, state_id)`, `interior_entered(interior_id)`, `tide_phase_changed(tide_id)`, `festival_overlay_changed(map_id, overlay_id)`. [MỚI]

**Luồng mẫu khi sửa cầu:** QuestManager đánh dấu mục tiêu hoàn thành → EventBus phát sự kiện → World map đọc `unlock_conditions` và thay sprite cầu từ “hỏng” sang “sửa” → `MapPortal` cho vào Biển → SaveManager giữ cờ. Không để script cầu tự viết vào JSON nhiệm vụ.

### 15.6 Sinh ngẫu nhiên có seed và lưu trạng thái

- `world_seed` sinh từ save; thời tiết, spawn hầm, vật phẩm ngẫu nhiên phải tái lập theo seed/phần ngày theo quy tắc GDD.
- Với vật phẩm do người chơi đặt/trồng, **ưu tiên `persistent_id`** hơn seed ngẫu nhiên để tránh mất đồ khi load lại.
- 40 tầng hầm dùng seed ngày, nhưng **tiến trình đang ở tầng/hộp đã mở trong ngày** phải giữ trong phiên và ghi đúng nếu save tại chỗ được hỗ trợ.
- Không tự phát sinh NPC, mùa hoặc cổng trên client theo giờ thực; chỉ dùng đồng hồ game.

### 15.7 Hợp đồng tệp ảnh và animation [MỚI]

```text
assets/art/tilesets/
  shared/                 # dirt_path, water_edges, wood_fence, small_rocks
  spring/ summer/ autumn/ winter/
  forest/ cave/ coast/ mountain/ interior/
assets/art/buildings/
  farm_house/ market_stalls/ school/ library/ forge/ clinic/
assets/art/props/
  signposts/ lanterns/ wells/ benches/ bridge/ crafting_stations/
assets/art/plants/
  crops/ trees/ fruit_trees/ flowers/ foraging/
assets/art/animals/        # per loài, sprite nhiều hướng
assets/art/monsters/       # per quái, attack/telegraph/hurt/death
assets/art/fx/             # leaf_fall, rainfall, fog, water, snow, meteor
```

**Tên file mẫu:** `tree_oak_spring.png`, `tree_oak_winter.png`, `bridge_lake_broken.png`, `bridge_lake_repaired.png`, `forge_flame_04f.png`, `water_river_flow_04f.png`. Mỗi assetsheet có tài liệu `frame_size`, `fps`, `origin`, `collision_bounds`, `atlas_margin`, `palette_variant`.

---

## 16. MA TRẬN ASSET THẾ GIỚI CẦN SẢN XUẤT

> Số lượng bên dưới là **ước lượng sản xuất** để chia ticket; **không thay thế MVP list** ở GDD phụ lục 16.1. Một “bộ” có thể gồm nhiều biến thể/mảnh autotile.

### 16.1 Nhóm tile & môi trường [MỚI]

| Nhóm | Bộ/scope đề xuất | Ghi chú |
|---|---|---|
| Nền cỏ/đất/đường | 4 biến thể mùa × bộ terrain cạnh/góc | Chuyển mùa và mặt đất ướt/khô |
| Nước | 1 bộ sông + 1 hồ + 1 biển, mỗi bộ hoạt hình 4 frame | Bờ nước và tile nông/sâu rõ |
| Rừng | Sồi, thông, phong, cổ thụ, cây bụi, rễ lớn | Tán và thân độc lập; cây cần chặt có HP |
| Núi/đá | 4 mức cao, vách, dốc, bậc thang, rãnh | Chú ý collision/height_level |
| Hầm mỏ | 4 họ vật liệu cho mỗi dải 10 tầng | Đá, quặng, cầu gỗ, tinh thể, máy cổ |
| Bờ biển | Cát khô/ướt, sóng, vỏ sò, san hô, ao triều | Có state theo thủy triều |
| Trang trí | Rào gỗ/tre, luống, đèn, biển, ghế, thùng, sọt, giếng | Tái sử dụng giữa map, đổi bảng màu nhẹ |
| Thời tiết | Mưa, tuyết, gió lá, sương, cầu vồng, sao băng | Kèm trạng thái trợ năng giảm hiệu ứng |
| Kiến trúc ngoài | Nhà nhỏ/vừa/lớn, mái tranh/ngói, cửa, biển hiệu | Cửa và chân tường collision độc lập |
| Nội thất | Sàn gỗ, vách, cửa, bàn, kệ, tủ, giường, dụng cụ học | Tương tác định vị theo object |

### 16.2 Asset nhân vật/sinh vật [GDD + MỚI]

- [GDD] Nhân vật người chơi ghép lớp 16×32, đủ hướng/animation; 12 NPC 16×32 và chân dung 48×48; quái nhỏ 16×16, vừa 24×24, boss ≥48×48.
- [MỚI] Mỗi NPC chính nên có `idle`, `walk`, `interact/activity` và 2–3 biến thể đạo cụ theo nghề; riêng chân dung dùng 4 biểu cảm theo UI Spec.
- [MỚI] Với vật nuôi, chuẩn sheet ít nhất 4 hướng di chuyển và trạng thái ăn/ngủ/nhận chăm sóc; với động vật hoang, có hoạt ảnh đặc trưng và phản ứng bỏ chạy/quan sát.
- [MỚI] Thêm silhouette pass ở 1× và 2× để kiểm tra chồng lấn giữa người, cây và cổng.

### 16.3 Mỗi khu vực cần gói art giao việc cụ thể [MỚI]

| Mã | Landmark phải vẽ | Module độc quyền | Bộ trạng thái cần chụp QA |
|---|---|---|---|
| W01 | Nhà chính + giếng + ruộng | Đất canh tác, chuồng, nhà kính, silo | Sáng Xuân, mưa, Đông, đêm Trăng Tròn |
| W02 | Cổng trại + bãi cỏ | Chuồng mẫu, máng, ao vịt, bảng động vật | Nắng, mưa, Đông, giờ cho ăn |
| W03 | Dãy mái ngói và lò rèn | Quầy tạp hóa, phòng khám, quán, sạp | Mở cửa, đóng cửa, chợ phiên, bão tuyết |
| W04 | Đài phun + bảng tin | Sân lễ hội, gian hàng, ghế, đèn | Ngày thường, 4 lễ hội, tuyết |
| W05 | Cổng trường + lớp U | Bảng đen, phòng thí nghiệm, vườn trường | Buổi học, nghỉ cuối tuần, Sương Quên |
| W06 | Nhà thư viện + cây cổ thụ | Kệ cổ, máy mục lục, hầm sách | Bình thường, Ch3 bị xóa, sau phục hồi |
| W07 | Cổ thụ + hang sói | Nấm, đường rừng, trại thợ rừng | Ngày, đêm, mưa, Sương Quên |
| W08 | Sảnh hầm + thang máy | 4 theme tầng, quặng, cột tinh thể | Tầng đầu, boss 10/20/30/40 |
| W09 | Cầu gỗ + thác + sen | Nhà thuyền, bến câu, băng | Nắng, mưa lớn, đêm Hạ, Đông |
| W10 | Cầu cảng + tàu | Ao triều, hang, đèn nước | Triều cao/thấp, giông, lễ Biển Đêm |
| W11 | Vách zig-zag + đài sao | Trạm nghỉ, bệ ký ức, tuyết cao | Sương sáng, đêm quang, Ch6, Ch7 |

### 16.4 Yêu cầu đầu ra cho họa sĩ [MỚI]

Mỗi gói asset giao kèm: file PNG nền trong suốt ở pixel gốc; sprite sheet có lưới/metadata; bảng màu sử dụng; tile atlas có thứ tự; mẫu đặt vào scene 320×180 ở scale thực; hướng ánh sáng; va chạm đề xuất; animation frame count/FPS; tên và mô tả trạng thái tương tác; giấy phép sử dụng thương mại. **Không giao chỉ một ảnh concept độ phân giải cao thay cho tài sản có thể chơi.**

---

## 17. QUY TRÌNH TẠO BẢN ĐỒ TỪ ĐẶC TẢ [MỚI — ĐỀ XUẤT]

### 17.1 Một map đi qua tám bước

1. **Blockout:** đặt rìa map, đường đi, vùng khóa, landmark, portal, vùng nước/địa hình cao trên lưới tile.
2. **Traversal test:** di chuyển 4 hướng từ mọi portal đến ít nhất một POI; kiểm tra chỗ hẹp, kẹt cửa, băng qua cầu.
3. **Gameplay placement:** đặt Interactable, shop/NPC marker, FishingZone, farming cells, resource nodes, spawn tables.
4. **Palette and terrain:** tô biome, nền, tường, sườn, nước và bảng màu theo mùa.
5. **Set dressing:** mái, hoa, bụi, đèn, đá nhỏ, biển; không làm giảm khả năng đọc lối chính.
6. **Living world:** lịch NPC, chuyển động sinh vật, âm thanh tại vị trí, thời tiết, ánh sáng theo giờ.
7. **Event variants:** khóa/mở, chương truyện, bốn lễ hội, câu đố; test mọi thứ tự sự kiện hợp lệ.
8. **Save/performance/QA:** lưu/tải sau tương tác, test ở scale x2/x3/x4 và khi map đông, đạt 60 FPS theo GDD.

### 17.2 Hai ảnh kiểm chứng bắt buộc của mỗi map

- **Ảnh A — Gameplay nguyên bản 320×180:** nhân vật, đường đi và tối đa HUD thường dùng, cho thấy tính chơi được.
- **Ảnh B — Concept/marketing 16:9:** phong cảnh giàu chi tiết, cùng màu và silhouette; không dùng để đánh giá kích thước va chạm.

Điểm này giúp tránh nhầm lẫn giữa sáu ảnh thiết kế trình bày hiện tại với cảnh có thể đưa trực tiếp vào game.

### 17.3 Một lát cắt sản xuất mẫu (vertical slice)

**Đề xuất:** làm đường **Nông Trại → Phố Chợ → Quảng Trường → Trường → Nông Trại**, kèm một phiên học Số tại bảng giá hoặc trường và một tương tác bán nông sản. Lát cắt phải bao gồm ngày/đêm, mưa, một NPC có lịch, cửa tiệm mở/đóng, lưu/tải, một màn học và đường về. Sau đó mới nhân rộng cùng chuẩn sang rừng/hầm/hồ/biển/núi. [MỚI]

**Tại sao:** một đoạn đường liên thông có đủ nông nghiệp, cửa hàng, hội thoại, tri thức và cổng sẽ kiểm nghiệm “thế giới sống” tốt hơn 11 background chưa có collision.

---

## 18. KIỂM THỬ CHẤT LƯỢNG THẾ GIỚI — DEFINITION OF DONE

### 18.1 Tiêu chuẩn bắt buộc của từng map [GDD + MỚI]

- [ ] Kích thước và tên `map_id` đúng bảng mục 2.2.
- [ ] Portal hai chiều cho phép trở ra; không spawn đè vật thể hoặc đối tượng nguy hiểm.
- [ ] Nhân vật/NPC/động vật không xuyên qua tường/nước sâu/vách theo layer vật lý.
- [ ] Có ít nhất một landmark dễ nhận biết và đường tới hoạt động chính.
- [ ] NPC đang làm việc theo `GameClock`, đổi lịch mưa/lễ hội, không biến mất khi bắt đầu đối thoại.
- [ ] Xuân/Hạ/Thu/Đông và sáng/trưa/đêm không làm thay đổi collision sai ý.
- [ ] Đồ đặt, đất, cây, rương, portal mở và trạng thái cốt truyện lưu/tải được.
- [ ] Không có vật phẩm hoặc rương sinh ra trong ô không đi tới được.
- [ ] Ô học/quest/câu cá/đánh quái có vùng đứng tương tác phù hợp.
- [ ] Hiệu ứng gió/mưa/tuyết không che dấu hiệu báo đòn và tương tác.
- [ ] Tất cả chữ tiếng Việt có dấu, bảng biển/tooltip vừa màn 320×180 với scale hỗ trợ.
- [ ] Mục tiêu 60 FPS; cập nhật ngoài camera đúng chiến lược chunk/object pool của GDD.
- [ ] Có scene test độc lập + ít nhất một unit test GUT logic thuần + ghi chú API trong `docs/`.

### 18.2 Kịch bản QA chung [MỚI]

| Test | Bước | Kết quả mong đợi |
|---|---|---|
| **World reload** | Trồng 3 ô, đặt rương, mở cổng, save/load | Giữ đúng đất, cây, cổng và vật phẩm |
| **Weather cycle** | Chạy từ nắng sang mưa và qua ngày | Cây ngoài trời tự tưới, vật liệu ướt, âm thanh đổi |
| **Season roll** | Từ ngày 7 sang ngày 1 mùa sau | Cây trái mùa héo, tileset đổi, quầy theo mùa thay |
| **NPC and hours** | Tới tiệm trước/đúng/sau giờ mở | Biển/cửa/NPC/Shop đồng bộ; gõ cửa có phản hồi |
| **Story order** | Vào Xuân 4 khi chưa xong Ch1 | Không tự phát hoạt cảnh Ch2; cổng theo quest |
| **Festival overlay** | Ngày 7, đi qua 4 cổng Quảng Trường | Không có gian nào chắn đường/NPC/quest |
| **Forest risk** | Tới rừng ban ngày/đêm/Trăng Tròn/Sương | Spawn, tầm nhìn, đèn và lối về hợp lệ |
| **Mine generation** | Sinh nhiều tầng theo cùng seed/ngày | Có lối xuống, quặng và rương tới được; tái lập đúng |
| **Lake winter** | Đổi từ Thu sang Đông ở Hồ | Băng hình/va chạm/câu băng tương ứng; không mắc kẹt |
| **Beach tide** | Quan sát qua chu kỳ 6 giờ game | Bãi triều đúng thời gian, tài nguyên/đường đi hợp lệ |
| **Mountain heights** | Leo 0→3 và trở xuống | Không xuyên vách/nhầm lớp vẽ, góc camera đúng |
| **Accessibility** | Bật font lớn, giảm chớp, mù màu | Còn đọc rõ icon, telegraph, caption và tương tác |

### 18.3 Định nghĩa hoàn thành toàn thế giới

Một bản game được xem là **hoàn thành thế giới khả dụng** khi có đủ 11 map + nội thất bắt buộc, đi hết các tuyến hợp lệ theo điều kiện mở, chơi một vòng Xuân→Đông, hoàn thành tuyến Ch0–Ch7 và năm trận Bóng Quên, NPC và thời tiết đúng lịch, thế giới giữ trạng thái save, không có softlock và đáp ứng chỉ tiêu hiệu năng GDD. Đây là **tiêu chuẩn tích hợp**, không đòi toàn bộ asset trang trí cao cấp đã polish trước vertical slice.

---

## 19. CÁC ĐIỂM CHƯA THỐNG NHẤT / CẦN CHỐT TRƯỚC KHI CODE

| ID | Vấn đề | Những gì nguồn đang nói | Quyết định tạm trong tài liệu bổ sung | Việc cần chốt |
|---|---|---|---|---|
| `DEC-01` | **Bà Tư / Dì Năm** | GDD: Bà Tư là thủ thư, Dì Năm chủ tạp hóa; ảnh 2 ghi “Cửa Hàng Bà Tư” | Giữ GDD, coi tên trên mockup là chưa chuẩn hóa | Sửa label ở thiết kế UI hoặc đổi GDD bằng quyết định chính thức |
| `DEC-02` | **Tên nông trại** | GDD: Nông Trại Mầm Xanh; hình có Nông Trại Sao Mai/Trang Trại Đồi Gió | Giữ `farm_main` và Nông Trại Mầm Xanh | Chọn tên mặc định/alias rồi cập nhật ảnh |
| `DEC-03` | **Tên vùng trong bản đồ vẽ tay** | Hình 4 có Rừng Mơ, Núi Ngàn Sao, Đầm Linh Thủy; GDD có Rừng Thì Thầm, Núi Mây, Hồ Gương & Sông Bạc | Giữ 11 tên GDD | Xác định là tên cũ/concept hay vùng phụ thực sự |
| `DEC-04` | **Tên game và trung tâm** | Logo Làng Sao Mai; GDD mục 5 gọi “Thị trấn Sao Mai”, `town_square` là Quảng Trường Sao Mai | Làng Sao Mai là tên sản phẩm; Quảng Trường Sao Mai là map | Chốt tên hiển thị trong bản đồ và câu thoại |
| `DEC-05` | **Danh sách kỹ năng** | GDD: Nông nghiệp, Hái lượm, Câu cá, Khai thác, Chiến đấu; hình 5: Trồng trọt, Câu cá, Khai khoáng, Chăn nuôi, Thủ công | Giữ 5 kỹ năng theo GDD; chăn nuôi/thủ công là hoạt động có thể thuộc hệ thống khác | Chốt chỉnh mockup, hoặc thay GDD có chủ đích |
| `DEC-06` | **Số tab sổ tay** | UI spec: 8 mục chính; GDD mục 7.8 nêu “10 thẻ” nhưng liệt kê Trang bị và Thoát riêng, còn ảnh thể hiện 8 tab | World spec không thiết kế lại tab; để UI quyết định sau | Chốt Trang bị là tab hay subtab, Thoát là nút riêng hay tab |
| `DEC-07` | **Cầu mở biển và liên kết bản đồ** | GDD: Biển mở sau sửa cầu Hồ Gương; sơ đồ nối Quảng Trường–Bãi Biển và Hồ–Biển | Dùng gate “sửa cầu Hồ Gương”; không bỏ đường trên sơ đồ nếu chưa chốt | Liệt kê portal chính xác, điểm nào thực sự bị chặn |
| `DEC-08` | **Nhà kính** | GDD: có trong nông trại, sau Ch4 mở nhà kính, cấp Cư Dân 12 mở nhà kính | Chưa quyết định dùng điều kiện AND/OR | Chốt điều kiện xây và sử dụng hệ tưới |
| `DEC-09` | **Kích thước nội thất** | GDD quy định size ngoài; chưa có size mỗi interior | Dùng module 16×12/20×14/24×16 chỉ để thử | Chốt từng nội thất sau blockout |
| `DEC-10` | **Trang trí icon/sao trong lore** | Hình có hoa đào, sao và bảng gỗ; GDD có Ngôi Sao Tri Thức | Đề xuất một hệ biểu tượng năm cánh nhất quán | Chốt mẫu biểu tượng chính trước vẽ toàn bộ |
| `DEC-11` | **Thời điểm mở Ch7 và trùm cuối** | GDD: Ch7 mở Đông 1, trận cuối Đông 7 20:00, chương không hết hạn | Chờ đến sự kiện Đông 7 phù hợp, có thể qua năm sau | Chốt hành vi khi lỡ sự kiện do chưa đủ điều kiện |
| `DEC-12` | **Màn hình Phòng học trên tiêu đề** | GDD có Phòng học; ảnh 1 menu mẫu không hiển thị mục này | Giữ chức năng GDD, không sửa hình tại tài liệu thế giới | Sửa giao diện tiêu đề để có Phòng học |

**Nguyên tắc xử lý:** nhóm art vẫn có thể phát triển **hình, màu, layout blockout** của các vùng; các vấn đề `DEC` ảnh hưởng dữ liệu/UX/tiến trình phải được chốt trước khi kết nối vào scene thật. Không sửa lén các file nguồn.

---

## 20. BRIEF TẠO MINH HỌA VÀ TÀI SẢN CHO TỪNG VÙNG

### 20.1 Master World Art Brief [MỚI]

> **Mục tiêu:** vẽ Làng Sao Mai như một thế giới 2D top-down pixel-art 16-bit ấm áp, đậm cảm giác làng quê Việt hư cấu. Tỷ lệ gốc tile 16×16 và nhân vật 16×32; silhouette nhà mái ngói/nhà tranh, đường đất–đá, hàng rào gỗ, cây bốn mùa, hoa đào, ao sen, núi xanh, ánh đèn vàng, cảnh trong trẻo. Bố cục giữ đường đi và điểm tương tác rõ ràng, vật thể tách lớp để xử lý collision/Y-sort; không vẽ UI vào nền world scene. Mỗi cảnh có bản daylight và trạng thái thời tiết/mùa, giữ một ngôn ngữ bảng màu chung. Tránh sao chép logo/asset từ trò chơi khác.

Đây là **art direction**, không phải prompt thay thế kỹ thuật xuất sprite sheet. Mỗi đầu ra production cần thêm số frame, tỉ lệ, file cấu trúc, background trong suốt và pivot.

### 20.2 Shot list tạo concept/bản vẽ định hướng

| Shot | Nội dung phải có | Lưu ý góc máy |
|---|---|---|
| `WORLD_SHOT_01` | Bình minh Nông Trại, người tưới luống, giếng, mái nhà, cổng làng | Top-down ¾, đường đi nhìn rõ |
| `WORLD_SHOT_02` | Đồng Cỏ có cô Mai, bò/gà, rào gỗ, chuồng | Gợi chăm sóc, không rối đàn |
| `WORLD_SHOT_03` | Phố Chợ nhiều mái ngói, Dì Năm, lò rèn, quán Hương Lúa | Dải ngang, biển hiệu riêng |
| `WORLD_SHOT_04` | Quảng Trường với đài phun và bảng nhiệm vụ | Trục tâm, đủ khoảng trống ngày lễ |
| `WORLD_SHOT_05` | Trường có cổng, sân, vườn thực nghiệm và học sinh | Không biến thành lớp học hiện đại không hợp mỹ thuật |
| `WORLD_SHOT_06` | Đồi Thư Viện có vườn đọc, tán cây và thư viện cổ | Tĩnh, vàng kem và xanh rêu |
| `WORLD_SHOT_07` | Rừng Thì Thầm ban ngày/ban đêm | Hai trạng thái cùng layout, thấy lối mòn |
| `WORLD_SHOT_08` | Sảnh Hầm Đá và một tầng tinh thể sâu | Mô-đun đá và ánh đèn rõ collision |
| `WORLD_SHOT_09` | Hồ Gương, bến câu, cầu gỗ, sen, thác | Đường bờ/điểm câu không bị hoa che |
| `WORLD_SHOT_10` | Bãi Biển Sóng Vàng triều thấp, cầu cảng, thuyền | Biển ngọc lam, ao triều và cát vàng |
| `WORLD_SHOT_11` | Núi Mây từ chân lên đài sao, có bậc cao độ và tuyết | Tầng lớp rõ, đường đi khúc khuỷu |
| `WORLD_SHOT_12` | Lễ Đêm Sao Rơi, đài thiên văn và năm ký hiệu tri thức | Không gian kỳ ảo nhưng ấm, tránh kinh dị |

### 20.3 Brief làm tileset khác brief làm concept

**Tileset:** cần một atlas tile 16×16 với cạnh/góc/đường nối, các ô collision, biến thể mặt đất/sườn/bờ nước và các sprite độc lập cho object lớn. **Character sheet:** 16×32 frame, hướng trước/sau/trái, phải mirror nếu phù hợp, pivot chân thống nhất. **Exterior building:** mái, thân, cửa, đèn, biển thành các lớp. **Environment FX:** có thể tắt/giảm để đáp ứng trợ năng; không vẽ chết vào nền.

---

## 21. LỘ TRÌNH SẢN XUẤT THẾ GIỚI GẮN VỚI GDD

| Giai đoạn GDD | Phần thế giới phải hoàn thành | Cảnh kiểm thử gợi ý |
|---|---|---|
| **M0–M1** | Tile base, nhân vật, Y-sort, camera, Nông Trại blockout | Chạy vòng qua nhà, ruộng, cổng và cây |
| **M2–M3** | Bộ ánh sáng, mùa, thời tiết, giao diện HUD, hotbar | Qua 06:00 → hoàng hôn → đêm và save/load |
| **M4** | Đất/cây và asset mùa nông trại, hòm hàng | Trồng–tưới–thu hoạch–bán 3 ngày |
| **M5** | Cổng vùng và nội thất/cửa/Interactable | Đi nhà → chợ → nhà, giữ trạng thái đồ |
| **M6–M7** | Phố Chợ, Quảng Trường, Trường và 12 NPC theo lịch | Ngày nắng/mưa, hội thoại/quầy/nhiệm vụ |
| **M8** | Rừng, hầm, quái, phòng boss | Vòng rừng đêm, hầm tầng 1–10 |
| **M9** | Đồng Cỏ, chuồng, động vật và sản phẩm | Chăm gà/bò qua 7 ngày |
| **M10** | Hồ, nước, biển, thủy triều, câu cá | Câu theo thời tiết và triều |
| **M11** | Địa điểm học thực thụ, lớp/thư viện/bến/đài | 5 mảng tri thức, mở minigame đúng nơi |
| **M12** | Đài Núi Mây, 5 Bóng Quên, overlay chương/lễ hội | Chơi trọn Ch0–Ch7 |
| **M13–M14** | Âm thanh, polish, trợ năng, cân bằng/QA | 60 FPS, không softlock, build Windows |

### 21.1 Bản bàn giao cho đội phát triển [MỚI]

Mỗi khu vực có một thư mục `docs/world/` chứa: (1) phiếu map từ W01–W11; (2) bản blockout có ký hiệu portal; (3) danh sách POI và Interactable; (4) bảng asset cần vẽ; (5) danh sách trạng thái mùa/giờ/chương; (6) bảng NPC và spawn; (7) ảnh kiểm chứng 320×180; (8) kết quả QA/Performance. Sau khi team phê duyệt `DEC` còn mở, chuyển các đề xuất đã chốt thành dữ liệu `.tres`/JSON có version.

---

## PHỤ LỤC A — HÀNH TRÌNH MẪU MỘT NGÀY TRONG LÀNG

> **Ví dụ trải nghiệm [MỚI]:** Đây là một chuỗi có thể xảy ra dựa trên quy tắc game, không phải lịch nhiệm vụ bắt buộc.

**06:00:** thức dậy trong nhà Nông Trại Mầm Xanh, nhìn TV dự báo mưa mai, kiểm tra thư và bảng nhiệm vụ. **07:00–08:00:** chăm ruộng và cho vật nuôi ăn; nếu mưa, giảm công tưới. **09:00:** tới Phố Chợ, mua giống của Dì Năm và ghé quán; trong tiệm, một bài toán tính tiền được mở như hoạt động tự chọn. **10:00:** qua Quảng Trường, nhận nhiệm vụ hằng ngày và gặp một NPC, sau đó ghé Hồ Gương câu cá. **Chiều:** tới Thư Viện mượn sách hoặc học ở Trường khi có lớp. **Hoàng hôn:** trên đường về, đèn làng bật dần, người dân trở về nhà. **Tối:** về nông trại nấu ăn, đọc sách, sửa sang rồi ngủ để lưu tự động. Nếu người chơi thích khám phá, họ có thể đổi cả buổi chiều thành vào Rừng hoặc Hầm mà không phá mạch truyện.

## PHỤ LỤC B — HÀNH TRÌNH MẪU QUA BỐN MÙA

- **Xuân:** xây nông trại, làm quen làng và cô Lan; cây, hoa, đường rừng là các dấu mở rộng dễ thấy.
- **Hạ:** học ở thư viện, phục hồi sách, rồi ra biển, quan sát đom đóm, tham gia Hội Biển Đêm.
- **Thu:** thu hoạch bí/nho, khám phá hầm sâu và núi, đọc ký ức, cùng cộng đồng dự Hội Gặt.
- **Đông:** chuẩn bị áo ấm, câu cá băng, quan sát sao, kết thúc cốt truyện tại Đêm Sao Rơi; sang năm sau vẫn có thể sống, làm nông và hoàn thiện Bách khoa.

**Lưu ý:** đây là nhịp gợi ý tương ứng các mốc mở sớm nhất của GDD, không biến chương thành deadline; nếu chưa hoàn tất, tiến trình kéo sang năm tiếp.

## PHỤ LỤC C — TỪ ĐIỂN ĐỊA DANH VÀ ID CANON

| ID | Tên hiện dùng trong bản này | Trọng tâm |
|---|---|---|
| `farm_main` | Nông Trại Mầm Xanh | Nhà người chơi |
| `ranch` | Đồng Cỏ Cỏ Xanh | Chăn nuôi |
| `market_street` | Phố Chợ | Kinh tế, giao thương |
| `town_square` | Quảng Trường Sao Mai | Sinh hoạt làng |
| `school_grounds` | Trường Ánh Dương | Học Số/Vật |
| `library_hill` | Đồi Thư Viện | Học Chữ/Ký |
| `whispering_forest` | Rừng Thì Thầm | Hái lượm/quái nhẹ |
| `stone_mine` | Hầm Đá Thì Thầm | Khoáng và Vật |
| `mirror_lake` | Hồ Gương & Sông Bạc | Câu cá/nước |
| `golden_beach` | Bãi Biển Sóng Vàng | Biển và Ngữ |
| `cloud_mountain` | Núi Mây | Ký/thiên văn |

## PHỤ LỤC D — DANH SÁCH NGUỒN ĐỂ KIỂM TRA SAU KHI GHÉP GDD

- **GDD gốc:** mục 1 (tầm nhìn), 2–4 (kỹ thuật, thời gian), 5 (11 map), 6 (công trình), 7 (người chơi), 8 (vật phẩm), 9 (truyện/tri thức/NPC/lễ hội), 10 (động vật), 11 (quái), 12 (thực vật), 13 (nước/núi/biển), 14 (giao diện), 15 (kiến trúc và milestone), 16 (asset MVP).
- **UI Spec:** mục 1–2 (ngôn ngữ UI, pixel), 3–4 (HUD/hotbar), 5 (sổ tay), 6–7 (hội thoại, shop, học, câu cá, chiến đấu), 8–10 (tiêu đề/save/nhân vật/trợ năng), 11–14 (Godot/asset/QA).
- **Sáu bảng hình:** (1) ngoài gameplay; (2) hội thoại/cửa hàng/học; (3) chế tạo/cài đặt; (4) bách khoa/bản đồ/quan hệ; (5) túi/kỹ năng/nhiệm vụ; (6) gameplay/chiến đấu/câu cá.

---

**KẾT LUẬN THIẾT KẾ:** Thế giới Làng Sao Mai phải vừa đáng yêu để muốn ở lại, vừa vận hành đủ nhất quán để muốn hiểu sâu hơn. Mỗi ngôi nhà có người ở, mỗi con đường có đích đến, mỗi mùa để lại dấu vết, mỗi vật thể dạy được điều gì đó, và việc phục hồi Ngôi Sao Tri Thức có thể nhìn thấy ngay trong đời sống làng — chứ không chỉ trong màn hình nhiệm vụ.
